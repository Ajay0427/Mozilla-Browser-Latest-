require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

describe('secondsToMinuteFilter', function() {
    beforeEach(ngModule(main.name));

    beforeEach(inject(function(secondsToMinuteFilter) {
        this.filter = secondsToMinuteFilter;
    }));

    it('should return an empty string when something NaN is passed into the filter', function() {
        var input = 'foobar';

        expect(this.filter(input)).toBe('');
    });

    it('should return a formatted date when a number as string is passed into the filter', function() {
        var input = '61';

        expect(this.filter(input)).toBe('1:01');
    });

    it('should pad the seconds value with a 0 when needed', function() {
        var input = '5';

        expect(this.filter(input)).toBe('0:05');
    });

    it('should not pad the minutes value with a 0', function() {
        var input = '125';

        expect(this.filter(input)).toBe('2:05');
    });
});
