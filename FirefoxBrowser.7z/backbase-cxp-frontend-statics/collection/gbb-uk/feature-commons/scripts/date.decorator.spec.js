require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

describe('date filter decorator', function() {
    beforeEach(ngModule(main.name));

    it('should return an empty string if date is invalid', inject(function(dateFilter) {
        expect(dateFilter(null)).toBe('');
    }));

    it('should add "st" to dates ending in 1', inject(function(dateFilter) {
        var first = new Date(2000, 0, 1);
        var twentyFirst = new Date(2000, 0, 21);
        var thirtyFirst = new Date(2000, 0, 31);
        var DATE_FORMAT = 'do';

        expect(dateFilter(first, DATE_FORMAT)).toBe('1st');
        expect(dateFilter(twentyFirst, DATE_FORMAT)).toBe('21st');
        expect(dateFilter(thirtyFirst, DATE_FORMAT)).toBe('31st');
    }));

    it('should add "nd" to dates ending in 2', inject(function(dateFilter) {
        var second = new Date(2000, 0, 2);
        var twentySecond = new Date(2000, 0, 22);
        var DATE_FORMAT = 'do';

        expect(dateFilter(second, DATE_FORMAT)).toBe('2nd');
        expect(dateFilter(twentySecond, DATE_FORMAT)).toBe('22nd');
    }));

    it('should add "rd" to dates ending in 3', inject(function(dateFilter) {
        var third = new Date(2000, 0, 3);
        var twentyThird = new Date(2000, 0, 23);
        var DATE_FORMAT = 'do';

        expect(dateFilter(third, DATE_FORMAT)).toBe('3rd');
        expect(dateFilter(twentyThird, DATE_FORMAT)).toBe('23rd');
    }));

    it('should add "th" to all dates ending in 4, 5, 6, 7, 8, 9, 0', inject(function(dateFilter) {
        var DATE_FORMAT = 'do';
        var days = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 24, 25, 26, 27, 28, 29, 30];

        days.forEach(function (day) {
            var date = new Date(2000, 0, day);
            expect(dateFilter(date, DATE_FORMAT)).toBe(day + 'th');
        });
    }));
});
