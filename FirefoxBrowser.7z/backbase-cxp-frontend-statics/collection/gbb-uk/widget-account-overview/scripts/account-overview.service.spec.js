require('angular');
require('angular-mocks');

var main = require('./index');
var modelXML = require('../model.xml');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');
var accountMock = require('../test/mocks/UK/accounts.json');
var recentTransactionsMock = require('../test/mocks/UK/recent-transactions.json');
var balanceDetailsMock = require('../test/mocks/UK/balance-details.json');
var ngModule = window.module;

describe('Account Overview Service', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    describe('getAcountList()', function() {
        it('should fetch a list of accounts using URL on widget properties', inject(function(AccountOverviewService, lpWidget, $rootScope, $httpBackend) {
            var serverResponse = {
                result: {
                    companyName: accountMock.result.companyName,
                    companyId: accountMock.result.companyId,
                    lastUpdatedTime: accountMock.result.lastUpdatedTime,
                    accounts: []
                },
                responseTime: accountMock.responseTime,
                response: {
                    description: 'a message',
                    brcCode: '029'
                }
            };

            var overview = {
                companyName: accountMock.result.companyName,
                companyId: accountMock.result.companyId,
                lastUpdatedTime: accountMock.result.lastUpdatedTime
            };

            var urlToFetch = 'http://example.com/';

            $httpBackend.expectGET(urlToFetch).respond(200, serverResponse);
            lpWidget.setPreference(AccountOverviewService.PROPERTIES.ACCOUNT_LIST_URL, urlToFetch);

            var result;

            AccountOverviewService.getAccountList().then(function(o) {
                result = o;
            });

            $httpBackend.flush();

            expect(result).toEqual({
                accounts: [],
                overview: overview,
                errorMessage: serverResponse.response.description,
                isError: false,
                isPartialResponse: true
            });
        }));
    });

    describe('setAccountType()', function() {
        it('should process business accounts', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.BUSINESS
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isBussinessAccount).toBe(true);
            expect(account.isCardHolder).not.toBe(true);
        }));

        it('should process credit card control accounts', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.COMMERCIAL_CARDHOLDER
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isCommercialCardholderAccount).toBe(true);
            expect(account.isCardHolder).toBe(true);
        }));

        it('should process credit card sub-accounts', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.BUSINESS_CARDHOLDER
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isBusinessCardholderAccount).toBe(true);
            expect(account.isCardHolder).toBe(true);
        }));

        it('should process money market accounts', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.MONEY_MARKET
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isMoneyMarketAccount).toBe(true);
            expect(account.isCardHolder).not.toBe(true);
        }));

        it('should process foreign accounts', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.INTERNATIONAL
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isForeignAccount).toBe(true);
            expect(account.isCardHolder).not.toBe(true);
        }));

        it('should process loan accounts', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.LOAN
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isLoanAccount).toBe(true);
            expect(account.isCardHolder).not.toBe(true);
        }));

        it('should process loan accounts with special rules', inject(function(AccountOverviewService) {
            var accountTypes = AccountOverviewService.ACCOUNT_TYPES;
            var account = {
                accountMainType: accountTypes.LOAN_SPECIAL_RULE
            };

            AccountOverviewService.setAccountType(account);
            expect(account.isNotRuleLoanAccount).toBe(true);
            expect(account.isCardHolder).not.toBe(true);
        }));
    });

    describe('getBalanceDetails()', function() {
        it('should fetch the balance details for a given account', inject(function(AccountOverviewService, $httpBackend, lpWidget) {
            var balanceDetailsUrl = '/balance-details/' + Math.random();
            lpWidget.setPreference(AccountOverviewService.PROPERTIES.BALANCE_DETAIL_URL, balanceDetailsUrl);
            $httpBackend.expectGET(balanceDetailsUrl).respond(200, Object.create(balanceDetailsMock));

            var account = accountMock.result.accounts[0];
            var result;

            AccountOverviewService.getBalanceDetails(account).then(function(o) {
                result = o;
            });
            $httpBackend.flush();

            expect(result).toEqual(balanceDetailsMock.result);
        }));
    });

    describe('getRecentTransactionList()', function() {
        it('should fetch the recent transactions of a given account', inject(function(AccountOverviewService, $httpBackend, lpWidget) {
            var recentTransactionsUrl = '/transactions/' + Math.random();

            lpWidget.setPreference(AccountOverviewService.PROPERTIES.RECENT_TRANSACTIONS_URL, recentTransactionsUrl);
            $httpBackend.expectPOST(recentTransactionsUrl).respond(200, Object.create(recentTransactionsMock));

            var account = accountMock.result;
            var result;
            AccountOverviewService.getRecentTransactionList(account).then(function(o) {
                result = o;
            });
            $httpBackend.flush();
            expect(result.transactions).toBe(recentTransactionsMock.transactions);
        }));
    });
});
