define( function (require, exports, module) {
    'use strict';

    module.name = 'widget-session-timeout';

    require('angular-cookies');

    var base = require('base');
    var core = require('core');

    var designMode = window.bd && window.bd.designMode === 'true';

    var deps = [
        core.name,
        'ngCookies'
    ];

    module.exports = base.createModule(module.name, deps)
        .constant('WIDGET_NAME', module.name )
        .value('IS_DESIGN_MODE', designMode)
        .controller(require('./session-timeout.ctrl'))
        .service(require('./session-keepalive.service'))
        .service(require('./session-logoff.service'));
});
