package com.hsbc.cmb.gbb.gb.user.pa.user.steps;

import com.hsbc.cmb.gbb.gb.testing.RequestInitialisationHelper;
import com.hsbc.cmb.gbb.gb.testing.ResponseGettingHelper;
import com.hsbc.cmb.gbb.gb.testing.ResponseVerificationHelper;
import com.hsbc.cmb.gbb.gb.user.pa.user.configuration.DataStepsConfiguration;
import cucumber.api.DataTable;
import net.thucydides.core.annotations.Step;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.ContextHierarchy;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.equalTo;

@ContextHierarchy({
        @ContextConfiguration(classes = {DataStepsConfiguration.class})
})
class UserProcessApiStepsImplementation {

    private static final String RESPONSE_CODE = "responseCode";
    private static final String TRANSACTION_TYPE = "transactionType";

    @Autowired
    RequestInitialisationHelper requestInitialisation;

    @Autowired
    ResponseVerificationHelper responseVerificationInstance;

    @Autowired
    ResponseGettingHelper responseGettingInstance;

    private Map<String, String> xBibIdHeader;

    @Step
    void setXbibIdHeaderWithBisUsersData(DataTable usersData) {
        this.xBibIdHeader = buildXbibIdHeaderWithBisUsersData(usersData);
    }

    private Map<String, String> buildXbibIdHeaderWithBisUsersData(DataTable usersData) {
        return requestInitialisation.buildXbibIdHeader(usersData);
    }

    @Step
    void setUserHeaders(DataTable usersData) {
        requestInitialisation.setHeaders(buildUserHeaders(usersData));
    }

    private Map<String, String> buildUserHeaders(DataTable usersData) {
        Map<String, String> clientHeaders = requestInitialisation.buildHeaders(usersData);
        Map<String, String> headers = new HashMap<>();
        headers.putAll(xBibIdHeader);
        headers.putAll(clientHeaders);
        return headers;
    }

    @Step
    void sendRequestToUserProcessAPI() {
        responseGettingInstance.getResponseFromRequestWithHeadersToApiEndpoint(requestInitialisation);
    }

    @Step
    void verifyResponseStatus(int status) {
        responseVerificationInstance.verifyResponseStatus(requestInitialisation, status);
    }

    @Step
    void verifyUserProcessApiResponseBody(String responseCode, String system) {
        requestInitialisation.getResponse().then()
                .assertThat()
                .body(RESPONSE_CODE, equalTo(responseCode))
                .body(TRANSACTION_TYPE, equalTo(system));
    }

    @Step
    void verifyUserProcessApiResponseBody(String responseCode) {
        requestInitialisation.getResponse().then()
                .assertThat()
                .body(RESPONSE_CODE, equalTo(responseCode));
    }
}