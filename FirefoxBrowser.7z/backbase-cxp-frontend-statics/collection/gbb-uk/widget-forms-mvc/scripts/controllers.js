/**
 * Controllers
 * @module controllers
 */
(function () {

    'use strict';

    /**
     * Main controller
     * @ngInject
     * @constructor
     */
    angular.module('widget-forms-mvc')
        .controller('MainCtrl', function (widget, $scope, $filter, shortcutService) {

            $scope.isDesignMode = !!bd.designMode;

            $scope.runtimeUrl = b$.portal.config.serverRoot + '/services/forms';

            if ($scope.isDesignMode) {
                // Get avaialble shortcurts
                shortcutService.getShortcuts()
                    .then(function (response) {
                        $scope.shortcuts = response.data.items.length && response.data.items || [];
                    },function () {
                        $scope.shortcuts = [];
                    });

                // Add available shortcuts to the preferences
                widget.addEventListener("preferences-form", function (evt) {
                    var prefs = evt.detail.customPrefsModel = b$.portal.portalModel.filterPreferences(widget.model.preferences.array);
                    var shortcurtsPreference = $filter('filter')(prefs, {name: "shortcut"}, true)[0];

                    shortcurtsPreference.inputType.options = [];

                    if(!$scope.shortcuts.length){
                        shortcurtsPreference.inputType.options.push({
                            label: 'No shortcut available',
                            value: ''
                        });
                    } else {
                        angular.forEach($scope.shortcuts, function (value) {
                            shortcurtsPreference.inputType.options.push({
                                label: value.name,
                                value: value.name
                            });
                        });
                    }
                });

                widget.model.addEventListener('PrefModified', function (ev) {
                    updateConfiguration();

                    $scope.$apply();
                });
            }

            function updateConfiguration() {
                //warn about missing config
                var requiredPreferenceKeys = ['project', 'flow', 'branch', 'lang'];

                var shortcut = widget.getPreference('shortcut');
                $scope['shortcut'] = shortcut;

                var i, key, pref;
                for (i = 0; !shortcut && i < requiredPreferenceKeys.length; i++) {
                    key = requiredPreferenceKeys[i];
                    pref = widget.getPreference(key);
                    if (pref) {
                        $scope[key] = pref;
                    } else {
                        $scope.missingPreference = key;
                        break;
                    }
                }

                if(!shortcut)
                    $scope.missingPreference = 'shortcut';
            }

            $scope.parameters = {
                noTools:true
            };

            updateConfiguration();
        });
})();