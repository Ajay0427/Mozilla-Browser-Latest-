require('angular');
require('angular-mocks');

var main = require('./index');
var modelXML = require('../model.xml');
var indexHTML = require('../index.html');
var accountMock = require('../test/mocks/UK/accounts.json');
var balanceDetailsMock = require('../test/mocks/UK/balance-details.json');
var recentTransactionsMock = require('../test/mocks/UK/recent-transactions.json');
var recentTransactionsEmptyMock = require('../test/mocks/UK/recent-transactions-empty.json');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('AccountOverviewCtrl', function() {
    var createController,
        mockAccountList,
        mockAccountDetails,
        mockRecentTransaction;

    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', widget);
        $provide.value('orderByFilter', jasmine.createSpy('orderByFilter'));
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    beforeEach(inject(function($controller, $rootScope, $httpBackend, AccountOverviewService, lpWidget) {
        createController = function(locals) {
            locals = locals || {
                $scope: $rootScope.$new()
            };
            return $controller('AccountOverviewCtrl as $ctrl', locals);
        };

        mockAccountList = function() {
            // randomise URL to avoid conflicts between tests
            var accountListUrl = '/api/account-overview/' + Math.random();
            var accountListUpdateUrl = '/api/account-overview-updated/' + Math.random();
            var accountList = Object.create(accountMock);

            $httpBackend.whenGET(accountListUrl).respond(accountList);
            $httpBackend.whenGET(accountListUpdateUrl).respond(accountList);
            lpWidget.setPreference(AccountOverviewService.PROPERTIES.ACCOUNT_LIST_URL, accountListUrl);
            lpWidget.setPreference(AccountOverviewService.PROPERTIES.ACCOUNT_UPDATE_URL, accountListUpdateUrl);
        };

        mockAccountDetails = function() {
            // randomise URL to avoid conflicts between tests
            var balanceDetailsUrl = '/api/balance-details/' + Math.random();
            var balanceDetails = Object.create(balanceDetailsMock);

            $httpBackend.whenGET(balanceDetailsUrl).respond(balanceDetails);
            lpWidget.setPreference(AccountOverviewService.PROPERTIES.BALANCE_DETAIL_URL, balanceDetailsUrl);
        };

        mockRecentTransaction = function(recentTransactionsList) {
            // randomise URL to avoid conflicts between tests
            var transactionListUrl = '/api/recent-transactions/' + Math.random();
            var transactionList = Object.create(recentTransactionsMock);

            if (recentTransactionsList === 'recentTransactionsEmptyMock') {
                transactionList = Object.create(recentTransactionsEmptyMock);
            }

            $httpBackend.whenPOST(transactionListUrl).respond(transactionList);
            lpWidget.setPreference(AccountOverviewService.PROPERTIES.RECENT_TRANSACTIONS_URL, transactionListUrl);
        };
    }));

    describe('$onInit()', function() {
        it('should initialize the instance', inject(function() {
            var ctrl = createController();
            var spy = spyOn(ctrl, 'updateAccountList');
            ctrl.$onInit();

            expect(spy).toHaveBeenCalled();
        }));

        it('should expose links via properties', inject(function(lpWidget, $httpBackend) {
            var viewLastStatementLinkMock = '/link/view-last-statement-link/' + Math.random();
            var searchTransactionByDateLinkMock = '/link/search-transaction-by-date-link/' + Math.random();
            var helpWithMakingAPayment = '/link/help-with-making-a-payment/' + Math.random();
            var applyForNewCardHolder = '/link/apply-for-new-card-holder/' + Math.random();
            var applyForOverDraft = '/link/apply-for-over-draft/' + Math.random();
            var ctrl = createController();

            lpWidget.setPreference(ctrl.PROPERTIES.VIEW_LAST_STATEMENT_LINK, viewLastStatementLinkMock);
            lpWidget.setPreference(ctrl.PROPERTIES.SEARCH_TRANSACTION_BY_DATE_LINK, searchTransactionByDateLinkMock);
            lpWidget.setPreference(ctrl.PROPERTIES.HELP_WITH_MAKING_A_PAYMENT_LINK, helpWithMakingAPayment);
            lpWidget.setPreference(ctrl.PROPERTIES.APPLY_FOR_NEW_CARD_HOLDER_LINK, applyForNewCardHolder);
            lpWidget.setPreference(ctrl.PROPERTIES.APPLY_FOR_OVER_DRAFT_LINK, applyForOverDraft);

            mockAccountList();
            ctrl.$onInit();
            $httpBackend.flush();

            expect(ctrl.links).toEqual({
                viewLastStatementLink: viewLastStatementLinkMock,
                searchTransactionByDateLink: searchTransactionByDateLinkMock,
                helpWithMakingAPayment: helpWithMakingAPayment,
                applyForNewCardHolder: applyForNewCardHolder,
                applyForOverDraft: applyForOverDraft
            });
        }));
    });

    describe('updateAccountList()', function() {
        it('should fetch/process a list of accounts and update the controller', inject(function($httpBackend, AccountOverviewService) {
            mockAccountList();

            var ctrl = createController();

            ctrl.updateAccountList();
            expect(ctrl.isLoadingAccountListData).toBe(true);

            $httpBackend.flush();

            var skipTradeAccount = (a) => a.accountMainType !== AccountOverviewService.ACCOUNT_TYPES.TRADE;
            var expectedLength = accountMock.result.accounts.filter(skipTradeAccount).length;

            expect(ctrl.selectedAccount).toBe(null);
            expect(ctrl.accountList.length).toBe(expectedLength);

            var accountOverview = accountMock.result;
            expect(ctrl.overview).toEqual({
                companyName: accountOverview.companyName,
                companyId: accountOverview.companyId,
                lastUpdatedTime: accountOverview.lastUpdatedTime
            });

            expect(ctrl.isLoadingAccountListData).toBe(false);
        }));

        it('should create a relationship between child/parent accounts', inject(function($httpBackend) {
            mockAccountList();

            var ctrl = createController();

            // find an account in the mock list that has sub accounts
            var parentAccountIndex,
                childAccountIndex;
            accountMock.result.accounts.forEach(function(account, index) {
                if (parentAccountIndex !== undefined) {
                    return;
                }

                if (account.subAccountsCount > 0) {
                    parentAccountIndex = index;
                    childAccountIndex = index + 1;
                }

            });

            ctrl.updateAccountList();
            $httpBackend.flush();

            // relationships
            var parentAccount = ctrl.accountList[parentAccountIndex];
            var childAccount = ctrl.accountList[childAccountIndex];

            expect(parentAccount.children[0]).toBe(childAccount);
            expect(childAccount.parent).toBe(parentAccount);
        }));
    });

    describe('selectAccount()', function() {
        it('should set the current selected account, load account details/transactions and sort transactions by date in reverse order', inject(function($httpBackend, orderByFilter, SortViewModel) {
            mockAccountList();
            mockAccountDetails();
            mockRecentTransaction();
            var ctrl = createController();
            ctrl.updateAccountList();
            $httpBackend.flush();

            var account = ctrl.accountList[0];
            expect(account).not.toBeFalsy();

            expect(account.hasBalanceDetails).toBe(true);
            expect(account.hasTransactions).toBe(true);
            expect(ctrl.selectedAccount).toBe(null);

            orderByFilter.and.returnValue(recentTransactionsMock.transactions.slice());

            ctrl.selectAccount(account);
            $httpBackend.flush();

            expect(ctrl.selectedAccount).toBe(account);
            expect(account.unorderedTransactions.length).toBe(recentTransactionsMock.transactions.length);
            expect(account.transactions.length).toBe(recentTransactionsMock.transactions.length);
            expect(account.transactions).not.toBe(account.unorderedTransactions);
            expect(account.balanceDetails).not.toBe(null);
            expect(account.sorting).toEqual(new SortViewModel(SortViewModel.FIELDS.DATE, true));
        }));

        it('should reset the selected account if the current selection matches the account to select', inject(function($httpBackend) {
            mockAccountList();
            mockAccountDetails();
            mockRecentTransaction();
            var ctrl = createController();
            ctrl.updateAccountList();
            $httpBackend.flush();

            var account = ctrl.accountList[0];
            expect(account).not.toBeFalsy();

            expect(ctrl.selectedAccount).toBe(null);

            ctrl.selectAccount(account);
            $httpBackend.flush();

            expect(ctrl.selectedAccount).toBe(account);

            // select again the same account
            ctrl.selectAccount(account);
            expect(ctrl.selectedAccount).toBe(null);
        }));
    });

    describe('getRecentTransactionList()', function() {
        it('should get the recent transactions list when it is empty', inject(function($httpBackend) {
            mockAccountList();
            mockAccountDetails();
            mockRecentTransaction('recentTransactionsEmptyMock');
            var ctrl = createController();
            ctrl.updateAccountList();
            $httpBackend.flush();

            var account = ctrl.accountList[0];
            expect(account).not.toBeFalsy();

            expect(account.hasBalanceDetails).toBe(true);
            expect(account.hasTransactions).toBe(true);
            expect(ctrl.selectedAccount).toBe(null);

            ctrl.selectAccount(account);
            $httpBackend.flush();

            expect(account.hasTransactions).toBe(true);
            expect(account.hasBalanceDetails).toBe(true);
            expect(account.unorderedTransactions.length).toBe(1);
        }));

        it('should get the recent transactions list and set the template to recent transactions', inject(function($httpBackend) {
            mockAccountList();
            mockAccountDetails();
            mockRecentTransaction('recentTransactionsEmptyMock');
            var ctrl = createController();
            ctrl.updateAccountList();
            $httpBackend.flush();

            var account = ctrl.accountList[0];
            expect(account).not.toBeFalsy();

            expect(account.hasBalanceDetails).toBe(true);
            expect(account.hasTransactions).toBe(true);
            expect(ctrl.selectedAccount).toBe(null);

            account.hasBalanceDetails = false;

            ctrl.selectAccount(account);
            $httpBackend.flush();

            expect(account.hasTransactions).toBe(true);
            expect(account.hasBalanceDetails).toBe(false);
            expect(account.unorderedTransactions.length).toBe(1);
            expect(account.template).toBe(account.TEMPLATES.recentTransactions);
        }));

        it('should not get the recent transactions list when model.hasTransactions is false', inject(function($httpBackend) {
            mockAccountList();
            mockAccountDetails();
            mockRecentTransaction('recentTransactionsEmptyMock');
            var ctrl = createController();
            ctrl.updateAccountList();
            $httpBackend.flush();

            var account = ctrl.accountList[0];
            expect(account).not.toBeFalsy();

            expect(account.hasBalanceDetails).toBe(true);
            expect(account.hasTransactions).toBe(true);
            expect(ctrl.selectedAccount).toBe(null);

            account.hasTransactions = false;

            ctrl.selectAccount(account);
            $httpBackend.flush();

            expect(account.hasTransactions).toBe(false);
            expect(account.hasBalanceDetails).toBe(true);
            expect(account.unorderedTransactions).toBe(null);
        }));

        it('should not get the balance details when model.hasBalanceDetails is false', inject(function($httpBackend, AccountOverviewService) {
          mockAccountList();
          mockAccountDetails();
          mockRecentTransaction('recentTransactionsEmptyMock');

          var ctrl = createController();

          // find an account in the mock list that is a trade account
          var loanAccountIndex;
          accountMock.result.accounts.forEach(function(account, index) {
            if (account.accountMainType === AccountOverviewService.ACCOUNT_TYPES.MONEY_MARKET) {
              loanAccountIndex = index;
              return;
            }
          });

          ctrl.updateAccountList();
          $httpBackend.flush();

          // Selection of a trade account because it hasn't any balance details
          var account = ctrl.accountList[loanAccountIndex];

          expect(account).not.toBeFalsy();
          expect(account.hasBalanceDetails).toBe(false);

          ctrl.selectAccount(account);
          $httpBackend.flush();

          expect(account.balanceDetails).toBe(null);
        }));
    });

    describe('sortTransactionsBy()', function() {
        var prepareForSorting;

        beforeEach(inject(function($httpBackend) {
            prepareForSorting = function() {
                mockAccountList();
                mockAccountDetails();
                mockRecentTransaction();

                var ctrl = createController();

                ctrl.updateAccountList();
                $httpBackend.flush();

                var model = ctrl.accountList[0];
                ctrl.selectAccount(model);
                $httpBackend.flush();

                model.selectTab(model.TAB_TRANSACTIONS);

                return {
                    ctrl: ctrl,
                    model: model
                };
            };
        }));

        it('should not sort if there are no transactions', inject(function(SortViewModel) {
            var env = prepareForSorting();
            var model = env.model;
            var ctrl = env.ctrl;

            var FIELDS = SortViewModel.FIELDS;

            model.unorderedTransactions = [];
            ctrl.sortTransactionsBy(model, FIELDS.DATE);

            expect(model.sorting).toBe(null);
        }));

        it('should sort transactions by date', inject(function(orderByFilter, SortViewModel) {
            var env = prepareForSorting();
            var model = env.model;
            var ctrl = env.ctrl;

            var FIELDS = SortViewModel.FIELDS;
            var sortedList = [];
            orderByFilter.and.returnValue(sortedList);

            ctrl.sortTransactionsBy(model, FIELDS.DATE);

            // sorting direction is reversed because the controller sorts by default
            // on DATE field
            expect(model.sorting).toEqual(new SortViewModel(FIELDS.DATE, false));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);
        }));

        it('should sort transactions by value date', inject(function(orderByFilter, SortViewModel) {
            var env = prepareForSorting();
            var model = env.model;
            var ctrl = env.ctrl;

            var FIELDS = SortViewModel.FIELDS;
            var sortedList = [];
            orderByFilter.and.returnValue(sortedList);

            ctrl.sortTransactionsBy(model, FIELDS.VALUE_DATE);

            expect(model.sorting).toEqual(new SortViewModel(FIELDS.VALUE_DATE, false));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);
        }));

        it('should sort transactions by type', inject(function(orderByFilter, SortViewModel) {
            var env = prepareForSorting();
            var model = env.model;
            var ctrl = env.ctrl;

            var FIELDS = SortViewModel.FIELDS;
            var sortedList = [];
            orderByFilter.and.returnValue(sortedList);

            ctrl.sortTransactionsBy(model, FIELDS.TYPE);

            expect(model.sorting).toEqual(new SortViewModel(FIELDS.TYPE, false));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);
        }));

        it('should reverse the sort direction if the current sorting matches the field to sort by', inject(function(orderByFilter, SortViewModel) {
            var env = prepareForSorting();
            var model = env.model;
            var ctrl = env.ctrl;

            var FIELDS = SortViewModel.FIELDS;
            var sortedList = [];
            orderByFilter.and.returnValue(sortedList);

            ctrl.sortTransactionsBy(model, FIELDS.VALUE_DATE);

            expect(model.sorting).toEqual(new SortViewModel(FIELDS.VALUE_DATE, false));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);

            // sort again, same field
            ctrl.sortTransactionsBy(model, FIELDS.VALUE_DATE);

            expect(model.sorting).toEqual(new SortViewModel(FIELDS.VALUE_DATE, true));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);
        }));

        it('should use the value of "reverse" parameter even when the field name matches current sorting', inject(function(orderByFilter, SortViewModel) {
            var env = prepareForSorting();
            var model = env.model;
            var ctrl = env.ctrl;

            var FIELDS = SortViewModel.FIELDS;
            var sortedList = [];
            orderByFilter.and.returnValue(sortedList);

            ctrl.sortTransactionsBy(model, FIELDS.VALUE_DATE);

            expect(model.sorting).toEqual(new SortViewModel(FIELDS.VALUE_DATE, false));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);

            // sort again, same field, but specify the reverse parameter
            ctrl.sortTransactionsBy(model, FIELDS.VALUE_DATE, false);

            expect(model.sorting).toEqual(new SortViewModel(FIELDS.VALUE_DATE, false));
            expect(orderByFilter).toHaveBeenCalledWith(model.unorderedTransactions, model.sorting.field, model.sorting.reverse, jasmine.any(Function));
            expect(model.transactions).toBe(sortedList);
        }));
    });
});
