/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2015. ALL RIGHTS RESERVED.
 *
 * ProjLib software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package net.thucydides.showcase.cucumber.pages;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.lang3.StringUtils;


/**
 * <p>
 * <b> Owner : Selenium Automation Team Created On : 25-Feb-2014
 *
 * TODO : ProjLib class contains common methods to be used for scripts in
 * current project. </b>
 * </p>
 */
public class ProjLib {
    // private static HomePage hmpage;
    // private static LoginPage lgpage;
    // Login to GSP application
    // Parameters - Environment, URL, User CAM level, User Name, Memorable
    // Answer, Non Secure Key, Webdriver
    // return - Null

    // SuitBase.objCommlib = new CommLib();
    private static final String DP_CLOUD_URL = "http://testingservices.cn.hsbc:8080/publicapi/token";
    private static final String PARAM_USER_NAME = "username";
    private static final String PARAM_TYPE = "type";
    private static final String PARAM_KEY = "key";
    private static final String PARAM_ACCOUNT = "account";
    private static final String PARAM_MIN = "min";
    private static final int OTP_TYPE = 1;
    private static final int ACCOUNT_TDS_TYPE = 3;
    private static final String PARAM_SEPERATOR = "&";
    private static final String VALUE_SEPERATOR = "=";


    public static String generateOTP(final String userName, final String serialno, final String otpkey) throws IOException {
        String otp = StringUtils.EMPTY;
        try {
            otp = getOTP(userName, otpkey);
        } catch (NumberFormatException e) {
            // ProjLib.logger.error("Exception thrown:", e);
            otp = getOTP(userName + "_" + serialno, otpkey);
        } catch (Exception e) {
            // ProjLib.logger.error("Exception thrown:", e);
        }
        return otp;
    }

    public static String getOTP(final String userName, final String otpkey) throws IOException {
        String otp;
        do {
            otp = processRequest(buildTokenURL(userName, otpkey, null));
        } while (!(otp.length() == 6));
        return otp;
    }

    private static String processRequest(final String url) throws IOException {
        URL dpcloud = new URL(url);
        // ProjLib.logger.info("req URL:" + url);
        URLConnection yc = dpcloud.openConnection();
        yc.setConnectTimeout(50000);
        BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
        String inputLine = in.readLine();
        String token = inputLine.replaceAll("[\\D]", "");
        Integer.parseInt(token);
        in.close();
        return token;
    }

    private static String buildTokenURL(final String userName, final String otpKey, final String refAccountNumber) {
        String tokenString =
            ProjLib.PARAM_TYPE + ProjLib.VALUE_SEPERATOR + (refAccountNumber == null ? +ProjLib.OTP_TYPE : ProjLib.ACCOUNT_TDS_TYPE
                + ProjLib.PARAM_SEPERATOR + ProjLib.PARAM_ACCOUNT + ProjLib.VALUE_SEPERATOR + refAccountNumber);
        return new StringBuilder().append(ProjLib.DP_CLOUD_URL).append("?").append(ProjLib.PARAM_USER_NAME)
            .append(ProjLib.VALUE_SEPERATOR).append(userName).append(ProjLib.PARAM_SEPERATOR).append(ProjLib.PARAM_KEY)
            .append(ProjLib.VALUE_SEPERATOR).append(otpKey).append(ProjLib.PARAM_SEPERATOR).append(tokenString)
            .append(ProjLib.PARAM_SEPERATOR).append(ProjLib.PARAM_MIN).append(ProjLib.VALUE_SEPERATOR).append("Y").toString();
    }

}
