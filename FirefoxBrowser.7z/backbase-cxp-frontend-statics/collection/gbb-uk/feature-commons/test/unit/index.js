/*----------------------------------------------------------------*/
/* Webpack main entry point
/*----------------------------------------------------------------
 * look for every <filename>.spec.js or <filename>.Spec.js
 * in 'unit/' and '../../scripts/'  folder
 * except 3rd party vendors like bower_components or node_modules
 */

window.jQuery = window.jQuery || require('jquery');
window.$ = window.jQuery;

//var mock = require('mock');
//window.gadgets = mock.gadgets;
//window.b$ = { portal: mock.Portal() };

var testContext = require.context('../../scripts/', true, /^((?![\\/]node_modules|bower_components[\\/]).)*\.spec$/)

testContext.keys().forEach(testContext);
