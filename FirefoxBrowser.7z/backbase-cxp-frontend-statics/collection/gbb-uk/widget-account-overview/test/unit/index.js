/*----------------------------------------------------------------*/
/* Webpack main entry point
/*----------------------------------------------------------------
 * look for every <filename>.spec.js or <filename>.Spec.js
 * in 'unit/' and '../../scripts/'  folder
 * except 3rd party vendors like bower_components or node_modules
 */

var testContext = require.context('../../scripts/', true, /^((?![\\/]node_modules|bower_components[\\/]).)*\.spec$/);

testContext.keys().forEach(testContext);
