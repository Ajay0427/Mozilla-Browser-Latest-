var sharedTasks = require('./gulp-tasks');
sharedTasks.setupCollectionTasks();
