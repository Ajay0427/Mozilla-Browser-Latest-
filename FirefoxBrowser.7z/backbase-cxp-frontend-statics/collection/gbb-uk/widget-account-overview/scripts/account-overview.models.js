define(function(require, exports) {
    'use strict';

    var SORT_FIELDS = {
        DATE: 'id',
        VALUE_DATE: 'valueDate',
        TYPE: 'type'
    };

    SORT_FIELDS.all = [SORT_FIELDS.DATE, SORT_FIELDS.VALUE_DATE, SORT_FIELDS.TYPE];

    var TEMPLATES = {
        loading: 'loading-page',
        balanceDetails: 'balance-details',
        recentTransactions: 'recent-transactions'
    };

    var TAB_BALANCE = 1;
    var TAB_TRANSACTIONS = 2;

    function accountViewModelFactory(AccountOverviewService, SortViewModel) {
        /**
         * Decorator for an Account object. Holds view-model state, e.g. sorting
         * @class AccountViewModel
         */
        function AccountViewModel(account) {
            this.details = account;
            this.children = [];
            this.initialize();
        }

        AccountViewModel.prototype = {
            TAB_BALANCE: TAB_BALANCE,
            TAB_TRANSACTIONS: TAB_TRANSACTIONS,
            TEMPLATES: TEMPLATES,
            SORT_FIELDS: SORT_FIELDS,

            hasTransactions: false,
            hasOnlyTransactions: false,
            hasBalanceDetails: false,
            hasChildren: false,
            hasTypeColumn: false,
            hasValueDateColumn: false,

            activeTab: TAB_BALANCE,
            sorting: null,

            details: null,
            balanceDetails: null,
            unorderedTransactions: null,
            transactions: null,
            transactionsDetails: null,

            children: null,
            parent: null,
            template: null,

            initialize: initialize,
            selectTab: selectTab,
            isSortedBy: isSortedBy,
            canSortTransactionsBy: canSortTransactionsBy,
            sortTransactionsBy: sortTransactionsBy
        };

        function initialize() {
            var accountCode = this.details.accountMainType;
            var hasBoth = belongsToAccountDetailsAndRecentTransactions(accountCode);

            this.hasOnlyTransactions = belongsToRecentTransactions(accountCode);
            this.hasTransactions = this.hasOnlyTransactions || hasBoth;
            this.hasBalance = hasRecentTransactionsBalance(accountCode);
            this.hasBalanceDetails = hasBoth;
            this.hasValueDateColumn = hasRecentTransactionsValueDate(accountCode);
            this.hasTypeColumn = hasRecentTransactionsType(accountCode);
        }

        var accountTypes = AccountOverviewService.ACCOUNT_TYPES;

        function belongsToRecentTransactions(accountCode) {
            return accountCode === accountTypes.MONEY_MARKET;
        }

        function belongsToAccountDetailsAndRecentTransactions(accountCode) {
            return accountCode !== accountTypes.MONEY_MARKET;
        }

        function hasRecentTransactionsValueDate(accountCode) {
            return accountCode === accountTypes.INTERNATIONAL;
        }

        function hasRecentTransactionsType(accountCode) {
            return (
                accountCode === accountTypes.BUSINESS ||
                accountCode === accountTypes.MONEY_MARKET ||
                accountCode === accountTypes.LOAN ||
                accountCode === accountTypes.LOAN_SPECIAL_RULE
            );
        }

        function hasRecentTransactionsBalance(accountCode) {
            return (
                accountCode !== accountTypes.COMMERCIAL_CARDHOLDER &&
                accountCode !== accountTypes.BUSINESS_CARDHOLDER
            );
        }

        function selectTab(tab) {
            var canActivateTab = (tab === this.TAB_BALANCE && this.hasBalanceDetails) ||
                (tab === this.TAB_TRANSACTIONS && this.hasTransactions);

            if (canActivateTab) {
                this.activeTab = tab;
            }

        }

        function isSortedBy(field) {
            return this.sorting && this.sorting.field === field || false;
        }

        function canSortTransactionsBy(field) {
            return (
                SORT_FIELDS.all.indexOf(field) !== -1 &&
                this.unorderedTransactions &&
                this.unorderedTransactions.length
            );
        }

        function sortTransactionsBy(field, reverse) {
            var cannotBeSorted = !this.canSortTransactionsBy(field);

            if (cannotBeSorted) {
                this.sorting = null;
                return;
            }

            var currentSorting = this.sorting;

            if (currentSorting && currentSorting.field === field) {
                currentSorting.reverse = reverse !== undefined ? !!reverse : !currentSorting.reverse;
                return;
            }

            this.sorting = new SortViewModel(field, !!reverse);
        }

        return AccountViewModel;
    }

    function sortViewModelFactory() {
        /**
         * Modeling class for sorting state
         * @class SortViewModel
         */
        function SortViewModel(field, reverse) {
            this.field = field || '';
            this.reverse = reverse !== undefined && reverse || false;
        }

        SortViewModel.FIELDS = SortViewModel.prototype.FIELDS = SORT_FIELDS;

        Object.defineProperty(SortViewModel.prototype, 'isBalanceBroughtForwardInvisible', {
            get: function() {
                if (this.field === this.FIELDS.DATE) {
                    return !this.reverse;
                }

                return true;
            }
        });

        Object.defineProperty(SortViewModel.prototype, 'isBalanceVisible', {
            get: function() {
                return this.field === this.FIELDS.DATE;
            }
        });

        return SortViewModel;
    }

    exports.AccountViewModel = accountViewModelFactory;
    exports.SortViewModel = sortViewModelFactory;
});
