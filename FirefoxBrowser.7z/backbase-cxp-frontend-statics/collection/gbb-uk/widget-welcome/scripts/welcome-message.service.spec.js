require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');
var CurrentUserProfileMock = require('../test/mock/userProfile.json');
var ngModule = window.module;

xdescribe('Welcome Message Service', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    describe('getCurrentUserProfileData()', function() {
        it('should fetch a current profile data using URL on widget properties', inject(function(WelcomeMessageService, lpWidget, $rootScope, $httpBackend) {
            var urlToFetch = '/userProfile/' + Math.random();
            var result;

            $httpBackend.expectGET(urlToFetch).respond(200, CurrentUserProfileMock);
            lpWidget.setPreference(WelcomeMessageService.PROPERTIES.CURRENT_USER_PROFILE_URL, urlToFetch);

            WelcomeMessageService.getCurrentUserProfileData().then(function(o) { result = o; });

            $httpBackend.flush();
            expect(result).toEqual(CurrentUserProfileMock);
        }));
    });
});
