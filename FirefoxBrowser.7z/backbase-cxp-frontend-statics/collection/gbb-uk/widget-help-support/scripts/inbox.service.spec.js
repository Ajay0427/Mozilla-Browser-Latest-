/**
 *  ----------------------------------------------------------------
 *  Copyright © Backbase B.V.
 *  ----------------------------------------------------------------
 *  Author : Backbase R&D - Amsterdam - New York
 *  Filename : main.spec.js
 *  Description:
 *  ----------------------------------------------------------------
 */

require('angular');
require('angular-mocks');

var modelXML = require('../model.xml');
var indexHTML = require('../index.html');
var main = require('./index');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;
var topnavMock = require('../test/mocks/topnav.json');

describe('Inbox Service', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', widget);
    }));

    describe('getInboxStatus()', function() {
        it('should fetch the current inbox status from an endpoint', inject(function($httpBackend, lpWidget, InboxService) {
            var inboxStatusUrl = 'http://example.com/inbox/status' + Math.random();
            lpWidget.setPreference(InboxService.PROPERTIES.INBOX_STATUS_URL, inboxStatusUrl);

            $httpBackend.whenGET(inboxStatusUrl).respond(200, topnavMock);

            var result;

            InboxService.getInboxStatus().then(function (o) { result = o; });
            $httpBackend.flush();

            expect(result).toEqual({
                hasUnreadMessages: true
            });
        }));
    });

});
