package com.hsbc.cmb.gbb.gb.user.pa.user.configuration;

import com.hsbc.cmb.gbb.gb.testing.RequestInitialisationHelper;
import com.hsbc.cmb.gbb.gb.testing.ResponseGettingHelper;
import com.hsbc.cmb.gbb.gb.testing.ResponseVerificationHelper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.hsbc.cmb.gbb.gb.user.pa.user.configuration.CucumberWithProperties.API_RESOURCES_CONFIGURATION;

@Configuration
public class DataStepsConfiguration {

    @Bean
    public ResponseVerificationHelper createResponseVerification() {
        return new ResponseVerificationHelper();
    }

    @Bean
    public ResponseGettingHelper createResponseGetting() {
        return new ResponseGettingHelper();
    }

    @Bean
    public RequestInitialisationHelper createRequestInitialisation() {
        return new RequestInitialisationHelper(System.getProperty(API_RESOURCES_CONFIGURATION));
    }
}