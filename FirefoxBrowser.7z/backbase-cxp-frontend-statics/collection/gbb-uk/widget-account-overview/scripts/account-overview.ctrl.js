/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PROPERTIES = {
        VIEW_LAST_STATEMENT_LINK: 'viewLastStatementLink',
        SEARCH_TRANSACTION_BY_DATE_LINK: 'searchTransactionByDateLink',
        HELP_WITH_MAKING_A_PAYMENT_LINK: 'helpWithMakingAPayment',
        APPLY_FOR_NEW_CARD_HOLDER_LINK: 'applyForNewCardHolder',
        APPLY_FOR_OVER_DRAFT_LINK: 'applyForOverDraft'
    };

    /**
     * @ngInject
     * @controller accountList
     * @constructor
     */
    function AccountOverviewCtrl(AccountOverviewService, lpWidget, orderByFilter, AccountViewModel) {
        this.accountOverviewService = AccountOverviewService;
        this.widget = lpWidget;
        this.orderByFilter = orderByFilter;
        this.AccountViewModel = AccountViewModel;
    }

    AccountOverviewCtrl.prototype.$onInit = function() {
        this.updateAccountList();

        this.links = {
            viewLastStatementLink: this.widget.getPreference(this.PROPERTIES.VIEW_LAST_STATEMENT_LINK),
            searchTransactionByDateLink: this.widget.getPreference(this.PROPERTIES.SEARCH_TRANSACTION_BY_DATE_LINK),
            helpWithMakingAPayment: this.widget.getPreference(this.PROPERTIES.HELP_WITH_MAKING_A_PAYMENT_LINK),
            applyForNewCardHolder: this.widget.getPreference(this.PROPERTIES.APPLY_FOR_NEW_CARD_HOLDER_LINK),
            applyForOverDraft: this.widget.getPreference(this.PROPERTIES.APPLY_FOR_OVER_DRAFT_LINK)
        };
    };

    AccountOverviewCtrl.prototype.PROPERTIES = PROPERTIES;

    /**
     * Update accounts and resets the ViewModel state
     */
    AccountOverviewCtrl.prototype.updateAccountList = function() {
        this.isLoadingAccountListData = true;

        this.accountOverviewService.getAccountList()
            .then(this.setAccountOverview.bind(this))
            .then(this.setAccountListErrors.bind(this))
            .then(this.setAccountList.bind(this))
            .then(this.resetViewState.bind(this));
    };

    // @private
    AccountOverviewCtrl.prototype.resetViewState = function() {
        this.isLoadingAccountListData = false;
        this.selectedAccount = null;
    };

    AccountOverviewCtrl.prototype.setAccountListErrors = function(accountOverview) {
        this.accountListErrors = {
            errorMessage: accountOverview.errorMessage,
            isError: accountOverview.isError,
            isPartialResponse: accountOverview.isPartialResponse
        };

        return accountOverview;
    };

    // @private
    AccountOverviewCtrl.prototype.setAccountOverview = function(accountOverview) {
        this.overview = accountOverview.overview;

        return accountOverview;
    };

    AccountOverviewCtrl.prototype.setAccountList = function(accountOverview) {
        var accountModelList = accountOverview.accounts.map(this.createAccountViewModel, this);

        this.accountList = accountModelList;
        accountModelList.forEach(this.updateRelationships, this);
    };

    AccountOverviewCtrl.prototype.createAccountViewModel = function(account) {
        var model = new this.AccountViewModel(account);

        if (model.hasTransactions && !model.hasBalanceDetails) {
            model.selectTab(model.TAB_TRANSACTIONS);
        } else {
            model.selectTab(model.TAB_BALANCE);
        }

        return model;
    };

    AccountOverviewCtrl.prototype.updateRelationships = function(model, index) {
        var childrenCount = model.details.subAccountsCount;
        var accountList = this.accountList;

        if (!model.parent && childrenCount) {
            updateChildren(model, index + 1, childrenCount);
        }

        function updateChildren(parent, startAt, numberOfChildren) {
            var children = accountList.slice(startAt, startAt + numberOfChildren);

            parent.children = children;
            parent.hasChildren = true;
            children.forEach(function(child) {
                child.parent = parent;
            });
        }
    };

    AccountOverviewCtrl.prototype.selectAccount = function(model) {
        //TODO reset the sort filter
        if (this.selectedAccount === model) {
            this.selectedAccount = null;
            return;
        }

        this.selectedAccount = model;
        model.template = model.TEMPLATES.loading;

        this.getBalanceDetails(model);
        this.getRecentTransactionList(model);
    };

    AccountOverviewCtrl.prototype.sortTransactionsBy = function(accountModel, field, reverse) {
        accountModel.sortTransactionsBy(field, reverse);

        function compareEqualValues(transactionOne, transactionTwo) {
            if (accountModel.sorting.reverse) {
                return (transactionOne.index < transactionTwo.index ? 1 : -1);
            }

            return (transactionOne.index < transactionTwo.index ? -1 : 1);
        }

        function compareDifferentValues(transactionOne, transactionTwo) {
            var inversorOrder = 1;

            //For the transaction date, we need to inverse the sorting
            if (accountModel.sorting.field === accountModel.SORT_FIELDS.DATE) {
                inversorOrder = -1;
            }

            return (transactionOne.value > transactionTwo.value ? -1 : 1) * inversorOrder;
        }

        function filterComparator(transactionOne, transactionTwo) {
            if (transactionOne.value === transactionTwo.value) {
                return compareEqualValues(transactionOne, transactionTwo);
            }

            return compareDifferentValues(transactionOne, transactionTwo);
        }

        if (accountModel.sorting) {
            accountModel.transactions = this.orderByFilter(accountModel.unorderedTransactions, accountModel.sorting.field, accountModel.sorting.reverse, filterComparator);
            return;
        }

        accountModel.transactions = accountModel.unorderedTransactions.slice();
    };

    AccountOverviewCtrl.prototype.getRecentTransactionList = function(model) {
        if (!model.hasTransactions) {
            return;
        }

        var ctrl = this;

        this.accountOverviewService.getRecentTransactionList(model.details).then(function(transactionsDetails) {
            model.unorderedTransactions = transactionsDetails.transactions;
            model.transactionsDetails = {
                earliestDate: transactionsDetails.earliestDate,
                errorMessage: transactionsDetails.errorMessage,
                balanceCarriedForward: transactionsDetails.balanceCarriedForward,
                balanceBroughtForward: transactionsDetails.balanceBroughtForward
            };

            if (!model.hasBalanceDetails) {
                model.template = model.TEMPLATES.recentTransactions;
            }

            model.hasTransactionList = (transactionsDetails.transactions.length && transactionsDetails.transactions.length > 0);
            ctrl.sortTransactionsBy(model, model.SORT_FIELDS.DATE, true);

            if (!transactionsDetails.transactions.length) {
                return;
            }

            if (!model.transactionsDetails.earliestDate) {
                model.transactionsDetails.earliestDate = model.unorderedTransactions[model.unorderedTransactions.length - 1].date;
            }

        });
    };

    AccountOverviewCtrl.prototype.getBalanceDetails = function(model) {
        if (!model.hasBalanceDetails) {
            model.template = model.TEMPLATES.balanceDetails;
            return;
        }

        this.accountOverviewService.getBalanceDetails(model.details).then(function(balanceDetails) {
            model.balanceDetails = balanceDetails;
            model.template = model.TEMPLATES.balanceDetails;
        });

        // TODO error handling
    };

    exports.AccountOverviewCtrl = AccountOverviewCtrl;
});
