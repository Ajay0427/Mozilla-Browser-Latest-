/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PROPERTIES = {
        MORNING_MESSAGE: 'morningMessage',
        AFTERNOON_MESSAGE: 'afternoonMessage',
        EVENING_MESSAGE: 'eveningMessage'
    };

    /**
     * @ngInject
     * @controller accountList
     * @constructor
     */
    function WelcomeMessageCtrl( WelcomeMessageService, lpWidget) {
        this.welcomeMessageService = WelcomeMessageService;
        this.widget = lpWidget;
        this.currentDate = new Date();
    }

    WelcomeMessageCtrl.prototype.PROPERTIES = PROPERTIES;

    WelcomeMessageCtrl.prototype.$onInit = function() {
        this.readGreetingProperties();
        this.setGreetingMessage();
        this.initializeCurrentUserProfile();
    };

    WelcomeMessageCtrl.prototype.readGreetingProperties = function () {
        this.messages = {
            morningMessage: this.widget.getPreference(this.PROPERTIES.MORNING_MESSAGE),
            afternoonMessage: this.widget.getPreference(this.PROPERTIES.AFTERNOON_MESSAGE),
            eveningMessage: this.widget.getPreference(this.PROPERTIES.EVENING_MESSAGE),
        };
    };

    WelcomeMessageCtrl.prototype.setGreetingMessage = function() {
        this.userGreeting = this.getUserGreetingMessage(this.currentDate);
    };

    WelcomeMessageCtrl.prototype.initializeCurrentUserProfile = function() {
        this.welcomeMessageService.getCurrentUserProfileData().then(this.setUserProfile.bind(this));
    };

    WelcomeMessageCtrl.prototype.setUserProfile = function(currentUserProfile) {
        var shortName;
        var userFullName = currentUserProfile.userFullName || '';

        if (userFullName && userFullName.indexOf(' ') !== -1) {
            shortName = userFullName.split(' ')[0];
        }

        this.currentUserProfile = {
            dateAndTimeLastLoggedOn: currentUserProfile.dateAndTimeLastLoggedOn,
            firstName: shortName || userFullName
        };
    };

    WelcomeMessageCtrl.prototype.getUserGreetingMessage = function (date) {
        var hours = date.getHours();
        var minutes = date.getMinutes();

        if (hours < 12) {
            return this.messages.morningMessage;
        }

        if (hours < 17 || (hours === 17 && minutes < 31) ) {
            return this.messages.afternoonMessage;
        }

        return this.messages.eveningMessage;
    };

    exports.WelcomeMessageCtrl = WelcomeMessageCtrl;
});
