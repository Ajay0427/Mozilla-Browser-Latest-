### `v1.0.2 - 31/03/2016`

### v1.0.1 - `20/08/2015, 3:49pm`


### v1.0.0 - `20/08/2015, 2:38pm`
#### Initial release for CXP 5.6  


### v0.1.1 - `10/08/2015, 6:09pm`
#### Remove repository from bower.json  
* move soy file into the template folder  
