package net.serenitybdd.demos.todos;

import net.serenitybdd.jbehave.SerenityStories;

public class OneUserAddTodoUsingExamples extends SerenityStories {}
