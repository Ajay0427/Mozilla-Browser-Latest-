var tasks = require('../gulp-tasks');
tasks.createTasks(__dirname);
