package com.hsbc.cmb.gbb.gb.user.pa.user.steps;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class StepsDefinition {

    @Steps
    private UserProcessApiStepsImplementation usersSteps;

    @Given("^I have a list of the Business Internet Banking User's data:$")
    public void setXbibIdHeaderWithBibUsersData(DataTable usersData) {
        usersSteps.setXbibIdHeaderWithBisUsersData(usersData);
    }

    @And("^I have a list of the client data:$")
    public void buildUserHeaders(DataTable usersData) {
        usersSteps.setUserHeaders(usersData);
    }

    @When("^I send the request to User Process API Endpoint$")
    public void sendRequestToUserProcessAPI() {
        usersSteps.sendRequestToUserProcessAPI();
    }

    @Then("^I get a response with '(.*)'$")
    public void verifyResponseStatus(int status) {
        usersSteps.verifyResponseStatus(status);
    }

    @And("^I verify the response body. I expect to get '(.*)'$")
    public void verifyUserProcessApiResponseBody(String responseCode) {
        usersSteps.verifyUserProcessApiResponseBody(responseCode);
    }
}