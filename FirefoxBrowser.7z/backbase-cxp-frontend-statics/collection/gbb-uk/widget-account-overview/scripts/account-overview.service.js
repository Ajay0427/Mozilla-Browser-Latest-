/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var RESPONSE_PARTIAL = '029';
    var RESPONSE_SUCCESS = '000';

    var PROPERTIES = {
        ACCOUNT_LIST_URL: 'accountListDataSrcUrl',
        BALANCE_DETAIL_URL: 'accountDetailDataUrl',
        RECENT_TRANSACTIONS_URL: 'recentTransactionsDataUrl',
        ACCOUNT_UPDATE_URL: 'accountUpdateDataSrcUrl'
    };

    var ACCOUNT_TYPES = {
        BUSINESS: 'BUSINESS',
        COMMERCIAL_CARDHOLDER: 'CREDIT_CARD_CONTROL',
        BUSINESS_CARDHOLDER: 'CREDIT_CARDHOLDER',
        MONEY_MARKET: 'MONEY_MARKET',
        INTERNATIONAL: 'INTERNATIONAL',
        LOAN: 'LOAN',
        LOAN_SPECIAL_RULE: 'LOAN_NON_RULE_78',
        TRADE: 'TRADE'
    };

    /**
     * @ngInject
     * @service AccountOverviewService
     * @constructor
     */
    function AccountOverviewService($http, lpWidget, lpCoreUtils) {
        this.http = $http;
        this.widget = lpWidget;
        this.lpCoreUtils = lpCoreUtils;
    }

    /**
     * Widget properties used by this service
     * @property PROPERTIES
     * @type {Object}
     */
    AccountOverviewService.prototype.PROPERTIES = PROPERTIES;
    AccountOverviewService.prototype.ACCOUNT_TYPES = ACCOUNT_TYPES;

    AccountOverviewService.prototype.getAccountList = getAccountList;
    AccountOverviewService.prototype.getBalanceDetails = getBalanceDetails;
    AccountOverviewService.prototype.getRecentTransactionList = getRecentTransactionList;
    AccountOverviewService.prototype.setAccountType = setAccountType;

    // @private
    function getData(response) {
        return response.data;
    }

    // @private
    function transformAccountObject(accountOverview) {
        var meta = accountOverview.response || {};
        var errorCode = meta.brcCode;
        var isErrorResponse = errorCode !== RESPONSE_PARTIAL && errorCode !== RESPONSE_SUCCESS;
        var accounts = accountOverview.result.accounts;

        var overview = {
            companyName: accountOverview.result.companyName,
            companyId: accountOverview.result.companyId,
            lastUpdatedTime: accountOverview.result.lastUpdatedTime
        };

        // NOTE: trade accounts are not supported yet
        accounts = accounts.filter(function (account) {
            return account.accountMainType !== ACCOUNT_TYPES.TRADE;
        });

        accounts.forEach(this.setAccountType, this);

        return {
            accounts: accounts,
            overview: overview,
            errorMessage: meta.description || '',
            isError: isErrorResponse,
            isPartialResponse: errorCode === RESPONSE_PARTIAL
        };
    }

    function setAccountType(account) {
        var type = account.accountMainType;

        if (type === ACCOUNT_TYPES.BUSINESS) {
            account.isBussinessAccount = true;
        }
        else if (type === ACCOUNT_TYPES.COMMERCIAL_CARDHOLDER) {
            account.isCommercialCardholderAccount = true;
            account.isCardHolder = true;
        }
        else if (type === ACCOUNT_TYPES.BUSINESS_CARDHOLDER) {
            account.isBusinessCardholderAccount = true;
            account.isCardHolder = true;
        }
        else if (type === ACCOUNT_TYPES.MONEY_MARKET) {
            account.isMoneyMarketAccount = true;
        }
        else if (type === ACCOUNT_TYPES.INTERNATIONAL) {
            account.isForeignAccount = true;
        }
        else if (type === ACCOUNT_TYPES.LOAN) {
            account.isLoanAccount = true;
        }
        else if (type === ACCOUNT_TYPES.LOAN_SPECIAL_RULE) {
            account.isNotRuleLoanAccount = true;
        }

        return account;
    }

    // @private
    function transformBalanceDetailsObject(response) {
        return response.result;
    }

    // @private
    function transformRecentTransactionList(response) {
        var errorMessage;
        var transactions = response.transactions;

        transactions.forEach(function(transaction, index, array) {
            transaction.id = array.length - index;
        });

        if (response.responses[0] && response.responses[0].responseCode !== RESPONSE_SUCCESS) {
            errorMessage = response.responses[0].message;
        }

        return {
            transactions: transactions,
            earliestDate: response.earliestDate,
            errorMessage: errorMessage,
            balanceCarriedForward: response.balances[0].balanceCarriedForward,
            balanceBroughtForward: response.balances[0].balanceBroughtForward
        };
    }

    /**
     * @return {Promise<Array<Account>>}
     */
    function getAccountList() {
        var url = this.widget.getPreference(this.PROPERTIES.ACCOUNT_LIST_URL);

        return this.http.get(url).then(getData).then(transformAccountObject.bind(this));
    }

    /**
     * Fetch balance details of an account
     * @param  {Object} account     Account retrieved by getAccountList
     * @return {Promise<BalanceDetails>}
     */
    function getBalanceDetails(account) {
        var accountSortCode = account.accountSortCode;
        var accountNumber = account.accountNumber;
        var fullAccountNumber = accountSortCode ? accountSortCode + accountNumber : accountNumber;
        var accountDetailstUrl = this.widget.getPreference(this.PROPERTIES.BALANCE_DETAIL_URL).replace('{accountNumber}', fullAccountNumber);

        return this.http.get(accountDetailstUrl).then(getData).then(transformBalanceDetailsObject);
    }

    /**
     * Fetch recent transactions of an account
     * @param  {Object} account     Account object (retrieved by getAccountList)
     * @return {Promise<Array<Transaction>>}
     */
    function getRecentTransactionList(account) {
        var accountSortCode = account.accountSortCode;
        var accountNumber = account.accountNumber;
        var fullAccountNumber = accountSortCode ? accountSortCode + accountNumber : accountNumber;
        var recentTransactionsDataUrl = this.widget.getPreference(this.PROPERTIES.RECENT_TRANSACTIONS_URL);

        //TODO: remove after finishing call with header
        if (recentTransactionsDataUrl.indexOf('{accountNumber}') > -1) {
            recentTransactionsDataUrl = recentTransactionsDataUrl.replace('{accountNumber}', fullAccountNumber);
        }

        var req = {
            method: 'POST',
            url: recentTransactionsDataUrl,
            headers: {
                'X-HSBC-Account-Number': fullAccountNumber
            }
        };

        return this.http(req)
            .then(getData)
            .then(transformRecentTransactionList);
    }

    exports.AccountOverviewService = AccountOverviewService;
});
