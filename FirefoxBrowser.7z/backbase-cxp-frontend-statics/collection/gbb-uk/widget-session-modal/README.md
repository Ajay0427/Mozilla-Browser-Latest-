# Session modal and popup alive Widget
