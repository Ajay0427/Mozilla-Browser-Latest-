define(function(require, exports) {
    'use strict';

    /**
     * HTTP Interceptor
     * - handle CSRF token exchange on all $http calls
     * - fires events on pubsub main channel whenever an HTTP call is completed
     * - reloads the entire page if backend answers a request with 401 or 403
     *
     * @ngInject
     */
    function httpRequestInterceptor($q, $window, $document, lpCoreBus) {
        this.$q = $q;
        this.$window = $window;
        this.$document = $document;
        this.lpCoreBus = lpCoreBus;

        this.token = '';

        /**
         * NOTE: interceptors have no execution context (this), so explicit
         * context-bound methods must be created instead
         */
        this.request = request.bind(this);
        this.response = response.bind(this);
        this.responseError = responseError.bind(this);
    }

    httpRequestInterceptor.prototype.getTokenFromCookie = getTokenFromCookie;
    httpRequestInterceptor.prototype.updateToken = updateToken;

    function getTokenFromCookie() {
        var cookies = this.$document.cookie;

        if (!cookies || cookies.indexOf('BBXSRF=') === -1) {
            return '';
        }

        var token = cookies.split('BBXSRF=')[1];

        return token.split(';')[0];
    }

    function updateToken() {
        var token = this.getTokenFromCookie();

        if (token && this.token !== token) {
            this.token = token;
        }
    }

    function request(config) {
        if (this.token) {
            config.headers['X-BBXSRF'] = this.token;
        }

        return config;
    }

    function response(data) {
        this.updateToken();
        this.lpCoreBus.publish('http-call');

        return data;
    }

    function responseError(rejection) {
        if (rejection.status === 401 || rejection.status === 403) {
            this.$window.location.reload();
        }

        return this.$q.reject(rejection);
    }

    exports.httpRequestInterceptor = httpRequestInterceptor;
});
