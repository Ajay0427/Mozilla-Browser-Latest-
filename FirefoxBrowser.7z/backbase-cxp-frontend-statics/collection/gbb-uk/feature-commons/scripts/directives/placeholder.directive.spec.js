require('angular');
require('angular-mocks');

var main = require('../index');
var ngModule = window.module;

describe('input[placeholder] directive', function() {
    beforeEach(ngModule(main.name));

    it('should remove the placeholder of an input on focus', inject(function($controller, $rootScope) {
        var $element = angular.element(document.createElement('textarea'));
        var placeholder = 'foo bar baz';

        $element.attr('placeholder', placeholder);

        var locals = {
            $scope: $rootScope,
            $element: $element
        };

        var $ctrl = $controller('PlaceholderDirectiveCtrl as $ctrl', locals);

        $rootScope.$apply();
        $ctrl.$onInit();

        expect($element.attr('placeholder')).toBe(placeholder);

        $ctrl.onFocus();
        expect($element.attr('placeholder')).toBe('');
    }));

    it('should restore a previously removed placeholder attribute on blur', inject(function($controller, $rootScope) {
        var $element = angular.element(document.createElement('textarea'));
        var placeholder = 'foo bar baz';

        $element.attr('placeholder', placeholder);

        var locals = {
            $scope: $rootScope,
            $element: $element
        };

        var $ctrl = $controller('PlaceholderDirectiveCtrl as $ctrl', locals);

        $rootScope.$apply();
        $ctrl.$onInit();

        expect($element.attr('placeholder')).toBe(placeholder);

        $ctrl.onFocus();
        expect($element.attr('placeholder')).toBe('');

        $ctrl.onBlur();
        expect($element.attr('placeholder')).toBe(placeholder);
    }));
});
