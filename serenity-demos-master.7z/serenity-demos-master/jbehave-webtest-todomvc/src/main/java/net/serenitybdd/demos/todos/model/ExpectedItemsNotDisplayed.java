package net.serenitybdd.demos.todos.model;

public class ExpectedItemsNotDisplayed extends AssertionError {

    public ExpectedItemsNotDisplayed(Throwable cause) {
        super(cause);
    }
}
