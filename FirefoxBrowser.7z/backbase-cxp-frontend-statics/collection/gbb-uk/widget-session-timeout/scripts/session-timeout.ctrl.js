/**
 * Controllers
 * @module controllers
 */
define(function (require, exports) {
    'use strict';

    const PREFERENCES = {
        SESSION_HEARTBEAT_INTERVAL: 'sessionHeartbeatInterval',
        SESSION_SERVER_TIMEOUT: 'sessionServerTimeout',
        SESSION_KEEP_ALIVE_BIB_INTERVAL: 'sessionKeepAliveBibInterval',
        SESSION_LOGGEDOFF_URL: 'sessionLoggedoffUrl'
    };

    const MESSAGEBUS_EVENTS = {
        HTTP_CALL: 'http-call',
        KEEP_ALIVE: 'session:keep-alive',
        LOGOFF: 'session:logoff',
        TIME_LEFT: 'session:time-left'
    };

    /**
     * @constructor
     * @ngInject
     *
     * @name SessionTimeoutCtrl
     *
     * @description
     * Handles the session timeout logic by subscribing to and emitting events through
     * pubsub.
     *
     * @listens http-call Resets the session timeout counter on any http call.
     * @listens session:keep-alive Calls the sessionKeepAliveService to keep the session active.
     * @listens session:logoff Calls the sessionLogoffService to kill the session on bib and gbbp,
     *          redirects the user afterwards to the [SESSION_LOGGEDOFF_URL].
     *
     * @fires session:time-left Emits time-left event with the remaining session time as payload.
     */
    function SessionTimeoutCtrl(IS_DESIGN_MODE, $interval, $window, lpCoreBus, lpWidget, SessionKeepAliveService, SessionLogoffService) {
        this.$interval = $interval;
        this.$window = $window;

        this.lpCoreBus = lpCoreBus;
        this.lpWidget = lpWidget;

        this.SessionKeepAliveService = SessionKeepAliveService;
        this.SessionLogoffService = SessionLogoffService;

        this.isDesignMode = IS_DESIGN_MODE;
    }

    SessionTimeoutCtrl.prototype.$onInit = onInit;
    SessionTimeoutCtrl.prototype.$onDestroy = onDestroy;

    var bibKeepAliveInterval;
    var timeLeftHeartbeatInterval;

    var pubsubKeepAliveCallback;
    var pubsubLogoffCallback;
    var pubsubHttpCallback;


    function onInit() {
        if (this.isDesignMode) {
            return;
        }

        this.lpCoreBus.subscribe(MESSAGEBUS_EVENTS.KEEP_ALIVE, pubsubKeepAliveCallback = keepAlive.bind(this));
        this.lpCoreBus.subscribe(MESSAGEBUS_EVENTS.LOGOFF, pubsubLogoffCallback = logoff.bind(this));
        this.lpCoreBus.subscribe(MESSAGEBUS_EVENTS.HTTP_CALL, pubsubHttpCallback = resetTimeoutCountdown.bind(this));

        resetTimeoutCountdown.call(this);

        setBibHeartbeat.call(this);
        setTimeLeftHeartbeat.call(this);
    }

    function onDestroy() {
        this.$interval.cancel(bibKeepAliveInterval);
        this.$interval.cancel(timeLeftHeartbeatInterval);

        this.lpCoreBus.unsubscribe(MESSAGEBUS_EVENTS.KEEP_ALIVE, pubsubKeepAliveCallback);
        this.lpCoreBus.unsubscribe(MESSAGEBUS_EVENTS.LOGOFF, pubsubLogoffCallback);
        this.lpCoreBus.unsubscribe(MESSAGEBUS_EVENTS.HTTP_CALL, pubsubHttpCallback);
    }

    /**
     * @method
     *
     * @description
     * Resets the session expire countdown to it's original [SESSION_SERVER_TIMEOUT] value
     */
    function resetTimeoutCountdown() {
        this.serverTimeout = getPreference.call(this, 'SESSION_SERVER_TIMEOUT', 'integer');
    }

    /**
     * @method
     *
     * @description
     * Calls SessionKeepAliveService to extend the active session.
     */
    function keepAlive() {
        this.SessionKeepAliveService.keepAlive('gbbp');

        resetTimeoutCountdown.call(this);
    }

    /**
     * @method
     *
     * @description
     * Calls $onDestroy to make sure that sendalive is not executed while logging off the user
     * and logs off the user.
     */
    function logoff() {
        this.$onDestroy();

        this.SessionLogoffService.logoff().finally(redirectAfterLogoff.bind(this));

        function redirectAfterLogoff() {
            this.$window.location.href = getPreference.call(this, 'SESSION_LOGGEDOFF_URL');
        }
    }

    /**
     * @method
     *
     * @param {string} preference The preference key to retrieve from within the widget properties.
     * @param {string} type Optional parameter to parse preferences to certain type. Only integer
     *                      is currently supported.
     *
     * @description
     * Retrieves the given preference from the widget properties.
     */
    function getPreference(preference, type) {
        preference = this.lpWidget.getPreference(PREFERENCES[preference.toUpperCase()]);

        if (type === 'integer') {
            return parseInt(preference);
        }

        return preference;
    }

    /**
     * @method
     *
     * @description
     * Sets the timeleft heartbeat timer. This runs on an interval of [SESSION_HEARTBEAT_TIMER] second(s).
     *
     * Emits the [TIME_LEFT] bus event with the amount of time left within the current session.
     */
    function setTimeLeftHeartbeat() {
        var heartbeatIntervalPreference = getPreference.call(this, 'SESSION_HEARTBEAT_INTERVAL', 'integer');

        timeLeftHeartbeatInterval = this.$interval(transmitTimeLeftEvent.bind(this), heartbeatIntervalPreference * 1000);

        function transmitTimeLeftEvent() {
            this.serverTimeout--;

            this.lpCoreBus.publish(MESSAGEBUS_EVENTS.TIME_LEFT, this.serverTimeout);
        }
    }

    /**
     * @method
     *
     * @description
     * Sets the BIB keep-alive heartbeat. This runs on an interval of [SESSION_KEEP_ALIVE_BIB_INTERVAL] second(s).
     */
    function setBibHeartbeat() {
        var bibKeepAliveIntervalPreference = getPreference.call(this, 'SESSION_KEEP_ALIVE_BIB_INTERVAL', 'integer');

        bibKeepAliveInterval = this.$interval(bibSessionKeepAlive.bind(this), bibKeepAliveIntervalPreference * 1000);

        function bibSessionKeepAlive() {
            this.SessionKeepAliveService.keepAlive('bib');
        }
    };

    exports.SessionTimeoutCtrl = SessionTimeoutCtrl;
});
