define(function(require, exports) {
    'use strict';

    function filter() {
        var WORD_MATCHER = /(\w+)/g;

        function capitalizeWord($0, word) {
            return word.slice(0, 1).toUpperCase() + word.slice(1).toLowerCase();
        }

        return function (string) {
            if (!string) { return ''; }

            return string.replace(WORD_MATCHER, capitalizeWord);
        };
    }

    exports.capitalize = filter;
});
