package net.serenitybdd.demos.todos.model;

public enum TodoStatusFilter {
    All, Active, Completed
}
