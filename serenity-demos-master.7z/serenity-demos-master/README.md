## Serenity sample projects

A number of sample projects, showing how Serenity can be used with different technology stacks.