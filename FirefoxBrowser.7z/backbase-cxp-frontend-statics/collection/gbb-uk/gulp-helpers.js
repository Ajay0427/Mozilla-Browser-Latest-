'use strict';

var gulp = require('gulp');
var NodePath = require('path');
var FS = require('fs');
var PluginError = require('plugin-error');
var through = require('through2');

var TASK_TYPES = {
    BUILD: 1,
    BUNDLE: 2,
    LINT: 4,
    CLEAN: 8,
    TEST: 16
};

function Task(options) {
    this.watcher = options.watcher || false;
    this.runner = options.runner;
    this.taskName = options.name;
    this.targetDir = options.targetDir;
    this.taskDependencies = options.dependencies;
    this.scope = '';
    this.type = options.type;
    this.outputName = options.outputName;
}

Task.prototype = {
    constructor: Task,
    getPath: function(pathString) {
        var parts = pathString.split('/');
        parts.unshift(this.targetDir);

        return NodePath.join.apply(NodePath, parts);
    },

    shouldRun: function(taskType) {
        return taskType ? (this.type === taskType) : true;
    },

    run: function(taskType) {
        if (this.shouldRun(taskType)) {
            console.log('>>> Task [%s] running on "%s"', this.getName(), this.targetDir);
            gulp.start(this.getName());
            return;
        }

        console.log('>>> Task [%s] skipped', this.getName());
    },

    watch: function() {
        if (!this.watcher) {
            return;
        }

        var watcherPattern = this.getPath(this.watcher);
        var runnerFn = this.run.bind(this, this.BUILD);

        gulp.watch(watcherPattern, runnerFn);
    },

    addToGulp: function() {
        if (this.isAddedToGulp) {
            return;
        }

        this.isAddedToGulp = true;

        var taskArgs = [this.getName()];

        if (this.dependencies) {
            taskArgs.push(this.dependencies);
        }

        var taskFn = this.runner.bind(null, this);
        taskArgs.push(taskFn);

        gulp.task.apply(gulp, taskArgs);
    },

    setScope: function(scope) {
        this.scope = scope || '';
    },

    getName: function() {
        return (this.scope ? this.scope + ':' : '') + this.taskName;
    }
};

Object.defineProperty(Task.prototype, 'dependencies', {
    get: function() {
        if (!this.taskDependencies) {
            return null;
        }

        if (this.scope) {
            return this.taskDependencies.map(d => this.scope + ':' + d);
        }

        return this.taskDependencies;
    }
});

function BuildScope(tasks, scope) {
    this.tasks = tasks;
    this.name = scope;
    this.scope = '';

    if (scope) {
        this.setScope(scope);
    }
}

BuildScope.isScope = function(object) {
    return object instanceof BuildScope;
};

BuildScope.prototype = {
    constructor: BuildScope,

    run: function(taskType) {
        var queue = [];

        this.tasks
            .filter(task => task.shouldRun(taskType))
            .reduce(function(stack, task) {
                var names;

                if (BuildScope.isScope(task)) {
                    names = task.getScopeTaskNames(taskType);
                } else {
                    names = [task.getName()];
                }

                stack.push.apply(stack, names);

                return stack;
            }, queue);

        var taskName = 'run' + Math.random();

        gulp.task(taskName, queue, function() {
            console.log('Task queue completed');
        });

        return gulp.start(taskName);
    },

    getScopeTaskNames: function(taskType) {
        return this.tasks
            .filter(task => task.shouldRun(taskType))
            .map(task => task.getName());
    },

    shouldRun: function(taskType) {
        var tasks = this.tasks
            .map(task => task.shouldRun(taskType))
            .reduce(function(queue, value) {
                if (value) {
                    queue.push(value);
                }

                return queue;
            }, []);

        return tasks.length > 0;
    },

    watch: function() {
        this.tasks.forEach(task => task.watch());
    },

    addToGulp: function() {
        this.tasks.forEach(task => task.addToGulp());
    },

    setScope: function(scope) {
        scope = scope || '';
        this.scope = scope;

        this.tasks.forEach(task => task.setScope(scope));
    }
};

Object.assign(BuildScope.prototype, TASK_TYPES);
Object.assign(Task.prototype, TASK_TYPES);
Object.assign(Task, TASK_TYPES);

/**
 * Find all folders in a collection that have a gulpfile and treat them as components
 * @return {Array<Component>}       Found components
 */
function findComponentFolders() {
    var filesAndFolders = FS.readdirSync(__dirname);
    return filesAndFolders.filter(isComponentDirectory).map(mapToComponent);
}

/**
 * Determines if a given full path holds a component
 * @param  {String}  fullPath       Path to a potential component
 * @return {Boolean}                True if this path seems to be a component
 */
function isComponentDirectory(fullPath) {
    var stats = FS.statSync(fullPath);

    return stats && stats.isDirectory() && FS.existsSync(NodePath.join(fullPath, 'gulpfile.js'));
}

/**
 * Map paths to Component metadata (name/path)
 * @param  {String} path        Component path
 * @return {Object}             Component metadata
 */
function mapToComponent(path) {
    return {
        name: path,
        path: NodePath.join(__dirname, path)
    };
}

function readBuildRc(path) {
    var filePath = NodePath.join(path, '.buildrc');

    if (!FS.existsSync(filePath)) {
        return {};
    }

    return JSON.parse(String(FS.readFileSync(filePath)));
}

/**
 * Setup tasks with Gulp and all their dependencies
 * @param  {BuildScope} scope
 */
function setupScopeTasks(scope) {
    gulp.task('watch', function() {
        return scope.watch();
    });

    gulp.task('build', ['lint'], function() {
        return scope.run(TASK_TYPES.BUILD);
    });

    gulp.task('bundle', function() {
        return scope.run(TASK_TYPES.BUNDLE);
    });

    gulp.task('lint', function() {
        return scope.run(TASK_TYPES.LINT);
    });

    gulp.task('clean', function() {
        return scope.run(TASK_TYPES.CLEAN);
    });

    gulp.task('test', function() {
        return scope.run(TASK_TYPES.TEST);
    });

    scope.addToGulp();
}

function lessFailOnWarning(options) {
    let errorCount = 0;
    let limit = options.maxWarnings || 0;

    return through.obj((file, enc, cb) => {
        if (file.lesshint) {
            file.lesshint.results.forEach((result) => {
                if (result.severity === 'warning') {
                    errorCount++;
                }
            });
        }

        return cb(null, file);
    }, function(cb) {
        if (!errorCount || (limit && errorCount <= limit)) {
            return cb();
        }

        const message = `Failed with ${ errorCount } ` + (errorCount === 1 ? 'warning' : 'warnings');

        this.emit('error', new PluginError('gulp-lesshint', message, {
            name: 'LesshintError'
        }));

        return cb();
    });
}

exports.excludeDependenciesByName = function(excludes, filePath) {
    var excludesRegExp = new RegExp('\\s*require\\([\'\"]{1}[\\.\\\/\\\\\\w]+(' + excludes.join('|') + ')[\\\/\\\\\\w]+[\'\"]\\)\\.name,?', 'ig');
    return FS.readFileSync(filePath).toString().replace(excludesRegExp, '');
};

exports.BuildScope = BuildScope;
exports.Task = Task;

exports.setupScopeTasks = setupScopeTasks;
exports.readBuildRc = readBuildRc;
exports.findComponentFolders = findComponentFolders;
exports.lessFailOnWarning = lessFailOnWarning;
