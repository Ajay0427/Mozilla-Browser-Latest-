# hsbc-theme

Default theme for GBB-UK portal.



## Quick tips

- Breakpoints for responsive design follow bootstrap sizes:
screen xs:      480px;
screen sm:      768px;
screen md:      1024px;
screen lg:      1300px;

- All boostrap variables can be overriden into 'theme-variables.less'

- Bootstrap components can be included by importing them into 'bootstrap.less'

- @font-face declaration and imports for HSBC font are under 'typography.less'

- HSBC Icon font is loaded by 'iconography.less'. All icons have variable counterparts with their Unicode chars

- All available icons are documented under `docs/icons.html` example page.
Access to example [page is here](/portalserver/static/features/[BBHOST]/hsbc-theme/docs/icons.html)
