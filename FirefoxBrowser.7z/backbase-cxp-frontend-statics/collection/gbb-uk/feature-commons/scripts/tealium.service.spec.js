require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

describe('Tealium Service', function() {
    beforeEach(ngModule(main.name));
    beforeEach(inject(function(){
        window.utag = jasmine.createSpyObj('utag', ['track']);
    }));

    it('should call the track method on window.utag', inject(function(TealiumService) {
        TealiumService.track();

        expect(window.utag.track).toHaveBeenCalled();
    }));

    it('should pass the correct eventName and data to the track method', inject(function(TealiumService) {
        var eventName = 'link';
        var eventData = '{"page_type" : "home", "page_name" : "home: Top Nav", "event_name" : "return_to_welcome_page"}';

        TealiumService.track(eventName, eventData);

        expect(window.utag.track).toHaveBeenCalledWith(eventName, eventData);
    }));

});
