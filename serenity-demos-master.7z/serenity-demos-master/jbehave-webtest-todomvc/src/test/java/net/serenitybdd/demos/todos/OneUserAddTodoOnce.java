package net.serenitybdd.demos.todos;

import net.serenitybdd.jbehave.SerenityStories;

public class OneUserAddTodoOnce extends SerenityStories {}
