package net.thucydides.showcase.cucumber.model;

/**
 * Created by john on 22/04/2015.
 */
public enum Color {
    Red, Green, Blue
}
