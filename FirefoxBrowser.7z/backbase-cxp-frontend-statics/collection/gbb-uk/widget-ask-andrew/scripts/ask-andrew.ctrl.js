/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PREFERENCES = {
        ASK_ANDREW_IMAGE_SOURCE: 'askAndrewImageSource',
        ASK_ANDREW_OPTIONS: 'askAndrewOptions',
        ASK_ANDREW_URL: 'askAndrewUrl'
    };

    /**
     * @ngInject
     * @controller accountList
     * @constructor
     */
    function AskAndrewCtrl($window, lpWidget, HsbcUtils) {
        this.widget = lpWidget;
        this.$window = $window;
        this.utils = HsbcUtils;
    }

    AskAndrewCtrl.prototype.PREFERENCES = PREFERENCES;
    AskAndrewCtrl.prototype.$onInit = $onInit;
    AskAndrewCtrl.prototype.openPopUp = openPopUp;

    function $onInit() {
        var imageSource = this.widget.getPreference(this.PREFERENCES.ASK_ANDREW_IMAGE_SOURCE);
        var fullImageSource = this.utils.replaceContextPath(imageSource);

        this.assets = {
            askAndrewImageSource: fullImageSource
        };

        this.question = {
            text: ''
        };
    }

    function openPopUp() {
        if (this.popup && !this.popup.closed) {
            this.popup.close();
        }

        var url = this.widget.getPreference(this.PREFERENCES.ASK_ANDREW_URL);
        var windowOptions = this.widget.getPreference(this.PREFERENCES.ASK_ANDREW_OPTIONS);
        var question = encodeURIComponent(this.question.text);

        url = url.replace('{question}', question);

        this.popup = this.$window.open(url, 'ask-andrew', windowOptions);
    }

    exports.AskAndrewCtrl = AskAndrewCtrl;
});
