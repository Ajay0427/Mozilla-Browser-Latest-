require('angular');
require('angular-mocks');

var modelXML = require('../model.xml');
var indexHTML = require('../templates/main.ng.html');

var main = require('./index');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('SessionModalCtrl', function() {
    function pushSubscriptionCallback(eventName, callback) {
        var callbackName = callback.name.replace('bound ', '');

        this.registeredSubscriptions[callbackName] = callback;
    }

    function pushEventCallback(eventType, callback) {
        var callbackName = callback.name.replace('bound ', '');

        this.registeredEvents[callbackName] = callback;
    }

    beforeEach(ngModule(main.name, function($provide) {
        var lpWidget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', lpWidget);
    }));

    beforeEach(inject(function( $controller, $rootScope, $window, lpWidget) {
        this.$rootScope = $rootScope;
        this.$window = $window;
        this.lpWidget = lpWidget;

        this.lpWidget.body.contains = jasmine.createSpy('contains').and.returnValue(false);

        this.querySelectorSpyObject = jasmine.createSpyObj('querySelector', ['focus']);
        this.lpWidget.body.querySelector = function() {
            return this.querySelectorSpyObject;
        }.bind(this);

        this.lpCoreBusSpy = jasmine.createSpyObj('lpCoreBus', ['publish', 'subscribe', 'unsubscribe']);

        this.$window.addEventListener = jasmine.createSpy('addEventListener');
        this.$window.open = jasmine.createSpy('open');
        this.$window.opener = {gadgets: { pubsub: this.lpCoreBusSpy }};

        this.registeredEvents = [];
        this.registeredSubscriptions = [];

        this.lpCoreBusSpy.subscribe.and.callFake(pushSubscriptionCallback.bind(this));
        this.$window.addEventListener.and.callFake(pushEventCallback.bind(this));

        this.createController = function() {
            $controller('SessionModalCtrl as $ctrl', {
                $scope: this.$rootScope,
                $window: this.$window,
                lpCoreBus: this.lpCoreBusSpy
            });

            this.$rootScope.$ctrl.isPopupWindow = false;
            this.$rootScope.$ctrl.activated = false;

            return this.$rootScope.$ctrl;
        };
    }));

    describe('$onInit', function() {
        it('should subscribe to the appropriate messagebus events', function() {
            var expectedMessageBusEvents = [
                'session:time-left',
                'session-modal:deactivate'
            ];
            var ctrl = this.createController();

            ctrl.$onInit();

            expect(this.lpCoreBusSpy.subscribe).toHaveBeenCalledWith(expectedMessageBusEvents[0], jasmine.any(Function));
            expect(this.lpCoreBusSpy.subscribe).toHaveBeenCalledWith(expectedMessageBusEvents[1], jasmine.any(Function));
        });
    });

    describe('$onDestroy', function() {
        it('should unsubscibe the subscribed messagebus events', function() {
            var expectedMessageBusEvents = [
                'session:time-left',
                'session-modal:deactivate'
            ];
            var ctrl = this.createController();

            ctrl.$onInit();
            ctrl.$onDestroy();

            expect(this.lpCoreBusSpy.unsubscribe).toHaveBeenCalledWith(expectedMessageBusEvents[0], this.registeredSubscriptions.evaluate);
            expect(this.lpCoreBusSpy.unsubscribe).toHaveBeenCalledWith(expectedMessageBusEvents[1], this.registeredSubscriptions.deactivate);
        });
    });

    describe('evaluate', function() {
        it('should open a modal and popup on the happy flow', function() {
            var ctrl = this.createController();
            ctrl.$onInit();

            this.lpWidget.setPreference(ctrl.PREFERENCES.SESSION_POPUP_THRESHOLD, 60);

            this.registeredSubscriptions.evaluate(60);

            expect(ctrl.activated).toBeTruthy();
        });
    });

    describe('keepFocus', function() {
        function getEventObject(key, shiftKey) {
            key = key.charCodeAt(0);

            var event = new Event('keyup');
            event.keyCode = key;
            event.shiftKey = !!shiftKey;
            event.which = key;
            event.preventDefault = jasmine.createSpy('preventDefault');

            return event;
        }

        it('should not take any action when the modal was not active', function() {
            // Setup
            var timeLeftPreference = 60;
            var eventObject = getEventObject('\t');

            var ctrl = this.createController();
            ctrl.$onInit();

            // Does not open modal (timeLeftPreference + 1)
            this.lpWidget.setPreference(ctrl.PREFERENCES.SESSION_POPUP_THRESHOLD, timeLeftPreference);
            this.registeredSubscriptions.evaluate(timeLeftPreference + 1);

            this.registeredEvents.keepFocus(eventObject);

            expect(eventObject.preventDefault).not.toHaveBeenCalled();
        });

        it('should not take any action when an other key than TAB has been pressed', function() {
            // Setup
            var timeLeftPreference = 60;
            var eventObject = getEventObject('a');

            var ctrl = this.createController();
            ctrl.$onInit();

            // Open modal
            this.lpWidget.setPreference(ctrl.PREFERENCES.SESSION_POPUP_THRESHOLD, timeLeftPreference);
            this.registeredSubscriptions.evaluate(timeLeftPreference);

            this.registeredEvents.keepFocus(eventObject);this.$window.dispatchEvent(eventObject);

            expect(eventObject.preventDefault).not.toHaveBeenCalled();
        });

        it('should not take any action when the newly focused element is within the widget', function() {
            // Setup
            var timeLeftPreference = 60;
            var eventObject = getEventObject('\t');

            var ctrl = this.createController();
            ctrl.$onInit();

            this.lpWidget.body.contains.and.returnValue(true);

            // Open modal
            this.lpWidget.setPreference(ctrl.PREFERENCES.SESSION_POPUP_THRESHOLD, timeLeftPreference);
            this.registeredSubscriptions.evaluate(timeLeftPreference);

            this.registeredEvents.keepFocus(eventObject);

            expect(eventObject.preventDefault).not.toHaveBeenCalled();
        });

        it('should preventDefault when the newly focused element is outside the widget', function() {
            // Setup
            var timeLeftPreference = 60;
            var eventObject = getEventObject('\t');

            var ctrl = this.createController();
            ctrl.$onInit();

            // Open modal
            this.lpWidget.setPreference(ctrl.PREFERENCES.SESSION_POPUP_THRESHOLD, timeLeftPreference);
            this.registeredSubscriptions.evaluate(timeLeftPreference);

            this.registeredEvents.keepFocus(eventObject);

            expect(eventObject.preventDefault).toHaveBeenCalled();
        });

        it('should move focus to the first button within the modal on tab button up', function() {
            // Setup
            var timeLeftPreference = 60;
            var eventObject = getEventObject('\t');

            var ctrl = this.createController();
            ctrl.$onInit();

            // Open modal
            this.lpWidget.setPreference(ctrl.PREFERENCES.SESSION_POPUP_THRESHOLD, timeLeftPreference);
            this.registeredSubscriptions.evaluate(timeLeftPreference);

            this.registeredEvents.keepFocus(eventObject);

            expect(this.querySelectorSpyObject.focus).toHaveBeenCalled();
        });
    });
});
