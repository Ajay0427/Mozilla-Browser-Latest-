package net.serenitybdd.demo;


import net.serenitybdd.jbehave.SerenityStory;

/**
 * Created by john on 13/11/14.
 */
public class AddANewPet extends SerenityStory {
}
