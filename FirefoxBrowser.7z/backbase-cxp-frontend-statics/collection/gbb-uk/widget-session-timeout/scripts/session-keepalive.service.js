define(function(require, exports) {
    'use strict';

    const PREFERENCES = {
        SESSION_KEEP_ALIVE_BIB_URL: 'sessionKeepAliveBibUrl',
        SESSION_KEEP_ALIVE_GBBP_URL: 'sessionKeepAliveGbbpUrl'
    };

    /**
     * @constructor
     * @ngInject
     */
    function SessionKeepAliveService($http, $q, lpWidget) {
        this.$http = $http;
        this.$q = $q;
        this.widget = lpWidget;
    }

    SessionKeepAliveService.prototype.PREFERENCES = PREFERENCES;
    SessionKeepAliveService.prototype.keepAlive = keepAlive;

    /**
     * @method
     *
     * @param {string} environment the environment for which the URL needs to be retrieved.
     *
     * @description
     * Retrieves the keep alive URL from the preferences for the given environment, supports
     * BIB and GBBP.
     *
     * @returns {string} keepalive url for the given environment if valid, undefined otherwise.
     */
    function getUrl(environment) {
        if (!environment) {
            return '';
        }

        var keepAliveUrlKey = 'SESSION_KEEP_ALIVE_' + environment.toUpperCase() + '_URL';
        var keepAliveUrl;

        if (keepAliveUrlKey in PREFERENCES) {
            keepAliveUrl = this.widget.getPreference(PREFERENCES[keepAliveUrlKey]);
        }

        return keepAliveUrl;
    }

    /**
     * @method
     * @public
     *
     * @param {string} environment the environment for which the session needs to be kept alive.
     *
     * @description
     * Sends a GET request to the heartbeat URL for the given environment.
     *
     * @returns {promise} keepalive url for the given environment if valid, undefined otherwise.
     */
    function keepAlive(environment) {
        var keepAliveUrl = getUrl.call(this, environment);
        var response = this.$q.reject();

        if (keepAliveUrl) {
            response = this.$http.get(keepAliveUrl, {
                headers: { 'Content-Type': 'text/plain' },
                withCredentials: true
            });
        }

        return response;
    };

    exports.SessionKeepAliveService = SessionKeepAliveService;
});
