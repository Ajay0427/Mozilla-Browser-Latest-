require('jquery');
require('bootstrap');
require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

xdescribe('Feature commons Tooltip', function() {

    beforeEach(ngModule(main.name));

    describe('initialize Tooltip', function() {
        it('should initialize the tooltip', inject(function($rootScope, $compile) {
            var scope = $rootScope.$new();
            var element = angular.element('<div tooltip></div>');
            var compiledElement = $compile(element)(scope);
            scope.$digest();
            var directiveElem = compiledElement;

            expect(directiveElem).toBeDefined();
        }));
    });

    describe('Tooltip behaviour', function() {
        it('should call element.popover()', inject(function($rootScope, $compile) {
            var scope = $rootScope.$new();
            var element = angular.element('<div tooltip></div>');
            var compiledElement = $compile(element)(scope);
            scope.$digest();
            var directiveElem = compiledElement;

            spyOn(directiveElem, 'tooltip').andCallThrough();

            directiveElem.trigger('click');

            expect(directiveElem.popover).toHaveBeenCalled();
        }));

        it('shouldn\'t call element.popover() when hover', inject(function($rootScope, $compile) {
            var scope = $rootScope.$new();
            var element = angular.element('<div tooltip></div>');
            var compiledElement = $compile(element)(scope);
            scope.$digest();
            var directiveElem = compiledElement;

            directiveElem.triggerHandler('mouseenter');

            expect(scope.element.popover).not.toHaveBeenCalled();
        }));
    });
});
