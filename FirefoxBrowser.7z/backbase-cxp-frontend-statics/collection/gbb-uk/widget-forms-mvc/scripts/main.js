/**
 *  ----------------------------------------------------------------
 *  Copyright © Backbase B.V.
 *  ----------------------------------------------------------------
 *  Filename : main.js
 *  Description: ${widget.description}
 *  ----------------------------------------------------------------
 */

(function(){

  'use strict';

  var moduleName = 'widget-forms-mvc';

  var deps = [
    'angular-oauth2', //loaded via script tag
    'forms-ui' //loaded via script tag
  ];

  angular.module(moduleName, deps)
    .constant('WIDGET_NAME', moduleName)
    .value('templateBase',  b$.portal.config.serverRoot + '/services/forms/webresources/interface/default/templates')
    .config(['OAuthProvider', 'OAuthTokenProvider', 'servicePath', '$httpProvider', function(OAuthProvider, OAuthTokenProvider, servicePath, $httpProvider) {

        $httpProvider.defaults.xsrfCookieName = 'BBXSRF';
        $httpProvider.defaults.xsrfHeaderName = 'X-BBXSRF';

      OAuthProvider.configure({
        baseUrl: servicePath,
        clientId: 'admin',
        clientSecret: 'admin',
        grantPath: '/oauth/token',
        revokePath: '/oauth/revoke'
      });

      OAuthTokenProvider.configure({
        name: 'token',
        options: undefined
      });
    }])
    .run(['$rootScope', '$window', 'OAuth', 'OAuthToken', 'OAuthConfig', function($rootScope, $window, OAuth, OAuthToken, OAuthConfig) {
        $rootScope.$on('oauth:error', function (event, rejection) {
          // Ignore `invalid_grant` error - should be catched on `LoginController`.
          if ('invalid_grant' === rejection.data.error) {
            return;
          }

          // Refresh token when a `invalid_token` error occurs.
          if ('invalid_token' === rejection.data.error) {
            OAuthToken.removeToken();
            return OAuth.getAccessToken(OAuthConfig.credentials, OAuthConfig.options)
          }

          // Redirect to `/login` with the `error_reason`.
          return $window.location.href = '/login?error_reason=' + rejection.data.error;
        });
      }]);
})();