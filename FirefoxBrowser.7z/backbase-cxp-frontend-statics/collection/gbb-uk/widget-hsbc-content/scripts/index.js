/**
*  ----------------------------------------------------------------
*  Author : Backbase R&D - Amsterdam - New York
*  Filename : content.js
*  Description:
*
*  Source code for CXP Universal Content Widget
*  ----------------------------------------------------------------
*/

b$ = b$ || {};
b$.hsbc = b$.hsbc || {};
b$.hsbc.widgets = b$.hsbc.widgets || {};
b$.hsbc.widgets.WidgetHsbcContent = (function($, bd) {
    'use strict';

    return {

        /**
        *  Initialize content widget
        *  @param  {Object} oWidget Backbase widget object
        */
        start: function(oWidget) {

            var delayed = false;

            // Design Mode
            if (window.be.ice && bd && bd.designMode === 'true') {
                b$.hsbc.widgets.WidgetHsbcContent.enableEdit(oWidget);
            } else if (!delayed) {
                // ICE library not loaded yet, delay rendering
                delayed = true;
                setTimeout(b$.hsbc.widgets.WidgetHsbcContent.renderFinished(oWidget), 500);
            } else {
                b$.hsbc.widgets.WidgetHsbcContent.renderFinished(oWidget);
            }

            this.setBackgroundImage(oWidget);
            this.setWidgetHeight(oWidget);
        },

        /**
        *  enableEdit: enabled ICE editing for widget
        *  @param  {Object} oWidget Backbase widget object
        */
        enableEdit: function(oWidget) {

            oWidget.iceConfig = window.be.ice.config;
            var isMasterpage = window.be.utils.module('top.bd.PageMgmtTree.selectedLink').isMasterPage;
            // .model.manageable === true means widget belongs to master page
            // and is made manageable. In this case content still shouldn't be editable
            var isManageable = isMasterpage || (oWidget.model.manageable === '' || oWidget.model.manageable === undefined);

            /**
            * Wire Up Events
            */
            oWidget.addEventListener('preferences-form', function() {
                b$.hsbc.widgets.WidgetHsbcContent.preferenceStringToList('templateList', 'templateUrl', oWidget);
                b$.hsbc.widgets.WidgetHsbcContent.preferenceStringToList('bgImageContainerList', 'bgImageContainer', oWidget);
            });

            // this widget has property rendering example (template: simple.html)
            // so we need to refresh widget after property 'title' modified
            oWidget.model.addEventListener('PrefModified', function(e) {
                if (e.attrName === 'title') {
                    b$.hsbc.widgets.WidgetHsbcContent.enableEdit(oWidget);
                }
                b$.hsbc.widgets.WidgetHsbcContent.setWidgetHeight(oWidget);
                b$.hsbc.widgets.WidgetHsbcContent.removeBackgroundImage(oWidget, e.prevValue);
                b$.hsbc.widgets.WidgetHsbcContent.setBackgroundImage(oWidget);
            }, false, oWidget);

            b$.hsbc.widgets.WidgetHsbcContent.renderFinished(oWidget);

            /**
            * Event listener that listens to the targeting container. If the targeting container
            * changes panel, and this widget does use a fullscreen background, it will be set.
            */
            $(oWidget.model).parents()
            .filter(function(i, el) {
                return el.extendedItemName === 'TargetingContainer';
            })
            .map(function(index, targeting) {
                targeting.addEventListener('PrefModified', function() {
                    if ($(oWidget.htmlNode).is(':visible')) {
                        b$.hsbc.widgets.WidgetHsbcContent.setBackgroundImage(oWidget);
                    }
                });
            });

            /**
            * Enable ICE editing
            */
            if (isManageable && window.be.ice.controller && /(?:ADMIN|CREATOR)/.test(oWidget.model.securityProfile)) {
                var templateUrl = b$.hsbc.widgets.WidgetHsbcContent.getEditorialTemplate(oWidget);
                return window.be.ice.controller.edit(oWidget, templateUrl)
                .then(function(dom) {
                    $(oWidget.body).find('.bp-g-include').html(dom);
                    return dom;
                });
            }
        },

        setWidgetHeight: function(oWidget) {
            var widget = $(oWidget.body);
            var pref = oWidget.getPreference('widgetHeight');

            if ((pref !== null || typeof pref !== 'undefined') && pref !== '') {
                widget.css({
                    'min-height': pref + 'px'
                });
            }
        },

        /**
        *  setBackgroundImage: set image as css if needed
        *  @param  {Object} oWidget Backbase widget object
        */
        setBackgroundImage: function(oWidget) {
            var bgImage = $(oWidget.body).find('.background-image');

            // If there is no image, return.
            if (bgImage.length === 0) {
                return;
            }

            var bgImageTarget = b$.hsbc.widgets.WidgetHsbcContent.getBackgroundPosition(oWidget, oWidget.getPreference('bgImageContainer'));
            var imgSource = bgImage.find('img').attr('src');

            if (imgSource && bgImageTarget) {
                bgImageTarget.css({
                    'background-image': 'url(' + bgImage.find('img').attr('src') + ')',
                    'background-size': 'cover',
                    'background-position': 'center top',
                    'background-repeat': 'no-repeat'
                });
            }
        },

        removeBackgroundImage: function(oWidget, bgImagePosition) {
            var element = b$.hsbc.widgets.WidgetHsbcContent.getBackgroundPosition(oWidget, bgImagePosition);
            $(element).css({
                'background': 'none'
            });
        },

        /**
        *  renderFinished:
        *  @param  {Object} oWidget Backbase widget object
        */
        renderFinished: function(oWidget) {
            $('img[src=""], img:not([src])', oWidget.body).addClass('be-ice-hide-image');
            $(oWidget.body).addClass('be-ice-widget-rendered');
        },

        /**
        *  Helper function: preferenceStringToList: function(srcVar, destVar, oWidget)
        *  @param  {string} Source variable on preferences model
        *  @param  {string} Destination variable on preferences model
        *  @param  {Object} oWidget Backbase widget object
        */
        preferenceStringToList: function(srcVar, destVar, oWidget) {
            var prefArray = oWidget.model.preferences.array;
            var optionString = oWidget.getPreference(srcVar);

            if (!optionString) {
                return;
            }

            var optionList = optionString.split(';');
            var pref, i, j;

            for (i = 0; i < prefArray.length; i++) {
                if (prefArray[i].name === destVar) {
                    for (j = 0; j < optionList.length; j++) {
                        pref = optionList[j].split(',');
                        prefArray[i].inputType.options = prefArray[i].inputType.options || {};
                        prefArray[i].inputType.options[j] = {
                            label: pref[0],
                            value: pref[1]
                        };
                    }
                }
            }
        },

        /**
        *  Retrieve the editorial template
        *  @param  {Object} oWidget Backbase widget object
        */
        getEditorialTemplate: function(oWidget) {
            return oWidget.getPreference('templateUrl');
            var templateList = oWidget.getPreference('templateList').split(';');
            var pref, j;

            for (j = 0; j < templateList.length; j++) {
                pref = templateList[j].split(',');
                    if (pref[1] === oWidget.getPreference('templateUrl')) {
                    return ((pref[2] !== null && typeof pref[2] !== 'undefined') ? pref[2] : pref[1]);
                }
            }
        },

        /**
        *  Retrieve the background position if any is set
        *  @param  {Object} oWidget Backbase widget object
        */
        getBackgroundPosition: function(oWidget, bgImagePosition) {
            var bgPosition = false;
            switch (bgImagePosition) {
                case 'widget':
                bgPosition = $($(oWidget.body).parents('.bp-widget')[0]);
                break;

                case 'fullscreen':
                bgPosition = $('#main');
                break;

                case 'container':
                bgPosition = $(oWidget.body).parents('.bp-container').eq(0);
                break;
            }

            return bgPosition;
        },

    };
}(window.jQuery, window.bd));
