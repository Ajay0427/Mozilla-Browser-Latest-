/**
 *  ----------------------------------------------------------------
 *  Copyright © Backbase B.V.
 *  ----------------------------------------------------------------
 *  Author : Backbase R&D - Amsterdam - New York
 *  Filename : main.spec.js
 *  Description:
 *  ----------------------------------------------------------------
 */
 require('angular');
 require('angular-mocks');

 var modelXML = require('../model.xml');
 var indexHTML = require('../index.html');
 var main = require('./index');
 var WidgetMock = require('../test/widget-mocks');
 var ngModule = window.module;
 var topnavMock = require('../test/mocks/topnav.json');

describe('InboxCtrl', function() {
    var createController, mockInbox;
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', widget);
    }));

    beforeEach(inject(function($controller, $rootScope, InboxService, $httpBackend, lpWidget) {
        createController = function() {
            $controller('InboxCtrl as $ctrl', { $scope: $rootScope });
            return $rootScope.$ctrl;
        };

        mockInbox = function () {
            var inboxStatusUrl = lpWidget.getPreference(InboxService.PROPERTIES.INBOX_STATUS_URL);
            $httpBackend.whenGET(inboxStatusUrl).respond(200, topnavMock);
        };
    }));

    describe('$onInit()', function() {
        it('should initialize the widget state', inject(function($httpBackend, lpWidget) {
            var ctrl = createController();
            var inboxUrl = lpWidget.getPreference(ctrl.PREFERENCES.INBOX_URL);
            var helpCentreUrl = lpWidget.getPreference(ctrl.PREFERENCES.HELP_CENTRE_URL);
            var helpForThisPageUrl = lpWidget.getPreference(ctrl.PREFERENCES.HELP_FOR_THIS_PAGE_URL);

            mockInbox();
            ctrl.$onInit();
            $httpBackend.flush();

            expect(ctrl.inbox).toEqual({
                hasUnreadMessages: true
            });

            expect(ctrl.links).toEqual({
                inbox: inboxUrl,
                helpCentre: helpCentreUrl,
                helpForThisPage: helpForThisPageUrl
            });
        }));
    });
});
