/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PROPERTIES = {
        CHANGE_MY_BUSINESS_LINK: 'changeMyBusinessLink',
        RETURN_TO_WELCOME_PAGE_LINK: 'returnToWelcomePageLink',
    };

    /**
     * @ngInject
     * @controller accountList
     * @constructor
     */
    function BusinessDropDownCtrl( BusinessDropDownService, lpWidget) {
        this.businessDropDownService = BusinessDropDownService;
        this.widget = lpWidget;
    }

    BusinessDropDownCtrl.prototype.$onInit = function() {
      this.businessProfileInitialize();
      this.links = {
          changeMyBusinessLink: this.widget.getPreference(this.PROPERTIES.CHANGE_MY_BUSINESS_LINK),
          returnToWelcomePageLink: this.widget.getPreference(this.PROPERTIES.RETURN_TO_WELCOME_PAGE_LINK)
      };
    };

    BusinessDropDownCtrl.prototype.PROPERTIES = PROPERTIES;

    BusinessDropDownCtrl.prototype.businessProfileInitialize = function() {
        this.businessDropDownService.getCurrentBusinessData()
        .then(this.selectedBusinessProfile.bind(this));
    };

    BusinessDropDownCtrl.prototype.selectedBusinessProfile = function(businessProfileResponse) {
        var businessProfile = businessProfileResponse.result;

        this.businessProfile = {
            otherProfiles: businessProfile.hasOtherProfiles,
            selectedBusiness: businessProfile.selectedProfile.companyName,
        };
        return businessProfileResponse;
    };

    exports.BusinessDropDownCtrl = BusinessDropDownCtrl;
});
