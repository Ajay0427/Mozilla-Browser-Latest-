/* global b$ */
(function ($) {
    'use strict';
    var Container = b$.bdom.getNamespace('http://backbase.com/2013/portalView').getClass('container');

    function HeaderContainer() {
        Container.apply(this, arguments);
        this.isPossibleDragTarget = true;
    }

    Container.extend(HeaderContainer, {
        localName: 'hsbcContainerHeader',
        namespaceURI: 'templates_hsbcContainerHeader'
    }, {
        template: function(json) {
            var data = {item: json.model.originalItem};
            return window[this.namespaceURI][this.localName](data);
        },
        handlers: {
            DOMReady: function(){
                $('.btn-log-off').click(function () {
                    window.gadgets.pubsub.publish('session:logoff');
                });
            },

            preferencesSaved: function(event){
                if(event.target === this) {
                    this.refreshHTML();
                }
            }
        }
    });
})(window.jQuery);
