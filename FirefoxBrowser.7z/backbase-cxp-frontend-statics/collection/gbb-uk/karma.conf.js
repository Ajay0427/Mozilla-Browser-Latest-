var webpackConfig = require('./webpack.conf.js');
webpackConfig.entry = {};

module.exports = function(config) {
    var baseConfig = {
        basepath: '',
        frameworks: ['jasmine'],

        autoWatch: true,
        autoWatchBatchDelay: 300,
        browsers: ['Chrome'],
        failOnEmptyTestSuite: false,
        port: 9876,
        reporters: ['progress'],
        singleRun: false,

        preprocessors: {},

        webpack: webpackConfig()
    };

    Object.assign(baseConfig, config);

    baseConfig.files.forEach(function(entry) {
        baseConfig.preprocessors[entry] = ['webpack'];
    });

    return baseConfig;
};
