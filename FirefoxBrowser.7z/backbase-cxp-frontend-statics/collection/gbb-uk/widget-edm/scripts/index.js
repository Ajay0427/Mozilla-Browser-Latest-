b$.hsbc = b$.hsbc || {};
b$.hsbc.widgets = b$.hsbc.widgets || {};
b$.hsbc.widgets.WidgetEdm = (function($) {
    'use strict';

    var CLASSES = {
        OPEN: 'menu-open',
        CLOSED: 'menu-closed'
    };

    var SELECTORS = {
        TOGGLE_TARGET: '[data-target="toggle"]',
        TOGGLE_ROOT: '[data-toggle-root]'
    };

    function WidgetEdm(widget) {
        this.widget = widget;
        this.model = widget.model;
        this.element = widget.body;
        this.widgetChrome = this.element.parentNode;
    }

    WidgetEdm.CLASSES = CLASSES;
    WidgetEdm.SELECTORS = SELECTORS;

    function $onInit() {
        var element = $(this.element);

        element.on('click', '[data-toggle]', this.toggleMenuLevel.bind(this));
        element.on('click', '[data-target="popup"]', this.openPopup.bind(this));
        element.on('click', '[data-saml-token-url]', this.openSamlTokenPage.bind(this));

        window.addEventListener('resize', this.onResize.bind(this));
        this.onResize();
    }

    function onResize() {
        if (!this.secondLevelMenus) {
            this.secondLevelMenus = $(this.element).find('.nav-edm-secondary');
        }

        var geometry = this.getWidgetGeometry();
        var height = this.getContentHeight(geometry);

        this.secondLevelMenus.css('height', height + 'px');
    }

    /**
     * @param {Object} geometry     Object with heights read from DOM nodes
     *                              e.g. outerHeight (chrome), innerHeight (widget body)
     * @return {Number}
     */
    function getContentHeight(geometry) {
        return Math.max(geometry.outerHeight, geometry.innerHeight);
    }

    function getWidgetGeometry() {
        var outerHeight = this.widgetChrome.offsetHeight;
        var innerHeight = this.element.scrollHeight;

        return {
            outerHeight: outerHeight,
            innerHeight: innerHeight
        };
    }

    /**
     * Open/close a menu level
     * @param  {Event} event    Click event on LI node level of that menu
     */
    function toggleMenuLevel(event) {
        var target = event.currentTarget;
        var toggleType = target.getAttribute('data-toggle');

        // only links with these toggle types are actually toggle elements
        if (toggleType !== 'toggle' && toggleType !== 'parent') { return; }

        event.preventDefault();

        var toggleOnParent = toggleType === 'parent';
        var toggleRoot = $(target).parents(SELECTORS.TOGGLE_ROOT);
        var toggleTarget = findToggleTarget(target, toggleOnParent);

        toggleMenuGroup(toggleTarget);
        toggleMenuRoot(toggleRoot);

        this.onResize();
    }

    function openPopup(event) {
        var target = event.currentTarget;
        var options = target.getAttribute('data-target-options');
        var url = $(target).find('> a').eq(0).attr('href');
        var parsedOptions = parseOptionString(options);
        var windowName = parsedOptions.name || '_blank';
        event.preventDefault();

        // NOTE: if a third argument is provided, a popup is always opened, even if the
        // window name is '_blank'
        window.open(url, windowName, parsedOptions.popup ? options : '');
    }

    function openSamlTokenPage(event) {
        var eventTarget = event.currentTarget;
        var aHrefElement = eventTarget.querySelector('a');

        var samlUrl = eventTarget.getAttribute('data-saml-token-url');
        var pageUrl = aHrefElement.getAttribute('href');
        var pageName = aHrefElement.innerText.trim();

        if (!pageUrl) {
            return;
        }

        getSamlResponse(samlUrl).then(function(samlResponse) {
            var form = createSamlForm(pageUrl, pageName, samlResponse);

            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        });

        event.preventDefault();
    }

    function getSamlResponse(samlUrl) {
        var deferred = $.Deferred(); // eslint-disable-line new-cap

        $.get(samlUrl).then(function(response) {
            deferred.resolve(response.data);
        });

        return deferred.promise();
    }

    function createSamlForm(pageUrl, pageName, samlResponse) {
        var form = document.createElement('form');
        form.setAttribute('action', pageUrl);
        form.setAttribute('method', 'post');
        form.setAttribute('target', pageName || '_blank');

        var samlResponseField = document.createElement('input');
        samlResponseField.setAttribute('type', 'hidden');
        samlResponseField.setAttribute('name', 'SAMLResponse');
        samlResponseField.setAttribute('value', samlResponse);

        form.appendChild(samlResponseField);

        return form;
    }

    /**
     * Turns key/value pairs of a string into a map
     * @param {String} string
     * @return {Object}
     */
    function parseOptionString(string) {
        var output = {};

        string.split(/[,]{1}\s*/g).map(function (part) {
            part = part.split('=');
            output[part[0]] = part[1];
        });

        return output;
    }

    function findToggleTarget(startElement, toggleOnParent) {
        var toggleGroup = $(startElement).parents(SELECTORS.TOGGLE_TARGET).eq(0);

        if (toggleOnParent) {
            toggleGroup = $(toggleGroup[0]).parents(SELECTORS.TOGGLE_TARGET).eq(0);
        }

        return toggleGroup;
    }

    function toggleMenuRoot(toggleRoot) {
        var hasOpenMenus = toggleRoot.find('> .' + CLASSES.OPEN).length > 0;

        if (hasOpenMenus) {
            toggleRoot.addClass(CLASSES.OPEN).removeClass(CLASSES.CLOSED);
            return;
        }

        toggleRoot.removeClass(CLASSES.OPEN).addClass(CLASSES.CLOSED);
    }

    function toggleMenuGroup(toggleGroup) {
        var isClosed = !toggleGroup.hasClass(CLASSES.OPEN);

        if (isClosed) {
            $(toggleGroup[0].parentNode.children).removeClass(CLASSES.OPEN);
            toggleGroup.addClass(CLASSES.OPEN);
            return;
        }

        toggleGroup.removeClass(CLASSES.OPEN);
    }

    WidgetEdm.create = function(widget) {
        var instance = new WidgetEdm(widget);
        instance.$onInit();

        return instance;
    };

    WidgetEdm.prototype = {
        constructor: WidgetEdm,
        $onInit: $onInit,
        toggleMenuLevel: toggleMenuLevel,
        openPopup: openPopup,
        openSamlTokenPage: openSamlTokenPage,
        onResize: onResize,
        getContentHeight: getContentHeight,
        getWidgetGeometry: getWidgetGeometry
    };

    return WidgetEdm;
})(window.$);
