define(function (require, exports) {
    function PlaceholderCtrl($element) {
        this.element = $element;
    }

    PlaceholderCtrl.prototype.$onInit = $onInit;
    PlaceholderCtrl.prototype.onFocus = onFocus;
    PlaceholderCtrl.prototype.onBlur = onBlur;

    function $onInit() {
        this.placeholder = this.element.attr('placeholder');
        this.element.on('focus', this.onFocus.bind(this));
        this.element.on('blur', this.onBlur.bind(this));
    }

    function onFocus() {
        this.element.attr('placeholder', '');
    }

    function onBlur() {
        this.element.attr('placeholder', this.placeholder);
    }

    function placeholderDirective() {
        return {
            restrict: 'A',
            controller: 'PlaceholderDirectiveCtrl',
            name: 'placeholder'
        };
    }

    exports.directive = { placeholder: placeholderDirective };
    exports.controller = { PlaceholderDirectiveCtrl: PlaceholderCtrl };
});
