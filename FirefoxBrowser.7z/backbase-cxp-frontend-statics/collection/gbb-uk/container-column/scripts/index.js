(function (b$) {
    'use strict';
    var Container = b$.bdom.getNamespace('http://backbase.com/2013/portalView').getClass('container');

    function ResponsiveGrid() {
        Container.apply(this, arguments);
        this.isPossibleDragTarget = true;
    }

    var properties = {
        localName: 'hsbcColumnsContainer',
        namespaceURI: 'templates_hsbcColumnsContainer',
    };

    var methods = {
        template: function(json) {
            var data = {item: json.model.originalItem};
            return window[this.namespaceURI][this.localName](data);
        },
        handlers: {
            preferencesSaved: function(ev) {
                if (ev.target === this) {
                    this.refreshHTML();
                }
            }
        }
    };

    Container.extend(ResponsiveGrid, properties, methods);
})(window.b$);
