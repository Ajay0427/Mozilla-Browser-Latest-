b$.hsbc = b$.hsbc || {};
b$.hsbc.widgets = b$.hsbc.widgets || {};
b$.hsbc.widgets.HsbcWidgetFooter = (function() {
    'use strict';

    function HsbcWidgetFooter(widget) {
        this.widget = widget;

        var copyRightText = widget.getPreference('copyright');
        widget.body.querySelector('[data-js="copyright"]').innerText = copyRightText;
    }

    HsbcWidgetFooter.create = function(widget) {
        return new HsbcWidgetFooter(widget);
    };

    return HsbcWidgetFooter;
})();
