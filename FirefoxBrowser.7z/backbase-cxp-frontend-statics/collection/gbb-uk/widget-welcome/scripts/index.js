define( function (require, exports, module) {
    'use strict';

    module.name = 'widget-welcome';

    var base = require('base');
    var core = require('core');
    var commons = require('feature-commons');

    var deps = [
        core.name,
        commons.name
    ];

    module.exports = base.createModule(module.name, deps)
        .constant('WIDGET_NAME', module.name )
        .controller( require('./welcome-message.ctrl') )
        .service( require('./welcome-message.service') );
});
