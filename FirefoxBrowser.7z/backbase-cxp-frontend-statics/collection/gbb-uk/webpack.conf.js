'use strict';
var webpack = require('webpack');
var path = require('path');
var autoprefixer = require('autoprefixer');
var NGAnnotatePlugin = require('ng-annotate-webpack-plugin');

module.exports = function(config, excludeExternals) {
    var webpackConfig = {
        output: {},
        resolve: {
            root: [
                path.resolve(__dirname)
            ],
            modulesDirectories: [
                'node_modules',
                'bower_components'
            ],
            extensions: ['', '.js']
        },
        postcss: function() {
            return [
                autoprefixer({
                    browsers: [
                        'last 2 versions',
                        'iOS >= 7'
                    ]
                })
            ];
        },
        plugins: [
            new webpack.ResolverPlugin(
                // @todo fix the ['main', x] issue. Plugin does not allow for arrays in main field, while this is supported according to bower docs
                new webpack.ResolverPlugin.DirectoryDescriptionFilePlugin('bower.json', ['main', ['main', 0], ['main', 1]])
            ),
            new webpack.ProvidePlugin({
                jQuery: 'jquery'
            }),
            new webpack.optimize.DedupePlugin(),
            new webpack.IgnorePlugin(/vertx/),
            new NGAnnotatePlugin({
                add: true,
                sourceMap: true,
            })
        ],
        module: {
            loaders: [
                { test: /\.json$/, loader: 'json' },
                { test: /\.html$/, loader: 'raw' },
                { test: /\.xml$/, loader: 'raw' },
                { test: /\.(scss|sass)$/, loader: 'style!raw!sass!postcss' },
                { test: /\.less$/, loader: 'style!css!less!postcss' },
                { test: /\.css$/, loader: 'style!css!postcss' }
            ]
        },
        node: {
            fs: 'empty',
            child_process: 'empty'
        }
    };

    Object.assign(webpackConfig, config);

    if (excludeExternals) {
        webpackConfig.externals = [
            /^(@[^\/]+\/)?[\w-]+$/,

            // Every non-relative module is external
            function(context, request, callback) {
                // bypass requirejs plugins
                // Every module prefixed with 'async|font|goog|image|json' use the requirejs
                var m = request.match(/^(async|font|goog|image|json|text)!/);
                if (Object.prototype.toString.call(m) !== '[object Null]' && typeof m.input !== 'undefined') {
                    callback(null, m.input);
                    return;
                }

                callback();
            }
        ];
    }

    return webpackConfig;
};
