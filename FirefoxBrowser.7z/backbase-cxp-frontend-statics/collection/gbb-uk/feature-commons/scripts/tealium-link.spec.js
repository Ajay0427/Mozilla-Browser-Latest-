require('jquery');
require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

describe('Feature commons Tealium', function() {

    function createElement(element, scope) {
        element = angular.element(element);
        element = this.$compile(element)(scope);
        scope.$digest();

        return element;
    }

    beforeEach(ngModule(main.name, function($provide) {
        var tealiumServiceMock = jasmine.createSpyObj('tealiumService', ['track']);
        $provide.value('TealiumService', tealiumServiceMock);
    }));

    beforeEach(inject(function($compile, $rootScope, TealiumService) {
        this.$compile = $compile;
        this.$rootScope = $rootScope;

        this.TealiumService = TealiumService;

        this.createElement = createElement.bind(this);
    }));

    describe('click events', function() {
        it('should send a track event with the right object containing for a href elements', function() {
            var expectedEventType = 'linkclick';
            var expectedEventTarget = 'link';
            var expectedEventAttr1 = '';
            var expectedEventAttr2 = '';

            var scope = this.$rootScope.$new();
            var element = this.createElement('<a data-tealium-link=\'{"page_type": "home", "page_name": "home: Top Nav", "event_name": "return_to_welcome_page"}\'></a>', scope);

            var eventName = 'link';
            var eventData = {
                'page_type': 'home',
                'page_name': 'home: Top Nav',
                'event_name': 'return_to_welcome_page',
                'event_type': expectedEventType,
                'event_target': expectedEventTarget,
                'event_attr1': expectedEventAttr1,
                'event_attr2': expectedEventAttr2};

            element.triggerHandler('click');

            expect(this.TealiumService.track).toHaveBeenCalledWith(eventName, eventData);
        });

        it('should send a track event with the right object for button elements', function() {
            var expectedEventType = 'buttonclick';
            var expectedEventTarget = 'button';
            var expectedEventAttr1 = '';
            var expectedEventAttr2 = 'submit';

            var scope = this.$rootScope.$new();
            var element = this.createElement('<button data-tealium-link=\'{"page_type": "home", "page_name": "home: Top Nav", "event_name": "return_to_welcome_page"}\'></button>', scope);

            var eventName = 'link';
            var eventData = {
                'page_type': 'home',
                'page_name': 'home: Top Nav',
                'event_name': 'return_to_welcome_page',
                'event_type': expectedEventType,
                'event_target': expectedEventTarget,
                'event_attr1': expectedEventAttr1,
                'event_attr2': expectedEventAttr2};

            element.triggerHandler('click');

            expect(this.TealiumService.track).toHaveBeenCalledWith(eventName, eventData);
        });

        it('should send a track event with the right object for input elements', function() {
            var expectedEventType = 'buttonclick';
            var expectedEventTarget = 'button';
            var expectedEventAttr1 = '';
            var expectedEventAttr2 = 'submit';

            var scope = this.$rootScope.$new();
            var element = this.createElement('<button data-tealium-link=\'{"page_type": "home", "page_name": "home: Top Nav", "event_name": "return_to_welcome_page"}\'></button>', scope);

            var eventName = 'link';
            var eventData = {
                'page_type': 'home',
                'page_name': 'home: Top Nav',
                'event_name': 'return_to_welcome_page',
                'event_type': expectedEventType,
                'event_target': expectedEventTarget,
                'event_attr1': expectedEventAttr1,
                'event_attr2': expectedEventAttr2};

            element.triggerHandler('click');

            expect(this.TealiumService.track).toHaveBeenCalledWith(eventName, eventData);
        });

        it('should send a track event with the right object for img elements', function() {
            var expectedEventType = 'inputclick';
            var expectedEventTarget = 'input';
            var expectedEventAttr1 = 'foobar';
            var expectedEventAttr2 = undefined;

            var scope = this.$rootScope.$new();
            var element = this.createElement('<input value="' + expectedEventAttr1 + '" data-tealium-link=\'{"page_type": "home", "page_name": "home: Top Nav", "event_name": "return_to_welcome_page"}\'></input>', scope);

            var eventName = 'link';
            var eventData = {
                'page_type': 'home',
                'page_name': 'home: Top Nav',
                'event_name': 'return_to_welcome_page',
                'event_type': expectedEventType,
                'event_target': expectedEventTarget,
                'event_attr1': expectedEventAttr1,
                'event_attr2': expectedEventAttr2};

            element.triggerHandler('click');

            expect(this.TealiumService.track).toHaveBeenCalledWith(eventName, eventData);
        });
    });
});
