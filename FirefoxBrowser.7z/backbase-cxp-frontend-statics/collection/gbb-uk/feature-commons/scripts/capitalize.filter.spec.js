require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

describe('capitalize', function() {
    beforeEach(ngModule(main.name));

    it('should normalize upper case on a string', inject(function(capitalizeFilter) {
        var upperCaseString = 'FOOBAR TEST';

        expect(capitalizeFilter(upperCaseString)).toBe('Foobar Test');
    }));

    it('should normalize lower case on a string', inject(function(capitalizeFilter) {
        var lowerCaseString = 'foobar test';

        expect(capitalizeFilter(lowerCaseString)).toBe('Foobar Test');
    }));

    it('should normalize mixed case on a string', inject(function(capitalizeFilter) {
        var mixedCaseString = 'FooBar TeSt';

        expect(capitalizeFilter(mixedCaseString)).toBe('Foobar Test');
    }));

    it('should normalize mixed cases and ellision on a string', inject(function(capitalizeFilter) {
        var stringWithEllision = 'd\'foobar test';

        expect(capitalizeFilter(stringWithEllision)).toBe('D\'Foobar Test');
    }));
});
