# cmb-digital-bib-pa-user
Service retrieves user's data, profiles, balances, roles and logon part.
