(function (b$) {
    'use strict';
    var Container = b$.bdom.getNamespace('http://backbase.com/2013/portalView').getClass('container');

    function HeaderContainer() {
        Container.apply(this, arguments);
        this.isPossibleDragTarget = true;
    }

    Container.extend(HeaderContainer, {
        localName: 'hsbcContainerHelpLayout',
        namespaceURI: 'templates_hsbcContainerHelpLayout'
    }, {
        template: function(json) {
            var data = {item: json.model.originalItem};
            return window[this.namespaceURI][this.localName](data);
        },

        handlers: {
            preferencesSaved: function(event){
                if(event.target === this) {
                    this.refreshHTML();
                }
            }
        }
    });
})(window.b$);
