require('./index.js');

var modelXML = require('../model.xml');
var indexHTML = require('../templates/top_level.html');
var WidgetMock = require('../test/widget-mocks.js');
var Widget = b$.hsbc.widgets.HsbcWidgetFooter;

describe('HsbcWidgetFooter', function() {
    var widget;

    beforeEach( function(done) {
        widget = new WidgetMock(modelXML, indexHTML);
        widget.initialize();
        setTimeout(done, 50);
    });

    describe('create(__WIDGET__)', function() {

        it('should initialize the widget', function() {
            var copyright = 'copyright text';
            widget.setPreference('copyright', copyright);

            var footer = Widget.create(widget);
            expect(footer.widget.body.querySelector('[data-js="copyright"]').innerText).toBe(copyright);
        });
    });
});
