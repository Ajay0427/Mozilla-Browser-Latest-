package com.hsbc.cmb.gbb.gb.user.pa.user.configuration;

import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runners.model.InitializationError;

import java.io.IOException;

public class CucumberWithProperties extends CucumberWithSerenity {
    static final String API_RESOURCES_CONFIGURATION = "api.resources.configuration";

    public CucumberWithProperties(Class clazz) throws InitializationError, IOException {
        super(clazz);
        PropertiesFile filename = (PropertiesFile) clazz.getAnnotation(PropertiesFile.class);
        System.setProperty(API_RESOURCES_CONFIGURATION, filename.value());
    }
}