### `v1.1.1 - 31/03/2016`

### v1.1.0 - `22/01/2016, 3:36pm`
* LF-622: Enhance column container template to use columnsCSSClasses.

### v1.0.1 - `20/08/2015, 3:49pm`


### v1.0.0 - `20/08/2015, 2:38pm`
#### Initial release for CXP 5.6  


### v0.1.1 - `10/08/2015, 6:09pm`
#### Remove repository from bower.json  
* update model.xml  
* fix column container template  
