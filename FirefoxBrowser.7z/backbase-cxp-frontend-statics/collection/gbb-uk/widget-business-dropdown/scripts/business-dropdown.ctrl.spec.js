require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var headerMock = require('../test/mock/header.json');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('Header DropDown Controller', function() {
    var createController, mockBusinessProfileList;

    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    beforeEach(inject(function($controller, $rootScope, $httpBackend, BusinessDropDownService, lpWidget) {
        createController = function(locals) {
            locals = locals || { $scope: $rootScope.$new() };
            return $controller('BusinessDropDownCtrl as $ctrl', locals);
        };

        mockBusinessProfileList = function() {
            // randomise URL to avoid conflicts between tests
            var selectedBusinessProfileUrl = '/api/selected-business-profile/' + Math.random();
            var selectedBusinessProfileData = Object.create(headerMock);

            $httpBackend.whenGET(selectedBusinessProfileUrl).respond(selectedBusinessProfileData);
            lpWidget.setPreference(BusinessDropDownService.PROPERTIES.SELECTED_BUSINESS_PROFILE_URL, selectedBusinessProfileUrl);
        };
    }));

    describe('$onInit()', function() {
        it('should initialize the instance', inject(function() {
            var ctrl = createController();
            var spy = spyOn(ctrl, 'businessProfileInitialize');
            ctrl.$onInit();

            expect(spy).toHaveBeenCalled();
        }));

        it('should expose links via properties', inject(function(lpWidget, $httpBackend) {
            var changeMyBusinessLinkMock = '/link/change-my-business-link/' + Math.random();
            var returnToWelcomePageLinkMock = '/link/return-to-welcome-page-link/' + Math.random();
            var ctrl = createController();

            lpWidget.setPreference(ctrl.PROPERTIES.CHANGE_MY_BUSINESS_LINK, changeMyBusinessLinkMock);
            lpWidget.setPreference(ctrl.PROPERTIES.RETURN_TO_WELCOME_PAGE_LINK, returnToWelcomePageLinkMock);

            mockBusinessProfileList();
            ctrl.$onInit();
            $httpBackend.flush();
            expect(ctrl.links).toEqual({
                changeMyBusinessLink: changeMyBusinessLinkMock,
                returnToWelcomePageLink: returnToWelcomePageLinkMock
            });
        }));
    });

    describe('businessProfileInitialize()', function() {
        it('should fetch/process a value of SelectedBusinessProfile the controller', inject(function($httpBackend) {
          mockBusinessProfileList();
            var ctrl = createController();

            ctrl.businessProfileInitialize();
            $httpBackend.flush();

            var businessProfile = headerMock;
            expect(ctrl.businessProfile).toEqual({
                otherProfiles: businessProfile.hasOtherProfiles,
                selectedBusiness: businessProfile.selectedProfile.companyName
            });
        }));
    });

});
