package net.serenitybdd.demos.todos.pages.components;

import net.serenitybdd.screenplay.targets.Target;

/**
 * Created by john on 25/09/2015.
 */
public class ToDoList {
    public static Target NEW_TODO = Target.the("New Todo Field").locatedBy("#new-todo");

}
