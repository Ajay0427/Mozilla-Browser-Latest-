/**
 * Widget Model mocks
 * Reads out preferences from model.xml and provides a method to initialize the
 * widget DOM from index.html file
 *
 */

(function (global, factory) {
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = factory();
        return;
    }

    if (typeof define !== 'undefined') {
        define('widget-mocks', factory);
        return;
    }

    global.Widget = factory();
})(this, function() {
    'use strict';

    function toArray(o) {
        return Array.prototype.slice.call(o);
    }

    /**
     * Create XML parser.
     * from http://stackoverflow.com/questions/649614/xml-parsing-of-a-variable-string-in-javascript
     */
    var parseXML = (function() {
        if (typeof window.DOMParser !== 'undefined') {
            return function parse(xml) {
                return (new window.DOMParser()).parseFromString(xml, 'text/xml');
            };
        }

        if (typeof window.ActiveXObject !== 'undefined' && new window.ActiveXObject('Microsoft.XMLDOM')) {
            return function parse(xml) {
                var xmlDoc = new window.ActiveXObject('Microsoft.XMLDOM');
                xmlDoc.async = 'false';
                xmlDoc.loadXML(xml);
                return xmlDoc;
            };
        }

        throw new Error('No XML parser found');
    })();

    function parseHTML(html) {
        var doc = document.implementation.createHTMLDocument('widget');
        doc.documentElement.innerHTML = html;

        return doc;
    }

    function propertyToPreference(property) {
        var name = property.getAttribute('name');
        var label = property.getAttribute('label') || '';
        var valueNode = property.getElementsByTagName('value')[0];
        var rawValue = valueNode.textContent;
        var type = valueNode.getAttribute('type');
        var value;

        switch (type) {
            case 'boolean':
                value = (rawValue === 'true');
                break;

            case 'string':
            default:
                value = rawValue;
        }

        return {
            name: name,
            label: label,
            value: value
        };
    }

    function parsePreferences(model) {
        var xmlProperties = model.getElementsByTagName('property');
        var preferences = {};
        var propertyList = toArray(xmlProperties);

        propertyList.forEach(function(property) {
            var preference = propertyToPreference(property);
            preferences[preference.name] = preference;
        });

        return preferences;
    }

    function getWidgetBody(doc) {
        var rootNode = document.createElement('div');
        var nodes = toArray(doc.body.childNodes);
        var fragment = document.createDocumentFragment();

        if (doc.body.clasName) {
            rootNode.className = doc.body.clasName || '';
            doc.body.clasName = '';
        }

        nodes.forEach(fragment.appendChild, fragment);
        rootNode.appendChild(fragment);

        return rootNode;
    }

    /**
     * @class WidgetModel
     * @private
     */
    function WidgetModel(modelXML) {
        var modelXMLObject = parseXML(modelXML);
        this.preferences = parsePreferences(modelXMLObject);
    }

    WidgetModel.prototype.getPreference = function getPreference(name) {
        if (name in this.preferences) {
            return this.preferences[name].value;
        }

        return null;
    };

    WidgetModel.prototype.setPreference = function(name, value) {
        if (name in this.preferences === false) {
            this.preferences[name] = {
                label: '',
                name: name,
                value: value
            };

            return value;
        }

        return this.preferences[name].value = value;
    };

    /**
     * @class Widget
     * @param {string} modelXML     A string with the content of widget's model.xml file
     */
    function Widget(modelXML, indexHTML) {
        var model = new WidgetModel(modelXML);
        var doc = parseHTML(indexHTML);
        var widgetBody = getWidgetBody(doc);

        this.initializationExpression = doc.body.getAttribute('g:onload');
        this.body = widgetBody;
        this.model = model;
    }

    Widget.prototype.initialize = function() {
        var expression = this.initializationExpression;

        if (!expression) { return; }

        var fn = Function('__WIDGET__', expression);
        try {
            fn.call(window, this);
        } catch (e) {
            throw new Error('Failed to initialize widget: \n' + e.message, e);
        }
    };

    Widget.prototype.getPreference = function(name) {
        return this.model.getPreference(name);
    };

    Widget.prototype.setPreference = function(name, value) {
        return this.model.setPreference(name, value);
    };

    return Widget;
});
