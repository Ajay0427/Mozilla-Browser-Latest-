require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;

describe('Feature commons httpRequestInterceptor', function() {
    var setCookie;

    beforeEach(ngModule(main.name));
    beforeEach(ngModule(function($provide) {
        $provide.value('$window', {
            location: {}
        });

        $provide.value('$document', {});
    }));

    beforeEach(inject(function($document) {
        setCookie = function(cookieName, value) {
            $document.cookie = cookieName + '=' + value;
        };
    }));

    describe('initialize httpRequestInterceptor', function() {
        it('should call the window.location.reload when invoke a 403', inject(function($http, $httpBackend, $window) {
            var CHECK_SPY = $window.location.reload = jasmine.createSpy();
            var CHECK_URL = 'http://example.com' + Math.random();

            $httpBackend.whenGET(CHECK_URL).respond(403);
            $http.get(CHECK_URL);
            $httpBackend.flush();

            expect(CHECK_SPY).toHaveBeenCalled();
        }));

        it('should return the rejection when invoke a 404', inject(function($http, $httpBackend) {
            var CHECK_URL = 'http://example.com' + Math.random();
            var successSpy = jasmine.createSpy('ok');
            var errorSpy = jasmine.createSpy('error');

            $httpBackend.whenGET(CHECK_URL).respond(404, 'Failed...');
            $http.get(CHECK_URL).then(successSpy, errorSpy);
            $httpBackend.flush();

            expect(successSpy).not.toHaveBeenCalled();
            expect(errorSpy).toHaveBeenCalled();
        }));

        it('shouldn\'t call the window.location.reload when invoke a 200', inject(function($http, $httpBackend, $window) {
            var CHECK_SPY = $window.location.reload = jasmine.createSpy();
            var CHECK_URL = 'http://example.com' + Math.random();

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);
            $httpBackend.flush();

            expect(CHECK_SPY).not.toHaveBeenCalled();
        }));

        it('should call the lpCoreBus.publish when invoke a 200', inject(function($http, $httpBackend, lpCoreBus) {
            var CHECK_LPCOREBUS_SPY = spyOn(lpCoreBus, 'publish');
            var CHECK_URL = 'http://example.com' + Math.random();

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);
            $httpBackend.flush();

            expect(CHECK_LPCOREBUS_SPY).toHaveBeenCalledWith('http-call');
        }));
    });

    describe('httpRequestInterceptor with cookies', function() {
        afterEach(inject(function($document) {
            $document.cookie = 'expires=Thu, 01 Jan 1970 00:00:00 GMT';
        }));

        it('should return an empty token when no cookie is there', inject(function($http, $httpBackend, httpRequestInterceptor) {
            var CHECK_URL = 'http://example.com' + Math.random();

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);
            $httpBackend.flush();

            expect(httpRequestInterceptor.token).toBe('');
        }));

        it('should grab the cookie when getting a response', inject(function($http, $httpBackend, httpRequestInterceptor) {
            var CHECK_URL = 'http://example.com' + Math.random();
            var tokenValue = 'b65cca9e-c395-4766-a391-ae69c04a7e1a';

            setCookie('BBXSRF', tokenValue);

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);

            $httpBackend.flush();

            expect(httpRequestInterceptor.token).toBe(tokenValue);
        }));

        it('should grab the cookie and renew the token', inject(function($http, $httpBackend, httpRequestInterceptor) {
            var CHECK_URL = 'http://example.com' + Math.random();
            var tokenValue = 'ae69c04a7e1a-c395-4766-a391-b65cca9e';

            httpRequestInterceptor.token = 'b65cca9e-c395-4766-a391-ae69c04a7e1a';
            setCookie('BBXSRF', tokenValue);

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);

            $httpBackend.flush();

            expect(httpRequestInterceptor.token).toBe(tokenValue);
        }));

        it('should grab the cookie and keep it if similar', inject(function($http, $httpBackend, httpRequestInterceptor) {
            var CHECK_URL = 'http://example.com' + Math.random();
            var tokenValue = 'ae69c04a7e1a-c395-4766-a391-b65cca9e';

            httpRequestInterceptor.token = tokenValue;
            setCookie('BBXSRF', 'ae69c04a7e1a-c395-4766-a391-b65cca9e');

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);

            $httpBackend.flush();

            expect(httpRequestInterceptor.token).toBe(tokenValue);
        }));

        it('should grab the cookie and keep it if similar', inject(function($http, $httpBackend, httpRequestInterceptor) {
            var CHECK_URL = 'http://example.com' + Math.random();
            var tokenValue = 'ae69c04a7e1a-c395-4766-a391-b65cca9e';

            httpRequestInterceptor.token = tokenValue;
            setCookie('BBXSRF', 'ae69c04a7e1a-c395-4766-a391-b65cca9e');

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);

            $httpBackend.flush();


            expect(httpRequestInterceptor.token).toBe(tokenValue);
        }));

        it('should send the X-BBXSRF as a header when the token is defined', inject(function($http, $httpBackend, lpCoreBus) {
            var CHECK_LPCOREBUS_SPY = spyOn(lpCoreBus, 'publish');
            var CHECK_URL = 'http://example.com' + Math.random();

            $httpBackend.whenGET(CHECK_URL).respond(200);
            $http.get(CHECK_URL);
            $httpBackend.flush();

            expect(CHECK_LPCOREBUS_SPY).toHaveBeenCalledWith('http-call');
        }));
    });

});
