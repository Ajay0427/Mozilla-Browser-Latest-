require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('AskAndrewCtrl', function() {
    var createController;

    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
        $provide.value('$window', {});
    }));

    beforeEach(inject(function($controller, $rootScope) {
        createController = function() {
            var locals = { $scope: $rootScope.$new() };
            return $controller('AskAndrewCtrl as $ctrl', locals);
        };
    }));

    describe('$onInit()', function() {
        beforeEach(function() {
            b$.portal.config = b$.portal.config || {};
            b$.portal.config.serverRoot = '/portal';
        });

        it('should initialize the instance', inject(function(lpWidget) {
            var ctrl = createController();
            var preference = ctrl.PREFERENCES.ASK_ANDREW_IMAGE_SOURCE;
            var imageSrc = '$(contextRoot)/media/image.png';
            var expectedImageSrc = '/portal/media/image.png';

            lpWidget.setPreference(preference, imageSrc);

            ctrl.$onInit();

            expect(ctrl.question).toEqual({
                text: ''
            });

            expect(ctrl.assets).toEqual({
                askAndrewImageSource: expectedImageSrc
            });
        }));
    });

    describe('openPopUp()', function() {
        it('should open a popup with Ask Andrew assistant', inject(function(lpWidget, $window) {
            var url = 'http://ask.andrew.com/q={question}';
            var inputText = 'question for assistant';
            var options = 'width=1,height=2';

            var ctrl = createController();
            $window.open = jasmine.createSpy('window.open');

            ctrl.$onInit();
            ctrl.question.text = inputText;

            lpWidget.setPreference(ctrl.PREFERENCES.ASK_ANDREW_URL, url);
            lpWidget.setPreference(ctrl.PREFERENCES.ASK_ANDREW_OPTIONS, options);

            ctrl.openPopUp();

            var urlWithQuestion = url.replace('{question}', encodeURIComponent(inputText));
            expect($window.open).toHaveBeenCalledWith(urlWithQuestion, 'ask-andrew', options);
        }));
    });
});
