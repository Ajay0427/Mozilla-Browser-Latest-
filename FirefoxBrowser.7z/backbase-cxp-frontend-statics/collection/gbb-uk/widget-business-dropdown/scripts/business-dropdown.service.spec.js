require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');
var currentBusinessProfileMock = require('../test/mock/header.json');
var ngModule = window.module;

describe('Header DropDown Service', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    describe('getCurrentBusinessData()', function() {
        it('should fetch a business profile data using URL on widget properties', inject(function(BusinessDropDownService, lpWidget, $rootScope, $httpBackend) {
            var urlToFetch = '/header/' + Math.random();
            var result;
            $httpBackend.expectGET(urlToFetch).respond(200, currentBusinessProfileMock);
            lpWidget.setPreference(BusinessDropDownService.PROPERTIES.SELECTED_BUSINESS_PROFILE_URL, urlToFetch);

            BusinessDropDownService.getCurrentBusinessData().then(function(o) { result = o; });

            $httpBackend.flush();
            expect(result).toEqual({
                result: currentBusinessProfileMock
            });
        }));
});
});
