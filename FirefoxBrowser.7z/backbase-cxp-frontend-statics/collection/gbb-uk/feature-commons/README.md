# backbase-cxp-feature-commons
Common feature for HSBC components
## Information
|  name |  version |  bundle |
|--|:--:|--:|
|  hsbc-services |  1.0.0 |  HSCB |
