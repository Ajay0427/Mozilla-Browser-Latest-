require('angular');
require('angular-mocks');

require('ui');

var modelXML = require('../model.xml');
var indexHTML = require('../index.html');

var main = require('./index');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('LayoutModalCtrl', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var lpWidget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', lpWidget);
    }));

    beforeEach(inject(function($controller, $rootScope, $window) {
        this.$scope = $rootScope;
        this.$window = $window;

        delete this.$window.localStorage.layoutModalShown;

        this.createController = function() {
            return $controller('LayoutModalCtrl as $ctrl', {
                $scope: this.$scope,
                $window: this.$window
            });
        };
    }));

    describe('$onInit', function() {
        it('should not show the modal initially', function() {
            var ctrl = this.createController();

            expect(ctrl.showModal).toBeUndefined();
        });

        it('should show the modal when localStorage.layoutModalShown was not set', function() {
            var ctrl = this.createController();

            ctrl.$onInit();

            expect(ctrl.showModal).toBeTruthy();
        });

        it('should save show state into local storage after showing the modal', function() {
            var ctrl = this.createController();

            ctrl.$onInit();

            expect(this.$window.localStorage.layoutModalShown).toBeTruthy();
        });

        it('should not show the modal if it\'s been shown before', function() {
            var ctrl = this.createController();
            var ctrl2 = this.createController();

            ctrl.$onInit();
            ctrl2.$onInit();

            expect(ctrl.showModal).toBeTruthy();
            expect(ctrl2.showModal).toBeFalsy();
        });
    });
});
