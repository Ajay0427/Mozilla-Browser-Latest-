define('feature-commons', function(require, exports, module) {
    'use strict';

    module.name = 'feature-commons';

    var base = require('base');
    var core = require('core');

    var deps = [
        core.name
    ];

    var placeholder = require('./directives/placeholder.directive');
    var tooltip = require('./tooltip-popover');

    module.exports = base.createModule(module.name, deps)
        .service(require('./http-request-interceptor'))
        .config(['$httpProvider', function($httpProvider) {
            $httpProvider.interceptors.push('httpRequestInterceptor');
        }])
        .config( require('./date.decorator').dateDecorator )
        .directive(require('./popover'))
        .filter(require('./capitalize.filter'))
        .service(require('./utils/hsbc-utils'))
        .directive(require('./components/accordion'))
        .directive(placeholder.directive)
        .controller(placeholder.controller)
        .directive(require('./tooltip'))
        .service(require('./tealium.service'))
        .directive(require('./tealium-link'))
        .directive(tooltip.directive)
        .controller(tooltip.controller);
});
