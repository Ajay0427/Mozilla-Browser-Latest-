/**
 * BB Service
 */
define( function (require, exports) {
    'use strict';

    var PROPERTIES = {
        INBOX_STATUS_URL: 'inboxStatusUrl'
    };

    function transformInboxStatus(response) {
        return {
            hasUnreadMessages: !!response.data.hasUnreadEmail
        };
    }

    /**
     * @constructor
     * @ngInject
     */
    function InboxService(lpWidget, $http) {
        this.widget = lpWidget;
        this.http = $http;
    }

    InboxService.prototype.PROPERTIES = PROPERTIES;

    InboxService.prototype.getInboxStatus = function () {
        var url = this.widget.getPreference(this.PROPERTIES.INBOX_STATUS_URL);

        return this.http.get(url).then(transformInboxStatus);
    };

    exports.InboxService = InboxService;
});
