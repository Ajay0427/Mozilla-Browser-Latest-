require('angular');
require('angular-mocks');

var modelXML = require('../model.xml');
var indexHTML = require('../index.html');

var main = require('./index');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('SessionTimeoutCtrl', function() {
    function pushEventCallback(eventName, callback) {
        var callbackName = callback.name.replace('bound ', '');

        this.registeredEvents[callbackName] = callback;
    }

    beforeEach(ngModule(main.name, function($provide) {
        var lpWidget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', lpWidget);
    }));

    beforeEach(inject(function($q, $rootScope, $controller, $interval) {
        this.$q = $q;
        this.$rootScope = $rootScope;
        this.$window = {location: {href: 'foo'}};

        this.$intervalSpy = jasmine.createSpy('$interval', $interval).and.callThrough();
        this.lpCoreBusSpy = jasmine.createSpyObj('lpCoreBus', ['publish', 'subscribe', 'unsubscribe']);

        this.SessionKeepAliveServiceSpy = jasmine.createSpyObj('SessionKeepAliveService', ['keepAlive']);
        this.SessionLogoffServiceSpy = jasmine.createSpyObj('SessionLogoffService', ['logoff']);

        this.registeredEvents = [];
        this.lpCoreBusSpy.subscribe.and.callFake(pushEventCallback.bind(this));

        this.createController = function(designMode) {
            $controller('SessionTimeoutCtrl as $ctrl', {
                IS_DESIGN_MODE: !!designMode,
                $interval: this.$intervalSpy,
                $scope: this.$rootScope,
                $window: this.$window,
                lpCoreBus: this.lpCoreBusSpy,
                SessionKeepAliveService: this.SessionKeepAliveServiceSpy,
                SessionLogoffService: this.SessionLogoffServiceSpy
            });

            return this.$rootScope.$ctrl;
        };
    }));

    describe('$onInit', function() {
        describe('when not in edit mode', function() {
            it('should subscribe to the messagebus events', function() {
                var expectedMessageBusEvents = [
                    'http-call',
                    'session:keep-alive',
                    'session:logoff'
                ];
                var ctrl = this.createController();

                ctrl.$onInit();

                expect(this.lpCoreBusSpy.subscribe).toHaveBeenCalledWith(expectedMessageBusEvents[0], jasmine.any(Function));
                expect(this.lpCoreBusSpy.subscribe).toHaveBeenCalledWith(expectedMessageBusEvents[1], jasmine.any(Function));
                expect(this.lpCoreBusSpy.subscribe).toHaveBeenCalledWith(expectedMessageBusEvents[2], jasmine.any(Function));
            });

            it('should reset the timeout countdown', function() {
                var ctrl = this.createController();
                var expectedServerTimeout = 720;

                ctrl.$onInit();

                expect(ctrl.serverTimeout).toEqual(expectedServerTimeout);
            });
        });
        describe('when in edit mode', function() {
            it('should not subscribe to the messagebus events', function() {
                var messageBusEvents = [
                    'http-call',
                    'session:keep-alive',
                    'session:logoff'
                ];
                var ctrl = this.createController(true);

                ctrl.$onInit();

                expect(this.lpCoreBusSpy.subscribe).not.toHaveBeenCalledWith(messageBusEvents[0], jasmine.any(Function));
                expect(this.lpCoreBusSpy.subscribe).not.toHaveBeenCalledWith(messageBusEvents[1], jasmine.any(Function));
                expect(this.lpCoreBusSpy.subscribe).not.toHaveBeenCalledWith(messageBusEvents[2], jasmine.any(Function));
            });

            it('should not reset the timeout countdown', function() {
                var ctrl = this.createController();
                var expectedServerTimeout = 720;

                ctrl.$onInit();

                expect(ctrl.serverTimeout).toEqual(expectedServerTimeout);
            });
        });
    });

    describe('$onDestroy', function() {
        it('should cancel any open $interval timers', function() {
            spyOn(this.$intervalSpy, 'cancel');
            var ctrl = this.createController();

            ctrl.$onInit();
            ctrl.$onDestroy();

            expect(this.$intervalSpy.cancel.calls.count()).toEqual(2);
        });

        it('should unsubscibe the subscribed messagebus events', function() {
            var expectedMessageBusEvents = [
                'http-call',
                'session:keep-alive',
                'session:logoff',
            ];
            var ctrl = this.createController();

            ctrl.$onInit();
            ctrl.$onDestroy();

            expect(this.lpCoreBusSpy.unsubscribe).toHaveBeenCalledWith(expectedMessageBusEvents[0], this.registeredEvents.resetTimeoutCountdown);
            expect(this.lpCoreBusSpy.unsubscribe).toHaveBeenCalledWith(expectedMessageBusEvents[1], this.registeredEvents.keepAlive);
            expect(this.lpCoreBusSpy.unsubscribe).toHaveBeenCalledWith(expectedMessageBusEvents[2], this.registeredEvents.logoff);
        });
    });

    describe('setTimeLeftHeartbeat', function() {
        var sessionHeartbeatInterval;
        var sessionServerTimeout;

        beforeEach(function() {
            sessionHeartbeatInterval = 1;
            sessionServerTimeout = 720;
        });

        it('should set the TimeLeft heartbeat to the prefered value', function() {
            var ctrl = this.createController();
            var expectedSessionHeartbeatInterval = sessionHeartbeatInterval * 1000;

            ctrl.$onInit();

            expect(this.$intervalSpy).toHaveBeenCalledWith(jasmine.any(Function), expectedSessionHeartbeatInterval);
        });

        it('should decrease the serverTimeout property on every timeleft interval', function() {
            var ctrl = this.createController();
            var expectedServerTimeout = sessionServerTimeout - 1;

            ctrl.$onInit();
            this.$intervalSpy.flush(sessionHeartbeatInterval * 1000);

            expect(ctrl.serverTimeout).toEqual(expectedServerTimeout);
        });

        it('should transmit the [TIME_LEFT] messagebus event on every timeleft interval', function() {
            var timeLeftEvent = 'session:time-left';
            var ctrl = this.createController();

            ctrl.$onInit();
            this.$intervalSpy.flush(sessionHeartbeatInterval * 1000);

            expect(this.lpCoreBusSpy.publish).toHaveBeenCalledWith(timeLeftEvent, ctrl.serverTimeout);
        });
    });

    describe('setBibHeartbeat', function() {
        var sessionKeepAliveBibInterval;

        beforeEach(function() {
            sessionKeepAliveBibInterval = 15;
        });

        it('should set the BIB heartbeat to the prefered value', function() {
            var expectedSessionKeepAliveBibInterval = sessionKeepAliveBibInterval * 1000;
            var ctrl = this.createController();

            ctrl.$onInit();

            expect(this.$intervalSpy).toHaveBeenCalledWith(jasmine.any(Function), expectedSessionKeepAliveBibInterval);
        });

        it('should call the SessionKeepAliveService every single heartbeat to keep BIB alive', function() {
            var ctrl = this.createController();

            ctrl.$onInit();
            this.$intervalSpy.flush(sessionKeepAliveBibInterval * 1000);

            expect(this.SessionKeepAliveServiceSpy.keepAlive).toHaveBeenCalledWith('bib');
        });
    });

    describe('messageBus keepAlive', function() {
        var sessionServerTimeout;

        beforeEach(function() {
            sessionServerTimeout = 720;
        });

        it('should call the SessionKeepAliveService to keep GBBP alive', function() {
            var ctrl = this.createController();

            ctrl.$onInit();
            this.registeredEvents.keepAlive();

            expect(this.SessionKeepAliveServiceSpy.keepAlive).toHaveBeenCalledWith('gbbp');
        });

        it('should reset the timeout countdown to the prefered value', function() {
            var ctrl = this.createController();
            var expectedSessionServerTimeout = sessionServerTimeout;
            ctrl.serverTimeout = 1;

            ctrl.$onInit();
            this.registeredEvents.keepAlive();

            expect(ctrl.serverTimeout).toEqual(expectedSessionServerTimeout);
        });
    });

    describe('logoff', function() {
        var sessionLoggedoffUrl;

        beforeEach(function() {
            sessionLoggedoffUrl = '/bibportalserver/public/loggedout';

            this.SessionLogoffServiceSpy.logoff.and.returnValue(this.$q.resolve());
        });

        it('should destroy the widget', function() {
            var ctrl = this.createController();

            spyOn(ctrl, '$onDestroy');

            ctrl.$onInit();
            this.registeredEvents.logoff();

            expect(ctrl.$onDestroy).toHaveBeenCalled();
        });

        it('should instruct the SessionLogoffService to logoff', function() {
            var ctrl = this.createController();

            ctrl.$onInit();
            this.registeredEvents.logoff();

            expect(this.SessionLogoffServiceSpy.logoff).toHaveBeenCalled();
        });

        it('should redirect the user to the [SESSION_LOGGEDOFF_URL] page after logoff resolved', function() {
            var expectedSessionLoggedoffUrl = sessionLoggedoffUrl;
            var ctrl = this.createController();
            ctrl.$onInit();

            this.registeredEvents.logoff();
            this.$rootScope.$apply();

            expect(this.$window.location.href).toEqual(expectedSessionLoggedoffUrl);
        });

        it('should redirect the user to the [SESSION_LOGGEDOFF_URL] page after logoff rejected', function() {
            this.SessionLogoffServiceSpy.logoff.and.callFake(function() {
                return this.$q.reject();
            }.bind(this));

            var expectedSessionLoggedoffUrl = sessionLoggedoffUrl;
            var ctrl = this.createController();
            ctrl.$onInit();

            this.registeredEvents.logoff();
            this.$rootScope.$apply();

            expect(this.$window.location.href).toEqual(expectedSessionLoggedoffUrl);
        });
    });
});
