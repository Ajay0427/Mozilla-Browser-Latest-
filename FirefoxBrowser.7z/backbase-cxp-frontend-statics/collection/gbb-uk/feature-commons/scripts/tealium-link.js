/**
 * Tealium
 */
define( function (require, exports) {
    'use strict';

    /**
     * @constructor
     * @ngInject
     */

    // @private
    function getEventType(target) {
        var eventType = '' + (target.nodeName.toLowerCase() || target.localName || target.tagName.toLowerCase());

        if (eventType === 'a') {
            eventType = 'link';
        } else if (eventType === 'img') {
            eventType = 'image';
        }

        return eventType;
    }

    // @private
    function getEventText(target) {
        var eventText = target.title || target.innerText || target.innerHTML.trim();

        if (eventText === '' && (target.value && target.value !== '')) {
            eventText = target.value;
        } else if (eventText === '' && (target.alt && target.alt !== '')) {
            eventText = target.alt;
        }

        return eventText;
    }

    // @private
    function getEventSource(eventType, target) {
        var eventSource;

        switch (eventType) {
            case 'link':
                eventSource = target.href;
                break;

            case 'button':
                eventSource = target.type || '';
                break;

            case 'input':
                break;

            default:
                if (target.src && target.src !== '') {
                    eventSource = target.src;
                }
                break;
        }

        return eventSource;
    }

    function tealiumLink(TealiumService) {
        return {
            restrict: 'A',

            link: function(scope, element, attributes) {
                element.bind('click', function(e) {
                    var dataLayer = {};
                    var target = e.target, eventType;

                    if (target.nodeName) {
                        eventType = getEventType(target);
                        dataLayer['event_type'] = eventType + 'click';
                    }

                    dataLayer['event_target'] = eventType;
                    dataLayer['event_attr1'] = getEventText(target);
                    dataLayer['event_attr2'] = getEventSource(eventType, target);

                    TealiumService.track('link', angular.extend(angular.fromJson(attributes.tealiumLink), dataLayer));
                });
            }
        };
    }

    exports.tealiumLink = tealiumLink;
});
