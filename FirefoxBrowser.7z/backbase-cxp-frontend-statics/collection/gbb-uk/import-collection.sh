cd bower_components;
ls -1 | grep template | xargs -n1 -i bb import-item --auto -t {} $@;
ls -1 | grep -v template | xargs -n1 -i bb import-item --auto -t {} $@;
cd ..;

gulp clean && gulp build && gulp hsbc-theme:fonts:copy;

if [ "$?" = "0" ]; then
    ls -1 | grep template | xargs -n1 -i bb import-item -t {} $@;
    ls -1 | grep -E -e "^(feature|hsbc|widget|container)" | xargs -n1 -i bb import-item -t {} $@;

else
    echo "Build failed!";
    exit 1;

fi
