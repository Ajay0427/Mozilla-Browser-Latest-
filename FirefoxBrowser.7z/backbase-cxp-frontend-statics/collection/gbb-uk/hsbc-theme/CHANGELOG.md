### `v1.0.11 - 12/04/2016`
* LF-902: Add watch script
* LF-902: Divide the CSS in several files

### `v1.0.10 - 06/04/2016`
* LF-902: Add a dist folder that does not break IE9

### `v1.0.9 - 30/03/2016`
* LF-928: Use @navbar-profile-logout-button-bg variable for logout button.

### `v1.0.8 - 25/03/2016`
* Resolve conflicts
* Bump version.
* LF-928: Styles for sign-in button.
* LF-922 Removed overwrite.less as the contents of this file were already harvested by initial theme creation
* LF-922 Use font-weight 500 for buttons
* LF-922 Added newly added fonts to dist, as bb cli does not do this automatically
* LF-922 Fixed styling for navigation bar, normal and active looks much better. Added font medium, as bold was too heavy
* LF-927 Removed the red color, also removed overwrite.less from base.less as all those styles are duplicated in theme.less

### `v1.0.7 - 25/03/2016`
* LF-926: Remove padding around columns on mobile size

### `v1.0.6 - 24/03/2016`
* LF-928: Navbar profile addition improvements.

### `v1.0.5 - 21/03/2016`
* LF-883: Profile block vertical align.

### `v1.0.4 - 09/03/2016`
* LF-694: Cleaned important

### `v1.0.3 - 04/03/2016`
* LF-817 Update base theme

### `v1.0.2 - 29/02/2016`
* LPMAINT-66: Changed design mode navbar workaround

### v1.0.1
- Add icon classes to the theme
