package net.serenitybdd.demo;

import net.serenitybdd.jbehave.SerenityStory;

/**
 * User: YamStranger
 * Date: 12/10/15
 * Time: 7:25 AM
 */
public class UpdateADefinition extends SerenityStory {
}
