/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PROPERTIES = {
        SELECTED_BUSINESS_PROFILE_URL: 'selectedBusinessProfileUrl'
    };

    // @private
    function getData(response) {
        return response.data;
    }

    // @private
    function transformCurrentBusinessResponse(response) {
        return {
            result: response
        };
    }


    /**
     * @ngInject
     * @service AccountOverviewService
     * @constructor
     */
    function BusinessDropDownService($http, lpWidget) {
        this.http = $http;
        this.widget = lpWidget;
    }

    /**
     * Widget properties used by this service
     * @property PROPERTIES
     * @type {Object}
     */
    BusinessDropDownService.prototype.PROPERTIES = PROPERTIES;

    /**
     * @return {Promise<Array<Account>>}
     */
    BusinessDropDownService.prototype.getCurrentBusinessData = function() {
        var url = this.widget.getPreference(this.PROPERTIES.SELECTED_BUSINESS_PROFILE_URL);
        return this.http.get(url).then(getData).then(transformCurrentBusinessResponse);
        // TODO error handling!
    };

    exports.BusinessDropDownService = BusinessDropDownService;
});
