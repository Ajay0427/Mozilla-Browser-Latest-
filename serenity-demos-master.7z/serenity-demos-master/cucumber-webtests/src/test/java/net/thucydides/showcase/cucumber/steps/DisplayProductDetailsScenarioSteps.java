package net.thucydides.showcase.cucumber.steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import net.thucydides.showcase.cucumber.pages.HomePage;
import net.thucydides.showcase.cucumber.steps.serenity.BuyerSteps;

public class DisplayProductDetailsScenarioSteps {

    @Steps
    BuyerSteps buyer;
    HomePage homePage;


    @Given("I have logged into BIB")
    public void givenILoggedintoBIB() {
        homePage.open();
        buyer.opens_home_page();
        buyer.protectiopnPopup();
        buyer.setUserName();

    }

    @Given("I have searched for '(.*)' in my region")
    public void givenIHaveSearchedFor(String searchTerm) {

        buyer.clicksOnLoan();

    }

    @When("I have clicked on Loan")
    public void whenclickedonLoan(int number) {
        buyer.clicksOnLoan();

        /*
        ListingItem selectedListingItem = buyer.selects_listing(number);
        Serenity.setSessionVariable(SELECTED_LISTING).to(selectedListingItem);*/
    }

    @When("I have clicked on Payments")
    public void whenIPayments() {
        buyer.clicksOnMakePayment();

    }
    @Then("I should see product description and price on the details page '(.*)'")
    public void thenIShouldSeeProductDescriptionAndPriceOnTheDetailsPage(String searchTerm) {
        buyer.shouldSeePageTitleContaining(searchTerm);
        buyer.isOnGBBLandingPage();
         /*ListingItem selectedListingItem = (ListingItem) Serenity.sessionVariableCalled(SELECTED_LISTING);
         buyer.should_see_product_details_for(selectedListingItem);*/
    }

    @Then("I should see a product rating")
    public void shouldSeeProductRating() {
        buyer.should_see_product_rating();
    }

    @Then("I should see social media links")
    public void shouldSeeSocialMediaLinks() {
        buyer.should_see_facebook_link();
        buyer.should_see_twitter_link();
        buyer.should_see_tumblr_link();
    }
}
