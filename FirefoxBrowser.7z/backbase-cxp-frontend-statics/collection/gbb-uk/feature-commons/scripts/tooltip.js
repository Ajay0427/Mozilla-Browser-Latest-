/**
 * Tooltip
 */
define( function (require, exports) {
    'use strict';

    require('bootstrap');

    /**
     * @constructor
     * @ngInject
     */
     function tooltip() {
         return {
             restrict: 'A',
             link: function(scope, element){
                 element.tooltip({html: true, template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><button type="button" aria-label="Close tooltip" class="tooltip-close btn btn-link">&times;</button><div class="tooltip-inner"></div></div>'});
                 angular.element('body').on('hidden.bs.popover', function (e) {
                    angular.element(e.target).data('bs.popover').inState = { click: false, hover: false, focus: false };
                 });
                 element.on('mouseenter', function(){
                    var tooltipElement = this.parentElement.querySelector('.tooltip');
                    angular.element('.tooltip').not(tooltipElement).tooltip('hide');
                 });

                 element.on('shown.bs.popover', function(e) {
                    //get the actual shown popover
                    var popover = angular.element(e.target).data('bs.popover').tip();

                    //find the close button
                    var closeButton = popover.find('.tooltip-close');

                    closeButton.click(function(){
                        element.popover('hide');
                    });
});

             }
         };
     };

    exports.tooltip = tooltip;
});
