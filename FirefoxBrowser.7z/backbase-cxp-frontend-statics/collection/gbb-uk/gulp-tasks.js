'use strict';

var minimist = require('minimist');
var argv = minimist(process.argv.slice(2));
process.argv = process.argv.filter(p => !p.startsWith('-'));

var gulp = require('gulp');
var NodePath = require('path');
var karma = require('karma');
var helpers = require('./gulp-helpers');
var BuildScope = helpers.BuildScope;
var Task = helpers.Task;
var noop = function() {};

/**
 * Lint LESS files
 */
function lintLess(context) {
    var lesshint = require('gulp-lesshint');
    var input = context.getPath('styles/**/*.less');
    var linterOptions = {
        configPath: NodePath.join(__dirname, '.lesshintrc')
    };

    return gulp.src(input)
        .pipe(lesshint(linterOptions))
        .pipe(lesshint.reporter())
        .pipe(helpers.lessFailOnWarning({ maxWarnings: 0 }));
}

function lintJs(context) {
    var eslint = require('gulp-eslint');
    var input = context.getPath('scripts/**/*.js');
    var linterOptions = {
        configFile: NodePath.join(__dirname, '.eslintrc.json')
    };

    return gulp.src(input)
        .pipe(eslint(linterOptions))
        .pipe(eslint.format())
        .pipe(eslint.failAfterError());
}
/**
 * Copy font files to dist folder
 * @param  {[type]} context [description]
 * @return {[type]}         [description]
 */
function copyFonts(context) {
    var input = context.getPath('styles/fonts/**/*');
    var output = context.getPath('dist/styles/fonts/');

    gulp.src(input)
        .pipe(gulp.dest(output));
}

/**
 * Build LESS files
 * Expects 'base.less' to be present inside 'styles/' folder
 * Outputs 'base.css' and 'base.min.css' on 'dist/' folder
 */
function buildLess(context, done) {
    var less = require('gulp-less');
    var rename = require('gulp-rename');

    var themePath = NodePath.join(__dirname, 'hsbc-theme', 'styles');
    var bootstrapPath = NodePath.join(__dirname, 'node_modules', 'bootstrap-less', 'bootstrap');

    var importPaths = [
        context.getPath('styles'),
        themePath,
        bootstrapPath
    ];

    var lessOptions = {
        paths: importPaths
    };

    var input = context.getPath('styles/base.less');
    var output = context.getPath('dist/styles');

    function onError(error) {
        var message = error.message.split('in file')[0];
        var extract = '> ' + error.extract.join('\n> ');

        console.log('\nIn %s (%d:%d):\n\n  %s\n\n%s', error.fileName, error.line, error.column, message, extract);
        done(new Error(message));
    }

    return gulp.src(input)
        .pipe(less(lessOptions).on('error', onError))
        .pipe(gulp.dest(output))
        .pipe(rename({ suffix: '.min' }))
        .pipe(gulp.dest(output));
}

/**
 * Remove all files from 'dist' folder
 */
function cleanDist(context) {
    var del = require('del');
    return del([
        context.getPath('dist/**/*')
    ]);
}

/**
 * Bundle JS files into one
 */
function buildScripts(options, context, done) {
    var input = context.getPath('scripts/index.js');
    var output = context.getPath('dist/scripts');
    var baseWebpackConf = require('./webpack.conf.js');
    var webpack = require('webpack');
    var webpackStream = require('webpack-stream');

    var webpackConf = baseWebpackConf({
        includeBuildPlugins: true,
        name: context.name,
        entry: input,
        output: {
            path: output,
            filename: context.outputName || 'index.js',
            publicPath: '/',
            libraryTarget: 'umd',
            library: 'main',
            umdNamedDefine: false
        }
    }, true);

    if (options.minify) {
        webpackConf.plugins.push(
            new webpack.optimize.UglifyJsPlugin({
                sourceMaps: true,
                mangle: {
                    except: ['exports', 'require']
                },
                compress: {
                    drop_debugger: true
                }
            })
        );
    }

    return gulp.src(input)
        .pipe(webpackStream(webpackConf).on('error', done))
        .pipe(gulp.dest(output));
}

function runTests(context) {
    var karmaBaseConfig = require('./karma.conf.js');

    var karmaConfig = karmaBaseConfig({
        files: [
            context.getPath('test/unit/index.js')
        ],
        singleRun: !argv.watch
    });

    return new karma.Server(karmaConfig).start();
}

function isTestTask(task) {
    return task.type === Task.TEST;
}

function runCollectionTests(contextList) {
    var karmaBaseConfig = require('./karma.conf.js');
    var entryFilePath = './.webpack.test-bundle.js';
    var FS = require('fs');
    var template = 'define("main", function(require) {window.$=window.jQuery=require("jquery");require("angular");require("angular-cookies");require("angular-mocks"); var mock = require("mock"); window.gadgets = mock.gadgets; window.b$ = window.b$ || {}; window.b$.portal = mock.Portal(); %s });require("main");';
    var entryFileContent = [];

    contextList.forEach(function (context) {
        var testTask = context.tasks.filter(isTestTask);
        if (!testTask.length) { return; }

        var filePath = './' + testTask[0].scope + '/test/unit/index.js';

        if (!FS.existsSync(filePath)) { return; }

        entryFileContent.push('try{require("' + filePath + '");}catch(e){console.log(e.message, e.stack);}');
    });

    FS.writeFileSync(entryFilePath, template.replace('%s', entryFileContent.join('')));

    var karmaConfig = karmaBaseConfig({
        files: [entryFilePath],
        singleRun: !argv.watch
    });

    return new karma.Server(karmaConfig).start();
}

/**
 * Map of all available tasks for a component
 * @type {Object}
 */
var TASKS = {
    'less': { fn: buildLess, watcher: 'styles/**/*.less', type: Task.BUILD, dependencies: ['less:lint'] },
    'less:lint': { fn: lintLess, type: Task.LINT },
    'js:build': { fn: buildScripts.bind(null, { minify: false }), watcher: 'scripts/**/*.js', type: Task.BUILD, dependencies: ['js:lint'] },
    'js:minify': { fn: buildScripts.bind(null, { minify: true }), type: Task.BUNDLE },
    'js:lint': { fn: lintJs, type: Task.LINT },
    'fonts:copy': { fn: copyFonts, type: Task.BUILD },
    'clean': { fn: cleanDist, type: Task.CLEAN },
    'test': { fn: runTests, type: Task.TEST },
    'build': { fn: noop, dependencies: ['js:build', 'less'] }
};

/**
 * Creates tasks to a given component path
 * @param  {String} targetDir      Directory of a component to build
 * @param  {Object} options        Name of tasks to create
 * @param {Array<String>} options.tasks     Tasks to build in this directory
 * @return {Array<Task>}           Tasks scoped to that component
 */
function createTasksForTarget(options) {
    var targetDir = options.targetDir;

    if (!targetDir) {
        throw new Error('Target directory to create tasks not specified');
    }

    return options.tasks.map(createTask);

    function createTask(taskName) {
        var baseOptions = TASKS[taskName];

        var taskOptions = {
            name: taskName,
            watcher: baseOptions.watcher,
            runner: baseOptions.fn,
            dependencies: baseOptions.dependencies,
            type: baseOptions.type
        };

        Object.assign(taskOptions, options);

        return new Task(taskOptions);
    }
}

/**
 * Setup build/watch tasks on all components. Controls the whole collection
 */
function setupCollectionTasks() {
    var componentFolders = helpers.findComponentFolders();
    var components = componentFolders.map(setupScopedComponentTasks);
    var scope = new BuildScope(components);

    helpers.setupScopeTasks(scope);
    gulp.task('test:run-all', function () {
        return runCollectionTests(components);
    });
}

function getBuildOptions(targetDir) {
    var options = helpers.readBuildRc(targetDir);
    options.tasks = options.tasks || Object.keys(TASKS);
    options.targetDir = targetDir;

    return options;
}

/**
 * Setup build/watch tasks on a single component
 * @param {String} targetDir        Directory to a component
 */
function setupComponentTasks(targetDir, extraTasks) {
    var options = getBuildOptions(targetDir);
    var tasks = createTasksForTarget(options, extraTasks);
    var scope = new BuildScope(tasks);

    helpers.setupScopeTasks(scope);
}

/**
 * Sets up a chain of tasks inside a given component
 * @param  {Component} component        Component metadata
 * @return {BuildScope}                 Scope with all tasks
 */
function setupScopedComponentTasks(component) {
    var options = getBuildOptions(component.path);
    var tasks = createTasksForTarget(options);
    var scope = new BuildScope(tasks, component.name);

    return scope;
}

module.exports = {
    gulp: gulp,
    createTasks: setupComponentTasks,
    setupCollectionTasks: setupCollectionTasks
};
