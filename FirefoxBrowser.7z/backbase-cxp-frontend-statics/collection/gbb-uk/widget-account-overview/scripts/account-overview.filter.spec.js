
require('angular');
require('angular-mocks');

var accountMock = require('../test/mocks/UK/accounts.json');
var recentTransactionsMock = require('../test/mocks/UK/recent-transactions.json');
var main = require('./index');
var ngModule = window.module;

describe('Account Overview Filter', function() {
    beforeEach(ngModule(main.name));

    describe('Account number filter', function() {
        it('should filter the short account number by spaces after the fourth number', inject(function(accountNumberFilter) {
            var accountNumber = '11005006';
            var accountNumberAfterFilter = accountNumberFilter(accountNumber);
            expect(accountNumberAfterFilter).toEqual('1100 5006');
        }));
        it('should filter the long account number by spaces after the fourth number', inject(function(accountNumberFilter) {
            var accountNumber = '4864831156716198';
            var accountNumberAfterFilter = accountNumberFilter(accountNumber);
            expect(accountNumberAfterFilter).toEqual('4864 8311 5671 6198');
        }));
        it('should not filter the account number with letters', inject(function(accountNumberFilter) {
            var accountNumber = 'GB11005006';
            var accountNumberAfterFilter = accountNumberFilter(accountNumber);
            expect(accountNumberAfterFilter).toEqual('GB11005006');
        }));
        it('shouldn\'t filter the account number when it is undefined', inject(function(accountNumberFilter) {
            var accountNumber = undefined;
            var accountNumberAfterFilter = accountNumberFilter(accountNumber);
            expect(accountNumberAfterFilter).toEqual(undefined);
        }));
    });

    describe('Amount filter', function() {
        it('should filter the amount  with correct format', inject(function(amountFilter) {
            var accountList = accountMock;
            var accountDetails = accountList.result.accounts[0].balance.value;
            var balanceAfterFilter = amountFilter(accountDetails);
            var endResultDecimal = Math.abs(accountDetails).toFixed(2);
            var endResult = endResultDecimal.split('.')[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + '.' + endResultDecimal.split('.')[1];
            expect(balanceAfterFilter).toEqual(endResult);
        }));

        it('should filter the negative amount to a postive balance with correct format', inject(function(amountFilter) {
            var accountList = accountMock;
            var accountDetails = accountList.result.accounts[1].balance.value;
            var amountAfterFilter = amountFilter(accountDetails);
            var endResultDecimal = Math.abs(accountDetails).toFixed(2);
            var endResult = endResultDecimal.split('.')[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + '.' + endResultDecimal.split('.')[1];
            expect(amountAfterFilter).toEqual(endResult);
        }));

        it('shouldn\'t filter the amount when value is undefined', inject(function(amountFilter) {
            var balanceAfterFilter = amountFilter(undefined);
            expect(balanceAfterFilter).toEqual('');
        }));
    });

    describe('balance filter', function() {
        it('should filter the business account balance with correct format', inject(function(balanceFilter) {
           var accountList = accountMock;
           var accountDetails = accountList.result.accounts[0].balance.value;
           var amountAfterFilter = balanceFilter(accountDetails);
           var endResultDecimal = Math.abs(accountDetails).toFixed(2);
           var endResult = endResultDecimal.split('.')[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + '.' + endResultDecimal.split('.')[1];
           expect(amountAfterFilter).toEqual(endResult);
       }));
       it('should filter the negative credit card balance to a postive balance with correct format', inject(function(balanceFilter) {
           var accountList = accountMock;
           var accountDetails = accountList.result.accounts[1].balance.value;
           var balanceAfterFilter = balanceFilter(accountDetails);
           var endResultDecimal = Math.abs(accountDetails).toFixed(2);
           var endResult = endResultDecimal.split('.')[0].replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,') + '.' + endResultDecimal.split('.')[1];
           expect(balanceAfterFilter).toEqual(endResult);
       }));
       it('should filter the balance null to N/A of an account', inject(function(balanceFilter) {
           var accountDetails = null;
           var balanceAfterFilter = balanceFilter(accountDetails);
           expect(balanceAfterFilter).toEqual('N/A');
       }));
    });

    describe('cardholderName filter', function() {
        it('should filter the cardholder name with correct format', inject(function(cardholderNameFilter) {
            var cardholderName = 'FCARELAUNCHWMMEZJ,F/MR';
            var cardholderNameAfterFilter = cardholderNameFilter(cardholderName);
            var endResult = 'MR F FCARELAUNCHWMMEZJ';
            expect(cardholderNameAfterFilter).toEqual(endResult);
        }));
        it('shouldn\'t filter the cardholder name when it doesn\'t have / or ,', inject(function(cardholderNameFilter) {
          var cardholderName = 'MR F FCARELAUNCHWMMEZJ';
          var cardholderNameAfterFilter = cardholderNameFilter(cardholderName);
          expect(cardholderNameAfterFilter).toEqual(cardholderName);
        }));
    });

    describe('DR or CR filter details', function() {
        it('should display the filtered balance when balance is 0', inject(function(drOrCrDetailsFilter) {
            var DrOrCrAfterFilter = drOrCrDetailsFilter(0, true);

            expect(DrOrCrAfterFilter).toEqual('');
        }));
        it('should display CR after the filter balance when isCardHolder is positive', inject(function(drOrCrDetailsFilter) {
            var DrOrCrAfterFilter = drOrCrDetailsFilter(2, true);

            expect(DrOrCrAfterFilter).toEqual(' CR');
        }));
        it('should only display the filtered balance without negative sign when isCardHolder is true', inject(function(drOrCrDetailsFilter) {
            var DrOrCrAfterFilter = drOrCrDetailsFilter(-3, true);

            expect(DrOrCrAfterFilter).toEqual('');
        }));
        it('should display DR after the filtered balance when isCardHolder is negative', inject(function(drOrCrDetailsFilter) {
            var DrOrCrAfterFilter = drOrCrDetailsFilter(-3, false);

            expect(DrOrCrAfterFilter).toEqual(' DR');
        }));
        it('should display the filtered balance when isCardHolder is false', inject(function(drOrCrDetailsFilter) {
            var DrOrCrAfterFilter = drOrCrDetailsFilter(2, false);

            expect(DrOrCrAfterFilter).toEqual('');
        }));
    });

    describe('DR or CR filter list', function() {
        it('should display nothing when balance is 0', inject(function(drOrCrListFilter) {
            var DrOrCrAfterFilter = drOrCrListFilter(0, true);

            expect(DrOrCrAfterFilter).toEqual('');
        }));
        it('should display CR when isCardHolder is true', inject(function(drOrCrListFilter) {
            var DrOrCrAfterFilter = drOrCrListFilter(2, true);

            expect(DrOrCrAfterFilter).toEqual('CR');
        }));
        it('should display DR and the amount without negative sign when isCardHolder is true', inject(function(drOrCrListFilter) {
            var DrOrCrAfterFilter = drOrCrListFilter(-3, true);

            expect(DrOrCrAfterFilter).toEqual('DR');
        }));
        it('should display DR when isCardHolder is false', inject(function(drOrCrListFilter) {
            var DrOrCrAfterFilter = drOrCrListFilter(-3, false);

            expect(DrOrCrAfterFilter).toEqual('DR');
        }));
        it('should display the amount when isCardHolder is false', inject(function(drOrCrListFilter) {
            var DrOrCrAfterFilter = drOrCrListFilter(2, false);

            expect(DrOrCrAfterFilter).toEqual('');
        }));
    });

    describe('Description Concat filter', function() {
        it('shouldn\'t concat the descriptions when transaction is undefined', inject(function(descriptionConcatFilter) {
            var DescriptionAfterFilter = descriptionConcatFilter(undefined);

            expect(DescriptionAfterFilter).toEqual('');
        }));
        it('should concat the descriptions to each other', inject(function(descriptionConcatFilter) {
            var recentTransactions = recentTransactionsMock;
            var recentTransaction = recentTransactions.transactions[0];
            var DescriptionAfterFilter = descriptionConcatFilter(recentTransaction);

            expect(DescriptionAfterFilter).toEqual('400443 41100238 INTERNET TRANSFER');
        }));
        it('should return undefined when descriptions are not defined', inject(function(descriptionConcatFilter) {
            var recentTransaction = {
                description1: null,
                description2: null,
                description3: null,
                description4: null,
                description5: null
            };
            var DescriptionAfterFilter = descriptionConcatFilter(recentTransaction);

            expect(DescriptionAfterFilter).toEqual('');
        }));
        it('should concat the descriptions to each other', inject(function(descriptionConcatFilter) {
            var recentTransaction = {
                description1: '1',
                description2: '2',
                description3: '3',
                description4: '4',
                description5: '5'
            };
            var DescriptionAfterFilter = descriptionConcatFilter(recentTransaction);

            expect(DescriptionAfterFilter).toEqual('1 2 3 4 5');
        }));
    });

    describe('Sorttype number filter', function() {
        it('should filter the sorttype number by hyphen after the second and fourth number', inject(function(sortTypeNumberFilter) {
            var sorttypeNumber = '400520';
            var sorttypeNumberAfterFilter = sortTypeNumberFilter(sorttypeNumber);
            expect(sorttypeNumberAfterFilter).toEqual('40-05-20');
        }));
        it('shouldn\'t filter the sorttype number by hyphen when it is undefined', inject(function(sortTypeNumberFilter) {
            var sorttypeNumber = undefined;
            var sorttypeNumberAfterFilter = sortTypeNumberFilter(sorttypeNumber);
            expect(sorttypeNumberAfterFilter).toEqual(undefined);
        }));
    });

    describe('Time filter', function() {
        it('should filter the time when seconds are in the value', inject(function(timeFilter) {
            var time = '11:11:11';
            var timeAfterFilter = timeFilter(time);
            expect(timeAfterFilter).toEqual('11:11');
        }));
        it('shouldn\'t filter time when no seconds are in the value', inject(function(timeFilter) {
            var time = '12:34';
            var timeAfterFilter = timeFilter(time);
            expect(timeAfterFilter).toEqual('12:34');
        }));
        it('should filter the time when it is undefined', inject(function(timeFilter) {
            var time = undefined;
            var timeAfterFilter = timeFilter(time);
            expect(timeAfterFilter).toEqual(undefined);
        }));
    });
});
