/**
 * Controllers
 * @module controllers
 */
define(function (require, exports) {
    'use strict';

    var PREFERENCES = {
        INBOX_URL: 'inboxUrl',
        HELP_CENTRE_URL: 'helpCentreUrl',
        HELP_FOR_THIS_PAGE_URL: 'helpForThisPageUrl'
    };

    /**
     * Main controller
     * @ngInject
     * @constructor
     */
    function InboxCtrl(InboxService, lpWidget) {
        this.widget = lpWidget;
        this.inboxService = InboxService;
    }

    InboxCtrl.prototype.PREFERENCES = PREFERENCES;

    InboxCtrl.prototype.$onInit = function () {
        this.updateInboxStatus();
        this.updateLinks();
    };

    InboxCtrl.prototype.updateLinks = function () {
        this.links = {
            inbox: this.widget.getPreference(PREFERENCES.INBOX_URL),
            helpCentre: this.widget.getPreference(PREFERENCES.HELP_CENTRE_URL),
            helpForThisPage: this.widget.getPreference(PREFERENCES.HELP_FOR_THIS_PAGE_URL)
        };
    };

    InboxCtrl.prototype.updateInboxStatus = function () {
        function setInboxStatus(status) {
            this.inbox = status;
        }

        this.inboxService.getInboxStatus().then(setInboxStatus.bind(this));
    };

    exports.InboxCtrl = InboxCtrl;
});
