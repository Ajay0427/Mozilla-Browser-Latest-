package net.serenitybdd.demos.todos.model;

public enum TodoStatus {
    Active, Completed
}
