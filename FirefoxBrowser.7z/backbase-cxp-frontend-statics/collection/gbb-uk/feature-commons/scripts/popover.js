define( function (require, exports) {
    'use strict';

    require('bootstrap');

    function popover($document) {
        return {
            restrict: 'A',
            link: link
        };

        function link($scope, $element, $attrs) {
            var options = {};

            if ($attrs.popover) {
                options = $scope.$eval($attrs.popover);
            }

            if (options.contentSelector) {
                var contentNode = $element[0].querySelector(options.contentSelector);
                options.content = contentNode;
            }

            if (options.templateSelector) {
                options.template = getTemplateFromSelector($element[0], options.templateSelector);
                options.templateSelector = undefined;
            }

            options.trigger = 'manual';

            $element.popover(options);

            $document.on('click', function (e) {
                var eventSource = e.target;
                var isSource = $element.is(eventSource);
                var hasSource = $element.has(eventSource).length > 0;

                if (isSource || hasSource) {
                    $element.popover('toggle');
                    return;
                }
                $element.popover('hide');
            });
        }
    }

    function getTemplateFromSelector(element, selector) {
        var target = element.querySelector(selector);
        var template;

        if (target) {
            template = target.outerHTML.trim();
            target.remove();
        }

        return template;
    }

    exports.popover = popover;
});
