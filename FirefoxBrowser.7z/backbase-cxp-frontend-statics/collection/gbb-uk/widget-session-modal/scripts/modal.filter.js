/**
 * filter
 * @module filter
 */
define(function (require, exports) {

    'use strict';

    /**
     * @constructor
     * @ngInject
     */
    function secondsToMinuteFilter() {
        return function(timeInSeconds) {
            timeInSeconds = parseInt(timeInSeconds);

            if (isNaN(timeInSeconds)) {
                return '';
            }

            var minuteValue = Math.floor(timeInSeconds / 60);
            var secondsValue = timeInSeconds % 60;

            if (secondsValue < 10) {
                secondsValue = '0' + secondsValue;
            }

            return minuteValue + ':' + secondsValue;
      };
    };

    exports.secondsToMinute = secondsToMinuteFilter;
});
