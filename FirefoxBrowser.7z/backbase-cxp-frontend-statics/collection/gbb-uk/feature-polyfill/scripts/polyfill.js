(function() {
    'use strict';

    /**
     * Object.values()
     */
    Object.values = Object.values || function (object) {
        Object.keys(object).map(function (key) {
            return object[key];
        });
    };
}());
