require('angular');
require('angular-mocks');

var accountMock = require('../test/mocks/UK/accounts.json');
var main = require('./index');
var ngModule = window.module;
var modelXML = require('../model.xml');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');

describe('Account Overview Service', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', widget);
    }));

    describe('SortViewModel', function() {
        describe('@isBalanceVisible', function() {
            it('should be false if sorting by VALUE_DATE', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.VALUE_DATE);
                expect(model.isBalanceVisible).toBe(false);
            }));

            it('should be false if sorting by TYPE', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.TYPE);
                expect(model.isBalanceVisible).toBe(false);
            }));

            it('should be true if sorting by DATE', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.DATE);
                expect(model.isBalanceVisible).toBe(true);
            }));
        });

        describe('@isBalanceBroughtForwardInvisible', function() {
            it('should be true if sorting by DATE', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.DATE);
                expect(model.isBalanceBroughtForwardInvisible).toBe(true);
            }));

            it('should be false if sorting by DATE but in reverse order', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.DATE, true);
                expect(model.isBalanceBroughtForwardInvisible).toBe(false);
            }));

            it('should be true if sorting by VALUE_DATE', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.VALUE_DATE);
                expect(model.isBalanceBroughtForwardInvisible).toBe(true);
            }));

            it('should be true if sorting by TYPE', inject(function(SortViewModel) {
                var fields = SortViewModel.FIELDS;
                var model = new SortViewModel(fields.TYPE, true);
                expect(model.isBalanceBroughtForwardInvisible).toBe(true);
            }));
        });
    });

    describe('AccountViewModel', function() {
        describe('selectTab()', function() {
            it('should set a tab as active', inject(function(AccountViewModel) {
                var account = accountMock.result.accounts[0];
                var accountModel = new AccountViewModel(account);

                expect(accountModel.hasTransactions).toBe(true);
                expect(accountModel.hasBalanceDetails).toBe(true);

                expect(accountModel.TAB_BALANCE).toBe(1);
                expect(accountModel.TAB_TRANSACTIONS).toBe(2);

                expect(accountModel.activeTab).toBe(accountModel.TAB_BALANCE);

                accountModel.selectTab(accountModel.TAB_TRANSACTIONS);
                expect(accountModel.activeTab).toBe(accountModel.TAB_TRANSACTIONS);
            }));

            it('should not activate Transactions tab if the model has no transitions', inject(function(AccountViewModel) {
                var account = accountMock.result.accounts[0];
                var accountModel = new AccountViewModel(account);

                accountModel.hasBalanceDetails = true;
                accountModel.hasTransactions = false;

                accountModel.selectTab(accountModel.TAB_TRANSACTIONS);

                expect(accountModel.activeTab).toBe(accountModel.TAB_BALANCE);
            }));

            it('should not activate Balance tab if the model has no transactions', inject(function(AccountViewModel) {
                var account = accountMock.result.accounts[0];
                var accountModel = new AccountViewModel(account);

                accountModel.hasBalanceDetails = false;
                accountModel.hasTransactions = true;

                accountModel.activeTab = accountModel.TAB_TRANSACTIONS;
                accountModel.selectTab(accountModel.TAB_BALANCE);

                expect(accountModel.activeTab).toBe(accountModel.TAB_TRANSACTIONS);
            }));
        });

        describe('isSortedBy()', function() {
            it('should return true only if a given model sorting state matches the field to test', inject(function(AccountViewModel) {
                var model = new AccountViewModel({});
                model.unorderedTransactions = [{}];
                model.sortTransactionsBy(model.SORT_FIELDS.TYPE);

                expect(model.isSortedBy(model.SORT_FIELDS.TYPE)).toBe(true);
                expect(model.isSortedBy(model.SORT_FIELDS.DATE)).toBe(false);
                expect(model.isSortedBy(model.SORT_FIELDS.VALUE_DATE)).toBe(false);
            }));
        });

        describe('initialize()', function() {
            it('should return true only if a given model sorting state matches the field to test', inject(function(AccountViewModel) {
                var model = new AccountViewModel({});
                model.unorderedTransactions = [{}];

                model.sortTransactionsBy(model.SORT_FIELDS.TYPE);

                expect(model.isSortedBy(model.SORT_FIELDS.TYPE)).toBe(true);
                expect(model.isSortedBy(model.SORT_FIELDS.DATE)).toBe(false);
                expect(model.isSortedBy(model.SORT_FIELDS.VALUE_DATE)).toBe(false);
            }));
        });
    });
});
