### `v1.0.4 - 31/03/2016`

### `v1.0.3 - 16/02/2016`
* LF-624: Styling correction, better icons for next/prev arrows.


### v1.0.2 - `26/08/2015, 12:16pm`
#### add tag to info.json for styleguide filtering  
* add tag to info.json for styleguide menu filtering  


### v1.0.1 - `20/08/2015, 3:48pm`
* Updating dependencies from master to ^1.0.0 in bower.json  


### v1.0.0 - `20/08/2015, 2:37pm`
#### Initial release for CXP 5.6  


### v0.2.3 - `14/08/2015, 4:54pm`
#### remove lp.utils  
* move design mode styles  


### v0.2.2 - `10/08/2015, 6:09pm`
#### Remove repository from bower.json  
* LPMAINT-4 send deferred event via data-event= attribute  
* add info.json  


### v0.2.1 - `04/08/2015, 10:07am`
#### Fix container  
* fix the template to work in 5.6  
* fix container initialization  
* add template dependency  


### v0.2.0 - `30/07/2015, 2:45pm`
* Moving templates to their own repos.  
* update template path  
