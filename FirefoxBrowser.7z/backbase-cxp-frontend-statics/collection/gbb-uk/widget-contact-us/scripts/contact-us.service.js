/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PROPERTIES = {
        CONTACT_US_LIST_URL: 'contactUSListUrl'
    };

    // @private
    function getData(response) {
        return response.data;
    }

    // @private
    function transformContactUSListResponse(response) {
        return {
            result: response
        };
    }


    /**
     * @ngInject
     * @service AccountOverviewService
     * @constructor
     */
    function ContactUSService($http, lpWidget) {
        this.http = $http;
        this.widget = lpWidget;
    }

    /**
     * Widget properties used by this service
     * @property PROPERTIES
     * @type {Object}
     */
    ContactUSService.prototype.PROPERTIES = PROPERTIES;

    /**
     * @return {Promise<Array<Account>>}
     */
    ContactUSService.prototype.getContactListData = function() {
        var url = this.widget.getPreference(this.PROPERTIES.CONTACT_US_LIST_URL);
        return this.http.get(url).then(getData).then(transformContactUSListResponse);
        // TODO error handling!
    };

    exports.ContactUSService = ContactUSService;
});
