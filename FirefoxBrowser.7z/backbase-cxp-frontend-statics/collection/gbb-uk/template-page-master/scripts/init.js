(function() {
    function getCurrentScript() {
        if (document.currentScript) {
            return document.currentScript;
        }
        var scripts = document.getElementsByTagName('script');
        return scripts[scripts.length - 1];
    };

    function getUrlVars(url) {
        var vars = {}, hash, hashes = url.split(' ').join('').slice(url.indexOf('?') + 1).split(';');
        for(var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars[hash[0]] = hash[1];
        }
        return vars;
    }

    var params = getUrlVars(getCurrentScript().src);
    (function(portal) {
        portal.config = portal.config || {};
        portal.config.serverRoot = params.cRoot;
        portal.config.resourceRoot = (portal.config.resourceRoot || portal.config.serverRoot);
        portal.portalName = params.pName;
        portal.pageName = params.pageName;
        portal.pageUUID = params.pageUUID;
        portal.loggedInUserId = params.userName;
        portal.linkUUID = params.linkUUID;
        portal.loggedInUserRole = params.role ? 'role' : '';

        var userGroup = params.loggedInUserGroup && params.loggedInUserGroup.length ?
                params.loggedInUserGroup : '';

        portal.loggedInUserGroup = userGroup.split(',');
    }(b$.portal));

    window.launchpad = window.launchpad || {
        staticRoot: (params.cRoot || '') + '/static'
    };
})();
