/**
* Controllers
* @module controllers
*/
define(function(require, exports) {
    'use strict';

    var PREFERENCES = {
        HELP_BUSINESS_CENTRE_URL: 'businessCentreUrl',
        HELP_BIB_PHONE_URL: 'bibPhoneUrl',
        POP_UP_OPTIONS: 'popupOptions'
    };

    /**
    * @ngInject
    * @controller customerContact
    * @constructor
    */
    function CustomerContactCtrl(lpWidget, $window) {
        this.widget = lpWidget;
        this.$window = $window;
    }

    CustomerContactCtrl.prototype.PREFERENCES = PREFERENCES;

    CustomerContactCtrl.prototype.$onInit = function() {
        this.updateLinks();
    };

    CustomerContactCtrl.prototype.updateLinks = function () {
        this.links = {
            businessCentreUrl: this.widget.getPreference(PREFERENCES.HELP_BUSINESS_CENTRE_URL),
            bibPhoneUrl: this.widget.getPreference(PREFERENCES.HELP_BIB_PHONE_URL)
        };
    };

    CustomerContactCtrl.prototype.openPopUpBibPhone = function (event) {

        event.preventDefault();
        event.stopPropagation();

        if (this.popup && !this.popup.closed) {
            this.popup.close();
        }
        var windowOptions = this.widget.getPreference(this.PREFERENCES.POP_UP_OPTIONS);
        this.popup = this.$window.open(this.links.businessCentreUrl, 'business centre', windowOptions);
    };

    exports.CustomerContactCtrl = CustomerContactCtrl;
});
