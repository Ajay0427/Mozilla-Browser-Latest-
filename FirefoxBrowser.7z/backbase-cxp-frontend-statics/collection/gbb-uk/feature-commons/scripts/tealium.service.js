/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    /**
     * @ngInject
     * @service TealiumService
     * @constructor
     */

    function TealiumService() {

    }

    TealiumService.prototype.track = function(eventName, data) {
        if (window.utag) {
            window.utag.track( eventName, data);
        }

    };

    exports.TealiumService = TealiumService;
});
