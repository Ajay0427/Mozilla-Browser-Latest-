require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('CustomerContact Controller', function() {
    var createController, PREFERENCES;

    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    beforeEach(inject(function($controller, $rootScope) {
        createController = function(locals) {
            locals = locals || { $scope: $rootScope.$new() };
            return $controller('CustomerContactCtrl as $ctrl', locals);
        };

        PREFERENCES = {
            HELP_BUSINESS_CENTRE_URL: 'businessCentreUrl',
            HELP_BIB_PHONE_URL: 'bibPhoneUrl',
            POP_UP_OPTIONS: 'popupOptions'
        };
    }));

    describe('$onInit()', function() {
        it('should initialize the instance', inject(function() {
            var ctrl = createController();
            var spy = spyOn(ctrl, 'updateLinks');
            ctrl.$onInit();
            expect(spy).toHaveBeenCalled();
        }));
    });

    describe('updateLinks()', function() {
        it('should initialise values of links in the controller', inject(function($httpBackend, lpWidget) {
            var HELP_BUSINESS_CENTRE_URL = 'http://www.business.hsbc.uk/en-gb/contact-us/business-banking-centres';
            var HELP_BIB_PHONE_URL = '/portalserver/hsbc/contact-and-support/useful-contacts';
            lpWidget.setPreference(PREFERENCES.HELP_BUSINESS_CENTRE_URL, HELP_BUSINESS_CENTRE_URL);
            lpWidget.setPreference(PREFERENCES.HELP_BIB_PHONE_URL, HELP_BIB_PHONE_URL);
            var ctrl = createController();
            ctrl.updateLinks();

            expect(ctrl.links.businessCentreUrl).toEqual(HELP_BUSINESS_CENTRE_URL);
            expect(ctrl.links.bibPhoneUrl).toEqual(HELP_BIB_PHONE_URL);
        }));
    });

    describe('openPopUpBibPhone()', function() {
        it('should open a popup with business banking informations', inject(function(lpWidget, $window) {
            var HELP_BUSINESS_CENTRE_URL = 'http://www.business.hsbc.uk/en-gb/contact-us/business-banking-centres';
            var POP_UP_OPTIONS = 'width=550,height=550,location=no';

            var event = {
                preventDefault: function(){},
                stopPropagation: function(){}
            };

            var spyPreventDefault = spyOn(event, 'preventDefault');
            var spyStopPropagation = spyOn(event, 'stopPropagation');

            lpWidget.setPreference(PREFERENCES.HELP_BUSINESS_CENTRE_URL, HELP_BUSINESS_CENTRE_URL);
            lpWidget.setPreference(PREFERENCES.POP_UP_OPTIONS, POP_UP_OPTIONS);

            var ctrl = createController();
            $window.open = jasmine.createSpy('window.open');

            ctrl.$onInit();

            ctrl.openPopUpBibPhone(event);

            expect(spyPreventDefault).toHaveBeenCalled();
            expect(spyStopPropagation).toHaveBeenCalled();
            expect($window.open).toHaveBeenCalledWith(HELP_BUSINESS_CENTRE_URL, 'business centre', POP_UP_OPTIONS);
        }));
    });
});
