# backbase-cxp-feature-services
Common HSBC master page
## Information
|  name |  version |  bundle |
|--|:--:|--:|
|  hsbc-page-master |  1.0.0 |  HSCB |

https://my.backbase.com/docs/product-documentation/documentation//portal/5.6.2/page_objectdefinition.html
https://my.backbase.com/docs/product-documentation/documentation//portal/5.6.2/pagetemplate_objectdefinition.html
