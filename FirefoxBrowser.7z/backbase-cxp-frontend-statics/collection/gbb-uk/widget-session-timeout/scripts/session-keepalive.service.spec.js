require('angular');
require('angular-mocks');

var modelXML = require('../model.xml');
var indexHTML = require('../index.html');

var main = require('./index');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('SessionKeepAliveService', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var lpWidget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', lpWidget);
    }));

    beforeEach(inject(function($httpBackend, $rootScope, SessionKeepAliveService, lpWidget) {
        this.$httpBackend = $httpBackend;
        this.$rootScope = $rootScope;

        this.SessionKeepAliveService = SessionKeepAliveService;
        this.lpWidget = lpWidget;
    }));

    afterEach(function() {
        this.$httpBackend.verifyNoOutstandingExpectation();
        this.$httpBackend.verifyNoOutstandingRequest();
    });

    describe('keepalive', function() {
        it('should send a keepalive request to bib', function() {
            var result;
            var sessionKeepAliveBibUrl = this.lpWidget.setPreference(this.SessionKeepAliveService.PREFERENCES.SESSION_KEEP_ALIVE_BIB_URL, 'keepaliveBib');
            this.$httpBackend.expectGET(sessionKeepAliveBibUrl).respond(200);

            this.SessionKeepAliveService.keepAlive('bib').then(function() {
                result = 'resolved';
            });

            this.$httpBackend.flush();
            expect(result).toBe('resolved');
        });

        it('should send Content-Type headers to bib', function() {
            var result;
            var sessionKeepAliveBibUrl = this.lpWidget.setPreference(this.SessionKeepAliveService.PREFERENCES.SESSION_KEEP_ALIVE_BIB_URL, 'keepaliveBibContentType');

            this.$httpBackend.expectGET(sessionKeepAliveBibUrl, function(headers) {
                return headers['Content-Type'] === 'text/plain';
            }).respond(200);

            this.SessionKeepAliveService.keepAlive('bib').then(function() {
                result = 'resolved';
            });

            this.$httpBackend.flush();
            expect(result).toBe('resolved');
        });

        it('should send a keepalive request to gbbp', function() {
            var result;
            var sessionKeepAliveBibUrl = this.lpWidget.setPreference(this.SessionKeepAliveService.PREFERENCES.SESSION_KEEP_ALIVE_GBBP_URL, 'keepaliveGbbp');
            this.$httpBackend.expectGET(sessionKeepAliveBibUrl).respond(200);

            this.SessionKeepAliveService.keepAlive('gbbp').then(function() {
                result = 'resolved';
            });

            this.$httpBackend.flush();
            expect(result).toBe('resolved');
        });

        it('should not send a keepalive request when no environment was given', function() {
            var result;
            this.SessionKeepAliveService.keepAlive().catch(function() {
                result = 'rejected';
            });

            this.$rootScope.$apply();

            this.$httpBackend.verifyNoOutstandingRequest();
            expect(result).toBe('rejected');
        });

        it('should not send a keepalive request when an invalid environment was given', function() {
            var result;
            this.SessionKeepAliveService.keepAlive('foobar').catch(function() {
                result = 'rejected';
            });

            this.$rootScope.$apply();

            this.$httpBackend.verifyNoOutstandingRequest();
            expect(result).toBe('rejected');
        });
    });
});
