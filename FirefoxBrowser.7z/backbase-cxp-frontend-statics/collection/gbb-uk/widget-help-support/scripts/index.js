define( function (require, exports, module) {
    'use strict';

    module.name = 'widget-help-support';

    var base = require('base');
    var core = require('core');
    var hsbcCommons = require('feature-commons');

    var deps = [
        core.name,
        hsbcCommons.name
    ];

    module.exports = base.createModule(module.name, deps)
        .constant('WIDGET_NAME', module.name )
        .controller(require('./inbox.ctrl'))
        .service(require('./inbox.service'));
});
