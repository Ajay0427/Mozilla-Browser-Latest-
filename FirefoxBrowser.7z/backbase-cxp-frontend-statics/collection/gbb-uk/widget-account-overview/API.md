# API

```
AccountOverviewCtrl {
    selectedAccount: AccountViewModel;
    accountList: Array<AccountViewModel>;
    overview: AccountOverview,
    lastUpdated: String;

    selectAccount(account: AccountViewModel);
    updateAccountList();
}

AccountOverview {
    companyId: String;
    companyName: String;
}

SortViewModel {
    DATE: 'date';
    VALUE_DATE: 'valueDate';
    TYPE: 'type';

    field: String;
    reverse: Boolean;
}

AccountViewModel {
    TAB_BALANCE: 1;
    TAB_TRANSACTIONS: 2;

    hasTransactions: Boolean;
    hasBalanceDetails: Boolean;
    activeTab: String;
    children: Array<AccountViewModel>;
    parent: AccountViewModel;
    sorting: SortViewModel;
    details: AccountDetails;
    balanceDetails: BalanceDetails;
    transactions: Array<Transaction>;

    selectTab(tab: Enum(TAB_BALANCE, TAB_TRANSACTIONS));
    sortTransactionsBy(field: Enum(DATE, VALUE_DATE, TYPE));
}

AccountDetails {
    // TODO
}

BalanceDetails {
    // TODO
}

Transaction {
    date: String;
    valueDate: String;
    description: String;
    in: String;
    out: String;
    balance: String;
    type: String;
}
