require('jquery');
require('bootstrap');
require('angular');
require('angular-mocks');

var main = require('./index');
var ngModule = window.module;
describe('Feature commons Tooltip-Popover', function() {

    beforeEach(ngModule(main.name));

    describe('Initialize the  OnInit ', function() {
        it('should called onClick method on triggered of click event', inject(function($document, $controller, $rootScope) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var TOOLTIP_TEMPLATE = '<div class="popover"><div class="arrow"></div><div class="popover-btn-close"><button type="button" aria-label="Close popover" class="popover-close btn btn-link">&times;</button></div><div class="popover-content"></div></div>';
            $element.popover = jasmine.createSpy('popover').and.returnValue({html: true, template: TOOLTIP_TEMPLATE});;
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            var spyonClick = spyOn($ctrl, 'onClick');

            $ctrl.$onInit();
            $document.triggerHandler('click');

            expect(spyonClick).toHaveBeenCalled();
        }));

        it('should called onMouseEnter method on triggered of mouseenter event', inject(function($controller, $rootScope) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var TOOLTIP_TEMPLATE = '<div class="popover"><div class="arrow"></div><div class="popover-btn-close"><button type="button" aria-label="Close popover" class="popover-close btn btn-link">&times;</button></div><div class="popover-content"></div></div>';
            $element.popover = jasmine.createSpy('popover').and.returnValue({html: true, template: TOOLTIP_TEMPLATE});
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            var spyonMouseEnter = spyOn($ctrl, 'onMouseEnter');

            $ctrl.$onInit();
            $element.triggerHandler('mouseenter');
            $element.triggerHandler('focus');

            expect(spyonMouseEnter).toHaveBeenCalled();
        }));

        it('should called onMouseEnter method on triggered of focus event', inject(function($controller, $rootScope) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var TOOLTIP_TEMPLATE = '<div class="popover"><div class="arrow"></div><div class="popover-btn-close"><button type="button" aria-label="Close popover" class="popover-close btn btn-link">&times;</button></div><div class="popover-content"></div></div>';
            $element.popover = jasmine.createSpy('popover').and.returnValue({html: true, template: TOOLTIP_TEMPLATE});
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            var spyonMouseEnter = spyOn($ctrl, 'onMouseEnter');

            $ctrl.$onInit();
            $element.triggerHandler('focus');

            expect(spyonMouseEnter).toHaveBeenCalled();
        }));

        it('should called onMouseLeave method on triggered of mouseleave event', inject(function($controller, $rootScope) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var TOOLTIP_TEMPLATE = '<div class="popover"><div class="arrow"></div><div class="popover-btn-close"><button type="button" aria-label="Close popover" class="popover-close btn btn-link">&times;</button></div><div class="popover-content"></div></div>';
            $element.popover = jasmine.createSpy('popover').and.returnValue({html: true, template: TOOLTIP_TEMPLATE});
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            var spyonMouseLeave = spyOn($ctrl, 'onMouseLeave');

            $ctrl.$onInit();
            $element.triggerHandler('mouseleave');

            expect(spyonMouseLeave).toHaveBeenCalled();
        }));
    });

    describe('Popover placement', function() {
        var spyGetPosition, spyGetOffset, spyGetDocumentHeight;

        var initialiseSpyPosition = function(ctrl, topPosition, leftPosition){
            spyGetPosition = spyOn(ctrl, 'getSourcePosition').and.callFake(function() {
                return {top: topPosition, left: leftPosition};
            });
        };

        var initialiseSpyOffset = function(ctrl, topOffset, leftOffset){
            spyGetOffset = spyOn(ctrl, 'getSourceOffset').and.callFake(function() {
                return {top: topOffset, left: leftOffset};
            });
        };

        var initialiseSpyDocumentHeight = function(documentTriggered, documentHeight){
            spyGetDocumentHeight = spyOn(documentTriggered, 'height').and.callFake(function() {
                return documentHeight;
            });
        };

        it('Popover placement position should be left', inject(function($controller, $rootScope, $document) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            initialiseSpyPosition($ctrl, 112, 1300.96875);

            initialiseSpyOffset($ctrl, 318, 1592.984375);

            initialiseSpyDocumentHeight($document, 800);

            var getPosition = $ctrl.getPopoverPlacement();

            expect(spyGetPosition).toHaveBeenCalled();
            expect(spyGetOffset).toHaveBeenCalled();
            expect(spyGetDocumentHeight).toHaveBeenCalled();

            expect(getPosition).toEqual('left');
        }));
        it('Popover placement position should be right', inject(function($controller, $rootScope, $document) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            initialiseSpyPosition($ctrl, 198, 294.53125);

            initialiseSpyOffset($ctrl, 420, 606.546875);

            initialiseSpyDocumentHeight($document, 800);

            var getPosition = $ctrl.getPopoverPlacement();

            expect(spyGetPosition).toHaveBeenCalled();
            expect(spyGetOffset).toHaveBeenCalled();
            expect(spyGetDocumentHeight).toHaveBeenCalled();

            expect(getPosition).toEqual('right');
        }));
        it('Popover placement position should be bottom', inject(function($controller, $rootScope, $document) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();

            initialiseSpyPosition($ctrl, 198, 294.53125);

            initialiseSpyOffset($ctrl, 170, 606.546875);

            initialiseSpyDocumentHeight($document, 800);

            var getPosition = $ctrl.getPopoverPlacement();

            expect(spyGetPosition).toHaveBeenCalled();
            expect(spyGetOffset).toHaveBeenCalled();
            expect(spyGetDocumentHeight).toHaveBeenCalled();

            expect(getPosition).toEqual('bottom');
        }));
        it('Popover placement position should be top', inject(function($controller, $rootScope, $document) {
            var $element = angular.element('<a tooltip-popover></a>');
            var locals = {
                $scope: $rootScope,
                $element: $element
            };
            var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
            $rootScope.$apply();


            initialiseSpyPosition($ctrl, 300, 1050.421875);

            initialiseSpyOffset($ctrl, 800, 1362.4375);

            initialiseSpyDocumentHeight($document, 800);

            var getPosition = $ctrl.getPopoverPlacement();

            expect(spyGetPosition).toHaveBeenCalled();
            expect(spyGetOffset).toHaveBeenCalled();
            expect(spyGetDocumentHeight).toHaveBeenCalled();

            expect(getPosition).toEqual('top');
        }));
    });

    describe('Popover toggle/hide', function() {
        describe('onMouseEnter()', function() {
            it('should called mouseenter event and end result is popover toggle ', inject(function($controller, $rootScope) {
                var $element = angular.element('<a tooltip-popover></a>');
                var locals = {
                    $scope: $rootScope,
                    $element: $element
                };
                $element.popover = jasmine.createSpy('popover');
                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.onMouseEnter();

                expect($element.popover).toHaveBeenCalledWith('toggle');
            }));
        });

        describe('onMouseLeave()', function() {
            it('should called MouseLeave event and end result is popover hide', inject(function($controller, $rootScope) {
                var $element = angular.element('<a tooltip-popover></a>');
                var locals = {
                    $scope: $rootScope,
                    $element: $element
                };
                $element.popover = jasmine.createSpy('popover');
                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.onMouseLeave();

                expect($element.popover).toHaveBeenCalledWith('hide');
            }));
        });

        describe('onFocusOut()', function() {
            it('should called FocusOut event and end result is popover hide', inject(function($controller, $rootScope) {
                var $element = angular.element('<a tooltip-popover></a>');
                var locals = {
                    $scope: $rootScope,
                    $element: $element
                };
                $element.popover = jasmine.createSpy('popover');
                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.onMouseEnter();
                $ctrl.onFocusOut();

                expect($element.popover).toHaveBeenCalledWith('hide');
            }));
        });

        describe('shiftTabHandler() and hide popover after focusout', function() {
            it('should have isShiftTabEvent to true when shift tab press and called FocusOut event with hidding popover', inject(function($controller, $rootScope) {
                var htmlElement = '<a tooltip-popover></a>';
                var element = angular.element(htmlElement);
                var locals = {
                    $scope: $rootScope,
                    $element: element
                };

                element.popover = jasmine.createSpy('popover');

                var evt = {
                    which: 9,
                    keyCode: 9,
                    shiftKey: true
                };

                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.$onInit();

                $ctrl.shiftTabHandler(evt);
                expect($ctrl.isShiftTabEvent).toBe(true);

                element.triggerHandler('focusout');

                expect(element.popover).toHaveBeenCalledWith('hide');
                expect($ctrl.isShiftTabEvent).toBe(false);

                var evtWithoutTab = {
                    which: 9,
                    keyCode: 9,
                    shiftKey: false
                };

                $ctrl.shiftTabHandler(evtWithoutTab);
                expect($ctrl.isShiftTabEvent).toBe(false);
            }));

            it('should have isShiftTabEvent to true when shift tab press, isShiftTabEvent false when pressing another combination and not calling hide popover function', inject(function($controller, $rootScope) {
                var htmlElement = '<a tooltip-popover></a>';
                var element = angular.element(htmlElement);
                var locals = {
                    $scope: $rootScope,
                    $element: element
                };

                element.popover = jasmine.createSpy('popover');

                var evt = {
                    which: 9,
                    keyCode: 9,
                    shiftKey: true
                };

                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.$onInit();

                $ctrl.shiftTabHandler(evt);
                expect($ctrl.isShiftTabEvent).toBe(true);

                var evtWithoutTab = {
                    which: 27,
                    keyCode: 27,
                    shiftKey: false
                };

                $ctrl.shiftTabHandler(evtWithoutTab);
                expect($ctrl.isShiftTabEvent).toBe(false);

                $(htmlElement).trigger('focusout');

                expect(element.popover).not.toHaveBeenCalled();
            }));
        });

        describe('onClick()', function() {
            it('should called click event with is value true & and value false, end result is popover toggle', inject(function($controller, $rootScope) {
                var $element = angular.element('<a tooltip-popover></a>');
                var locals = {
                    $scope: $rootScope,
                    $element: $element
                };
                var event = {
                    preventDefault: jasmine.createSpy('preventDefault'),
                    target: 'a'
                };
                $element.popover = jasmine.createSpy('popover');
                $element.is = jasmine.createSpy('is').and.returnValue(true);
                $element.has = jasmine.createSpy('has').and.returnValue(false);
                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.onClick(event);

                expect($element.popover).toHaveBeenCalledWith('toggle');
            }));

            it('should called click event with is value false & and value true, end result is popover toggle', inject(function($controller, $rootScope) {
                var $element = angular.element('<a tooltip-popover></a>');
                var locals = {
                    $scope: $rootScope,
                    $element: $element
                };
                var event = {
                    preventDefault: jasmine.createSpy('preventDefault'),
                    target: 'a'
                };
                $element.popover = jasmine.createSpy('popover');
                $element.is = jasmine.createSpy('is').and.returnValue(false);
                $element.has = jasmine.createSpy('has').and.returnValue(true);

                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.onClick(event);

                expect($element.popover).toHaveBeenCalledWith('hide');
            }));

            it('should called click event with is and and value false, end result is popover hide', inject(function($controller, $rootScope) {
                var $element = angular.element('<a tooltip-popover></a>');
                var locals = {
                    $scope: $rootScope,
                    $element: $element
                };
                var event = {
                    preventDefault: jasmine.createSpy('preventDefault'),
                    target: 'a'
                };
                $element.popover = jasmine.createSpy('popover');
                $element.is = jasmine.createSpy('is').and.returnValue(false);
                $element.has = jasmine.createSpy('has').and.returnValue(false);

                var $ctrl = $controller('TooltipDirectiveController as $ctrl', locals);
                $rootScope.$apply();

                $ctrl.onClick(event);

                expect($element.popover).toHaveBeenCalledWith('hide');
            }));
        });
    });
});
