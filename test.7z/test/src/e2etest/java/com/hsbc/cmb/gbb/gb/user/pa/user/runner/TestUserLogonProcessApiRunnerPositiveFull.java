package com.hsbc.cmb.gbb.gb.user.pa.user.runner;

import com.hsbc.cmb.gbb.gb.user.pa.user.configuration.CucumberWithProperties;
import com.hsbc.cmb.gbb.gb.user.pa.user.configuration.PropertiesFile;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.FEATURE_PATH;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.FULL;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.LOGON;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.LOGON_TEST_CONFIG_PROPERTIES;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.POSITIVE;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.PROCESS_API;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.STEPS_DEFINITION;
import static com.hsbc.cmb.gbb.gb.user.pa.user.runner.TestUserLogonProcessApiRunnerPositiveFull.USER;

@CucumberOptions(
        features = {FEATURE_PATH},
        glue = {STEPS_DEFINITION},
        monochrome = true,
        tags = {USER,
                LOGON,
                PROCESS_API,
                POSITIVE,
                FULL}
)

@RunWith(CucumberWithProperties.class)
@PropertiesFile(LOGON_TEST_CONFIG_PROPERTIES)
public class TestUserLogonProcessApiRunnerPositiveFull {
    static final String LOGON_TEST_CONFIG_PROPERTIES = "logonTestConfig.properties";
    static final String FEATURE_PATH = "classpath:feature";
    static final String STEPS_DEFINITION = "com.hsbc.cmb.gbb.gb.user.pa.user.steps";
    static final String USER = "@User";
    static final String LOGON = "@Logon";
    static final String PROCESS_API = "@ProcessAPI";
    static final String POSITIVE = "@Positive";
    static final String FULL = "@Full";
}