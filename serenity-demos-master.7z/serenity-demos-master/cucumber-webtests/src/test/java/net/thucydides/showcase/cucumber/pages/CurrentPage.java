package net.thucydides.showcase.cucumber.pages;

import net.serenitybdd.core.pages.PageObject;

/**
 * Created by john on 10/05/2016.
 */
public class CurrentPage extends PageObject {
}
