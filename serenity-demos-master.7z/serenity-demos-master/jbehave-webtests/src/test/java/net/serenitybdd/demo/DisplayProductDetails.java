package net.serenitybdd.demo;

import net.serenitybdd.jbehave.SerenityStory;

public class DisplayProductDetails extends SerenityStory {

    public DisplayProductDetails() {
        runSerenity().inASingleSession();
    }
}
