/**
 * Date Filter decorator
 * Adds 'o' (lowercase O letter) as a modifier for ordinal suffix addition on
 * day of month
 */
define(function (require, exports) {
    'use strict';

    function dateTimeDecorator($delegate) {
        var ORDINAL_PATTERN = /(\d{2}|\d{1})o/g;

        function isOrdinalFirst(day) {
            return day === 1 || day === 21 || day === 31;
        }

        function isOrdinalSecond(day) {
            return day === 2 || day === 22;
        }

        function isOrdinalThird(day) {
            return day === 3 || day === 23;
        }

        function replacementFn($0, $1) {
            var day = Number($1);

            if (isOrdinalFirst(day)) {
                return day + 'st';
            }

            if (isOrdinalSecond(day)) {
                return day + 'nd';
            }

            if (isOrdinalThird(day)) {
                return day + 'rd';
            }

            return day + 'th';
        }

        return function(date, format, timezone) {
            if (!date) {
                return '';
            }

            if (format) {
                format = format.replace(/o/g, '\'o\'');
            }

            var formattedDate = $delegate(date, format, timezone);

            return formattedDate.replace(ORDINAL_PATTERN, replacementFn);
        };
    }

    function decorate($provide) {
        $provide.decorator('dateFilter', dateTimeDecorator);
    }

    exports.dateDecorator = decorate;
});
