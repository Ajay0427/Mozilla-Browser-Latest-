window.jQuery = require('jquery');

window.be = {ice: true};

window.bd = {designMode: 'false'};

require('./template-marketing-ctrl.js');
require('./index.js');
require('./extension.js');

var WidgetMock = require('../test/widget-mocks.js');
var modelXML = require('../model.xml');
var templateExpandedHTML = require('../test/unit/extension.marketing.template.mock.html');
var WidgetIndex = b$.hsbc.widgets.WidgetHsbcContent;
var WidgetExtension = b$.hsbc.extensions.WidgetHsbcContentExtension;
var WidgetMarketing = b$.hsbc.widgets.marketingContentCtrl;

describe('WidgetHsbcContentExtension', function() {

    describe('call start', function() {
        var widget;

        beforeEach(function() {
            widget = new WidgetMock(modelXML, templateExpandedHTML);
        });

        it('should call start from b$.hsbc.widgets.WidgetHsbcContent', function() {
            var spyStart = spyOn(WidgetIndex, 'start').and.callThrough();
            WidgetExtension.start(widget);
            expect(spyStart).toHaveBeenCalledWith(widget);
        });

        it('should call initialise from b$.hsbc.widgets.marketingContentCtrl with widget parameter', function() {
            var spyInitialise = spyOn(WidgetMarketing, 'initialise').and.callThrough();
            WidgetExtension.start(widget);
            expect(spyInitialise).toHaveBeenCalledWith(widget);
        });
    });
});
