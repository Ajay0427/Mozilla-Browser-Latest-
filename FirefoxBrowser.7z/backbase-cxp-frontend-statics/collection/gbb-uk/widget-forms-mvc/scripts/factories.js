(function () {
  var serverName = window.location.hostname;
  var port = ( window.location.port === '' ) ? '' : ":" + window.location.port;
  var servicePath = ['https://', serverName, port, b$.portal.config.serverRoot, '/services/forms/api/v1'].join('');

  var OAuthConfig = {
    credentials: {
      username: 'admin',
      password: 'admin',
      grant_type: 'password'
    },
    options: {
      params: {
        username: 'admin',
        password: 'admin',
        grant_type: 'password'
      },
      headers: {
        'Authorization': 'Basic ' + btoa('admin:admin')
      }
    }
  };

  angular.module('widget-forms-mvc')
    .constant('servicePath', servicePath)
    .constant('OAuthConfig', OAuthConfig)
    .factory('shortcutService', ['$http', 'widget', 'servicePath', 'OAuth', 'OAuthConfig', function ($http, widget, servicePath, OAuth, OAuthConfig) {
      return {
        getShortcuts: function () {
          function queryShortcuts() {
            return $http({
              url: servicePath + '/shortcuts',
              method: 'GET'
            });
          }

          if (OAuth.isAuthenticated()) {
            return queryShortcuts();
          } else {
            return OAuth.getAccessToken(OAuthConfig.credentials, OAuthConfig.options).then(queryShortcuts);
          }
        }
      }
    }]);
})();