var $ = window.jQuery = require('jquery');

require('./template-marketing-ctrl.js');

var WidgetMock = require('../test/widget-mocks.js');
var modelXML = require('../model.xml');
var templateExpandedHTML = require('../test/unit/marketing-content.expand.mock.html');
var Widget = b$.hsbc.widgets.marketingContentCtrl;

describe('WidgetHsbcContent', function() {

    function createWidget(oWidget) {
        return Widget.initialise(oWidget);
    }

    describe('setEditingMode false', function() {
        var mainContainerUnexpand, widgetUnexpand, containerWidgetMarketingContent;
        beforeEach(function() {
            widgetUnexpand = new WidgetMock(modelXML, templateExpandedHTML);
            mainContainerUnexpand = $(widgetUnexpand.body).find('.main-container');
            containerWidgetMarketingContent = $(widgetUnexpand.body).find('.widget-marketing-content');

            //Creation dummy function to test window.open and window.focus
            spyOn(window, 'open').and.callFake(function(url, name){
                window.closed = false;
                window.name = name;
                window.url = url;
                return window;
            });

            this.widget = createWidget(widgetUnexpand);
        });

        it('should remove expand class and call initialise method', function() {
            expect(mainContainerUnexpand.hasClass('expand-main-container')).toBe(false);
            expect(mainContainerUnexpand.hasClass('loading-screen')).toBe(true);
            expect(containerWidgetMarketingContent.css('display')).toEqual('block');
        });

        it('should catch click signal on title and send signals', function() {
            var spyPublish = spyOn(window.gadgets.pubsub, 'publish');
            var titleSection = $(widgetUnexpand.body).find('.title');

            titleSection.trigger('click');

            var mainContainerUnexpandAfterTigger = $(widgetUnexpand.body).find('.main-container');

            expect(spyPublish).toHaveBeenCalledWith('carousel.stop.autoplay');
            expect(spyPublish).toHaveBeenCalledWith('carousel.display.pagination');
            expect(spyPublish).toHaveBeenCalledWith('carousel.display.control');
            expect(mainContainerUnexpandAfterTigger.hasClass('expand-main-container')).toBe(true);
            expect(spyPublish).toHaveBeenCalledWith('template.expand');
        });

        it('should catch click signal on btn-control, send signal stop autoplay with putting btn play and start autoplay with putting btn pause', function() {
            var spyPublish = spyOn(window.gadgets.pubsub, 'publish');
            var btnControl = $(widgetUnexpand.body).find('.btn-control');

            btnControl.trigger('click');

            expect(spyPublish).toHaveBeenCalledWith('carousel.stop.autoplay');
            expect(btnControl.hasClass('glyphicon-play')).toBe(true);
            expect(btnControl.hasClass('glyphicon-pause')).toBe(false);
            expect(spyPublish).toHaveBeenCalledWith('autoplay.pause');

            btnControl.trigger('click');

            expect(spyPublish).toHaveBeenCalledWith('carousel.start.autoplay');
            expect(btnControl.hasClass('glyphicon-pause')).toBe(true);
            expect(btnControl.hasClass('glyphicon-play')).toBe(false);
            expect(spyPublish).toHaveBeenCalledWith('autoplay.play');
        });

        it('should catch click signal on btn-close and send signals', function() {
            var spyPublish = spyOn(window.gadgets.pubsub, 'publish');
            var btnClose = $(widgetUnexpand.body).find('.btn-close');

            btnClose.trigger('click');

            var mainContainerUnexpendAfterTigger = $(widgetUnexpand.body).find('.main-container');

            expect(spyPublish).toHaveBeenCalledWith('carousel.start.autoplay');
            expect(spyPublish).toHaveBeenCalledWith('carousel.hide.pagination');
            expect(spyPublish).toHaveBeenCalledWith('carousel.hide.control');
            expect(mainContainerUnexpendAfterTigger.hasClass('expand-main-container')).toBe(false);
            expect(spyPublish).toHaveBeenCalledWith('template.unexpand');
        });

        it('should open new popup when btn in title is clicking', function() {

            var btnLink = $(widgetUnexpand.body).find('.btn-primary');

            window.focus = jasmine.createSpy('window.focus').and.callThrough();

            btnLink.trigger('click');

            expect(window.open).toHaveBeenCalledWith(btnLink.attr('href'), btnLink.attr('href'));

            btnLink.trigger('click');

            expect(window.focus).toHaveBeenCalled();
        });

        it('should send signal template.ready when load trigger is executing', function() {
            var spyPublish = spyOn(window.gadgets.pubsub, 'publish');

            $(window).trigger('load');

            expect(spyPublish).toHaveBeenCalledWith('template.ready');
        });
    });
});
