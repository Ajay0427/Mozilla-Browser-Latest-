/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    var PROPERTIES = {
        CURRENT_USER_PROFILE_URL: 'currentUserProfileUrl'
    };

    // @private
    function getData(response) {
        return response.data;
    }

    /**
     * @ngInject
     * @service AccountOverviewService
     * @constructor
     */
    function WelcomeMessageService($http, lpWidget) {
        this.http = $http;
        this.widget = lpWidget;
    }

    /**
     * Widget properties used by this service
     * @property PROPERTIES
     * @type {Object}
     */
    WelcomeMessageService.prototype.PROPERTIES = PROPERTIES;

    /**
     * @return {Promise<Array<Account>>}
     */
    WelcomeMessageService.prototype.getCurrentUserProfileData = function() {
        var url = this.widget.getPreference(this.PROPERTIES.CURRENT_USER_PROFILE_URL);
        return this.http.get(url).then(getData);
        // TODO error handling!
    };

    exports.WelcomeMessageService = WelcomeMessageService;
});
