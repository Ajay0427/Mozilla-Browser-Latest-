# Responsive Grid Container

A simple container with configurable areas. This container is a simplified version of Launchpad one with only the option to change the number of areas and CSS classes. No resize options are available.


## Properties

### Columns

Used to change the number of areas. A positive number, 1 or more.

### Column CSS classes

A list of Bootstrap Grid CSS classes, separated by comma. Each group between commas maps to the available columns (areas).
