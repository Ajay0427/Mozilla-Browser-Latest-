define(function (require, exports) {

    function accordionDirective() {
        var CLASSES = {
            COLLAPSED: 'collapsed',
            ACTIVE: 'in',
            OPEN: 'open'
        };

        function linker($scope, $element, $attrs) {
            var options = $attrs.accordion ? $scope.$eval($attrs.accordion) : {};

            $element.on('click', 'a[data-toggle]', toggleGroup);

            function toggleGroup(event) {
                var target = $(event.currentTarget);
                var group = target.parents('[data-group]');

                if (options.closeOthers) {
                    closeAllGroups();
                } else if (isGroupOpen(target)) {
                    closeGroup(group, target);
                } else {
                    openGroup(group, target);
                }
            }

            function isGroupOpen(target) {
                return !target.hasClass(CLASSES.COLLAPSED);
            }

            function openGroup(group, target) {
                var content = group.find('.accordion_content');
                var contentHeader = group.find('.accordion_heading');

                contentHeader.addClass(CLASSES.OPEN);
                content.addClass(CLASSES.ACTIVE);
                target.removeClass(CLASSES.COLLAPSED);
            }

            function closeGroup(group, target) {
                var content = group.find('.accordion_content');
                var contentHeader = group.find('.accordion_heading');

                contentHeader.removeClass(CLASSES.OPEN);
                content.removeClass(CLASSES.ACTIVE);
                target.addClass(CLASSES.COLLAPSED);
            }

            function closeAllGroups() {
                var groups = $element.find('[data-group]');
                var groupContentNodes = groups.find('.accordion_content');
                var groupToggleNodes = groups.find('a[data-toggle]');

                groupContentNodes.each(function () {
                    $(this).removeClass(CLASSES.ACTIVE);
                });

                groupToggleNodes.each(function closeToggle() {
                    $(this).addClass('collapsed');
                });
            }

        }

        return {
            name: 'accordion',
            link: linker,
            priority: 1500
        };
    }

    exports.accordion = accordionDirective;
});
