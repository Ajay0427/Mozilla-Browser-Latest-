/*----------------------------------------------------------------*/
/* Webpack main entry point
/*----------------------------------------------------------------
 * look for every <filename>.spec.js or <filename>.Spec.js
 * in 'unit/' and '../../scripts/'  folder
 * except 3rd party vendors like bower_components or node_modules
 */

var testContexts = [
    require.context('../../scripts', false, /^((?![\\/]node_modules|bower_components[\\/]).)*\.spec\.js$/)
];

testContexts.forEach(function(context) {
    context.keys().forEach(context);
});
