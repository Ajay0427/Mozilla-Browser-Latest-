/**
* Tooltip popover
*/
define(function(require, exports) {
    'use strict';

    require('bootstrap');

    var TOOLTIP_TEMPLATE = '<div class="popover"><div class="arrow"></div><div class="popover-btn-close"><button type="button" aria-label="Close popover" class="popover-close btn btn-link">&times;</button></div><div class="popover-content"></div></div>';
    var POSITION_LEFT = 300;
    var POSITION_TOP = 200;
    var TAB_KEY_CODE = 9;

    function getPopoverPlacement (context, source) {
        var position = this.getSourcePosition(source);
        var offset = this.getSourceOffset(source);

        var windowHeight = this.document.height();

        if ((position.left < POSITION_LEFT) && (offset.top > POSITION_TOP && (offset.top < windowHeight - POSITION_TOP))) {
            return 'right';
        }
        else if ((offset.left > POSITION_LEFT) && (offset.top > POSITION_TOP && (offset.top < windowHeight - POSITION_TOP))) {
            return 'left';
        }
        else if (offset.top < POSITION_TOP){
            return 'bottom';
        }
        else {
            return 'top';
        }
    }

    function getSourcePosition(source) {
        return $(source).position();
    };

    function getSourceOffset(source) {
        return $(source).offset();
    }


    /**
    * @constructor
    * @ngInject
    */

    function tooltipPopover() {
        return {
            restrict: 'A',
            controller: 'TooltipDirectiveController'
        };
    }

    function TooltipDirectiveController($document, $element) {
        this.element = $element;
        this.document = $document;
        this.isClicked = false;
        this.isShiftTabEvent = false;
    }

    TooltipDirectiveController.prototype.$onInit = $onInit;
    TooltipDirectiveController.prototype.getPopoverPlacement = getPopoverPlacement;
    TooltipDirectiveController.prototype.getSourcePosition = getSourcePosition;
    TooltipDirectiveController.prototype.getSourceOffset = getSourceOffset;
    TooltipDirectiveController.prototype.onFocusOut = onFocusOut;
    TooltipDirectiveController.prototype.onFocusOutPopover = onFocusOutPopover;
    TooltipDirectiveController.prototype.shiftTabHandler = shiftTabHandler;
    TooltipDirectiveController.prototype.onClick = onClick;
    TooltipDirectiveController.prototype.onMouseEnter = onMouseEnter;
    TooltipDirectiveController.prototype.onMouseLeave = onMouseLeave;

    function $onInit() {
        var element = this.element;

        element.popover({
            html: true,
            placement: this.getPopoverPlacement.bind(this),
            template: TOOLTIP_TEMPLATE
        });

        this.document.on('click', this.onClick.bind(this));
        element.on('mouseenter', this.onMouseEnter.bind(this));
        element.on('mouseleave', this.onMouseLeave.bind(this));
        element.on('focus', this.onMouseEnter.bind(this));
        element.on('keydown', this.shiftTabHandler.bind(this));
        element.on('focusout', this.onFocusOutPopover.bind(this));
    }

    function onClick(event) {
        var element = this.element;
        var eventSource = event.target;
        var isSource = element.is(eventSource);
        var hasSource = element.has(eventSource).length > 0;

        if (isSource || hasSource) {
            this.isClicked = true;
            element.popover('toggle');
            return;
        }

        element.popover('hide');
    }

    function onMouseLeave() {
        if (!this.isClicked) {
            this.element.popover('hide');
        }
    }

    function onFocusOut(){
        if (!this.isClicked) {
            this.element.popover('hide');
        }
    }

    function onFocusOutPopover(){
        if (this.isShiftTabEvent) {
            this.element.popover('hide');
            this.isShiftTabEvent = false;
        }
    }

    function shiftTabHandler(evt){
        var charCode = evt.which || evt.keyCode;
        this.isShiftTabEvent = false;
        if (charCode === TAB_KEY_CODE && evt.shiftKey) {
            this.isShiftTabEvent = true;
        }
    }

    function onMouseEnter() {
        this.isClicked = false;
        this.element.popover('toggle');
        var elementPopover = this.element[0].parentNode.querySelector('.popover');
        if (elementPopover) {
            angular.element('.popover').not(elementPopover).popover('hide');
            angular.element('.popover').find('.popover-close').on('focusout', this.onFocusOut.bind(this));
        }
    }

    exports.directive = { tooltipPopover: tooltipPopover };
    exports.controller = { TooltipDirectiveController: TooltipDirectiveController };
});
