require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var contactListMock = require('../test/mock/contactUs_List.json');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('ContactUS Controller', function() {
    var createController, mockContactUSList;

    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    beforeEach(inject(function($controller, $rootScope, $httpBackend, lpWidget, ContactUSService) {
        createController = function(locals) {
            locals = locals || { $scope: $rootScope.$new() };
            return $controller('ContactUSCtrl as $ctrl', locals);
        };

        mockContactUSList = function() {
            // randomise URL to avoid conflicts between tests
            var contactListUrl = '/api/contact-us-list/' + Math.random();
            var contactListData = Object.create(contactListMock);

            $httpBackend.whenGET(contactListUrl).respond(contactListData);
            lpWidget.setPreference(ContactUSService.PROPERTIES.CONTACT_US_LIST_URL, contactListUrl);
        };

    }));

    describe('$onInit()', function() {
        it('should initialize the instance', inject(function() {
            var ctrl = createController();
            var spy = spyOn(ctrl, 'contactUSListInitialize');
            ctrl.$onInit();

            expect(spy).toHaveBeenCalled();
        }));
    });

    describe('contactUSListInitialize()', function() {
        it('should fetch/process a value of contactUSList the controller', inject(function($httpBackend) {
            mockContactUSList();
            var ctrl = createController();
            ctrl.contactUSListInitialize();
            $httpBackend.flush();

            var contactList = contactListMock;
            expect(ctrl.contactList).toEqual({
              contactListDetail: contactList.result.accordion
            });
        }));
    });

});
