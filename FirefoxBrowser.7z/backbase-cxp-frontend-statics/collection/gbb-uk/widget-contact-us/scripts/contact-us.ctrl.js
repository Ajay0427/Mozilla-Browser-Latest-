/**
 * Controllers
 * @module controllers
 */
define(function(require, exports) {
    'use strict';

    /**
     * @ngInject
     * @controller accountList
     * @constructor
     */
    function ContactUSCtrl( ContactUSService, lpWidget) {
        this.contactUSService = ContactUSService;
        this.widget = lpWidget;
    }

    ContactUSCtrl.prototype.$onInit = function() {
      this.contactUSListInitialize();
    };


    ContactUSCtrl.prototype.contactUSListInitialize = function() {
        this.contactUSService.getContactListData()
        .then(this.contactListInformation.bind(this));
    };

    ContactUSCtrl.prototype.contactListInformation = function(contactListResponse) {
        var contactList = contactListResponse.result;
        this.contactList = {
            contactListDetail: contactList.result.accordion,
        };
        return contactListResponse;
    };

    exports.ContactUSCtrl = ContactUSCtrl;
});
