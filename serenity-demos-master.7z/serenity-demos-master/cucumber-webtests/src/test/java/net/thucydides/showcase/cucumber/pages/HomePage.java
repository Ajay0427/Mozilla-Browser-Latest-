package net.thucydides.showcase.cucumber.pages;

import com.google.common.base.Function;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@DefaultUrl("https://eu472user:Pr0tect@www.eu472.p2g.netd2.hsbc.com.hk/1/2/!ut")
public class HomePage extends PageObject {



    @FindBy(xpath = "//a[@title='LOG ON']")
    WebElementFacade LogOn;

    @FindBy(xpath = "//input[@id='userid1']")
    WebElementFacade userid;

    @FindBy(xpath = "//input[@type='submit' and @value='Continue']")
    WebElementFacade continiueBtn;

    @FindBy(xpath = "//input[@id='memorableAnswer']")
    WebElementFacade memorableAnswer;

    @FindBy(xpath = "//input[@id='idv_OtpCredential']")
    WebElementFacade idv_OtpCredential;

    @FindBy(xpath = "//input[@type='submit' and @value='Continue']")
    WebElementFacade Continue;

    @FindBy(xpath = "//a[@href='javascript:go();']")
    WebElementFacade gobtn;
    // Rapptor elements
    @FindBy(xpath = "//select[@id='rapportOptions']")
    WebElementFacade selectOpt;

    @FindBy(xpath = "//a[@id='rap_button']")
    WebElementFacade rapCont;


    @FindBy(xpath = "//a[@onclick='removeOverlay()']")
    WebElementFacade rapClose;

    @FindBy(xpath="//form[@id='search-bar']//button[@type='submit']")
    WebElementFacade searchButton;


    @FindBy(xpath = "//span[@class='icon icon-primary icon-insight']/following-sibling::span")
    WebElementFacade IntrestedIn;

    @FindBy(xpath = "//ul[@class='nav-edm-secondary']//span[contains(text(),'Interested in?')]")
    WebElementFacade secIntrestedIn;

    @FindBy(xpath = "//span[contains(text(),'Loan')]")
    WebElementFacade Loan;

    @FindBy(xpath = "//a[contains(text(),'Your Account')]")
    WebElementFacade YourAccount;

    @FindBy(xpath = "//a[contains(text(),'My HSBC')]")
    WebElementFacade myHSBC;

    @FindBy(xpath = "//span[contains(text(),'Accounts')]")
    WebElementFacade accountMenu;
    @FindBy(xpath = "//span[contains(text(),'Make Payments')]")
    WebElementFacade MakePayments;


    private final static String SHOP_SUGGESTION = "//div[@id='search-suggestions']//div[@class='as-suggestion']//*[contains(.,'find shop names containing')]";
    private final static String SHOP_SUGGESTION_SHOP_NAME = "//div[@id='search-suggestions']//div[@class='as-suggestion']/span[2]";
    
    public void enterSearchTerms(String keyword) {
    	$("#search-query").type(keyword);
        new WebDriverWait(getDriver(),1).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SHOP_SUGGESTION)));
        //withTimeoutOf(10, TimeUnit.SECONDS).waitForPresenceOf(By.xpath(SHOP_SUGGESTION));
        waitForKeywordToBeUpdatedTo(keyword);
    }

    private void waitForKeywordToBeUpdatedTo(String keyword) {
        waitForCondition()
                .withTimeout(5, TimeUnit.SECONDS)
                .pollingEvery(250,TimeUnit.MILLISECONDS)
                .until(keywordFieldIsUpdatedTo(keyword));
    }

    private Function<? super WebDriver, Boolean> keywordFieldIsUpdatedTo(String keyword) {
        return webDriver -> $("#search-query").getValue().equalsIgnoreCase(keyword);
    }

    public void search() {
        searchButton.click();
    }

    public void searchForShopCalled(String shopName) {
        enterSearchTerms(shopName);
        $(SHOP_SUGGESTION_SHOP_NAME).click();
    }

    public void dismissLocationMessage() {
        if (!findAll(By.cssSelector("input[value='Okay']")).isEmpty()) {
            find(By.cssSelector("input[value='Okay']")).click();
        }
    }
    public  void selectCategory() {
        LogOn.click();
        Select dropdown = new Select(selectOpt);
        dropdown.selectByVisibleText("I've already downloaded");
        rapCont.click();

        rapClose.click();
    }


    public void setUserName(final String Username, final String otp) {
        userid.sendKeys(Username);
        continiueBtn.click();

        String OTP = null;

        try {
            OTP = ProjLib.generateOTP(Username, "123", otp);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Password and IDV
        memorableAnswer.sendKeys("hsbcbank");
        idv_OtpCredential.sendKeys(OTP);
        Continue.click();
        gobtn.click();
        System.out.println(getTitle());
    }

    public void clickLoan() {
        element(IntrestedIn).waitUntilClickable();
        IntrestedIn.isEnabled();
        IntrestedIn.click();
        Loan.click();
    }

    public boolean isGBBPage() {
        // TODO Auto-generated method stub
        WebDriver Driver = getDriver();
        String Title = "My HSBC";
        Boolean flag = true;
        if (Driver.getTitle().equalsIgnoreCase(Title)) {
            flag = false;
        }


        return flag;
    }
    public void isBIBEDMAvailable() {
        // TODO Auto-generated method stub
        assert(YourAccount.isDisplayed());
    }

    public void backtoGBB() {
        // TODO Auto-generated method stub
        waitUntilTitleAppears();
        this.myHSBC.click();
        // this.MakePayments.click();

    }


    public void waitUntilTitleAppears() {
        element(YourAccount).waitUntilClickable();
    }

    public void MakePayment() {
        MakePayments.click();
    }
}
