package net.serenitybdd.demo;

import net.serenitybdd.jbehave.SerenityStory;

public class SearchByKeyword extends SerenityStory {}
