/**
 * Controllers
 * @module controllers
 */
define(function (require, exports) {
    'use strict';

    const DIMENSIONS = {
        HEIGHT: 360,
        WIDTH: 515
    };

    const MESSAGEBUS_EVENTS = {
        DEACTIVATE: 'session-modal:deactivate',
        KEEP_ALIVE: 'session:keep-alive',
        LOGOFF: 'session:logoff',
        TIME_LEFT: 'session:time-left'
    };

    const PREFERENCES = {
        SESSION_POPUP_THRESHOLD: 'sessionPopupThreshold',
        SESSION_POPUP_URL: 'sessionPopupUrl'
    };

    const TAB_KEY_CODE = 9;

    /**
     * @constructor
     * @ngInject
     *
     * @name SessionModalCtrl
     *
     * @description
     * Shows the session timeout popup and modal when the time left within the current session
     * reaches [SESSION_POPUP_THRESHOLD].
     *
     * @listens session:time-left Executes when the time-left payload exceeds the
     *          [SESSION_POPUP_THRESHOLD].
     * @listens session-modal:deactivate Deactivates the modal and popup. Implemented to
     *          support closure from within the popup window.
     *
     * @fires session:logoff Sends the logoff event when requested by the user or required.
     * @fires session:keep-alive Sends the keep-alive event when requested by the user.
     */
    function SessionModalCtrl($scope, $window, lpCoreBus, lpWidget) {
        this.isPopupWindow = !!$window.opener && $window.opener !== $window;

        this.$scope = $scope;
        this.$window = $window;
        this.lpCoreBus = !this.isPopupWindow ? lpCoreBus : $window.opener.gadgets.pubsub;
        this.lpWidget = lpWidget;
        this.showModal = false;
    }

    SessionModalCtrl.prototype.DIMENSIONS = DIMENSIONS;
    SessionModalCtrl.prototype.MESSAGEBUS_EVENTS = MESSAGEBUS_EVENTS;
    SessionModalCtrl.prototype.PREFERENCES = PREFERENCES;

    SessionModalCtrl.prototype.$onInit = onInit;
    SessionModalCtrl.prototype.$onDestroy = onDestroy;

    SessionModalCtrl.prototype.keepAlive = keepAlive;
    SessionModalCtrl.prototype.logoff = logoff;

    var pubsubTimeLeftCallback;
    var pubsubDeactivateCallback;

    var eventKeyupCallback;
    var eventBeforeunloadCallback;

    function onInit() {
        this.lpCoreBus.subscribe(MESSAGEBUS_EVENTS.TIME_LEFT, pubsubTimeLeftCallback = evaluate.bind(this));
        this.lpCoreBus.subscribe(MESSAGEBUS_EVENTS.DEACTIVATE, pubsubDeactivateCallback = deactivate.bind(this));

        this.$window.addEventListener('keyup', eventKeyupCallback = keepFocus.bind(this));
        this.$window.addEventListener('beforeunload', eventBeforeunloadCallback = onDestroy.bind(this));
    };

    function onDestroy() {
        this.lpCoreBus.unsubscribe(MESSAGEBUS_EVENTS.TIME_LEFT, pubsubTimeLeftCallback);
        this.lpCoreBus.unsubscribe(MESSAGEBUS_EVENTS.DEACTIVATE, pubsubDeactivateCallback);

        this.$window.removeEventListener('keyup', eventKeyupCallback);
        this.$window.removeEventListener('beforeunload', eventBeforeunloadCallback);
    };

    function keepFocus(event) {
        var charCode = event.which || event.keyCode;

        if (!this.showModal || charCode !== TAB_KEY_CODE) {
            return;
        }

        if (!this.lpWidget.body.contains(event.target)) {
            event.preventDefault();

            this.lpWidget.body.querySelector('button').focus();
        }
    }

    /**
     * @method
     *
     * @param {integer} sessionTimeCountdown The amount of time left within the current
     *                                       session in seconds.
     *
     * @description
     * Evaluates whether it's time to call activate or logoff based upon the time left
     * within the current session.
     */
    function evaluate(sessionTimeCountdown) {
        var sessionPopupThreshold = parseInt(this.lpWidget.getPreference(PREFERENCES.SESSION_POPUP_THRESHOLD));
        this.sessionTimeCountdown = sessionTimeCountdown;

        if (this.sessionTimeCountdown <= sessionPopupThreshold && !this.isPopupWindow && !this.activated) {
            activate.call(this);
        }

        if (this.sessionTimeCountdown === 0) {
            logoff.call(this);
        }

        this.$scope.$applyAsync();
    };

    /**
     * @method
     *
     * @description
     * Activates the session timeout popup and modal
     */
    function activate() {
        this.activated = this.showModal = true;

        var url = this.lpWidget.getPreference(PREFERENCES.SESSION_POPUP_URL);
        var dimensions = getPopupDimensions.call(this);

        this.popupReference = this.$window.open(url, 'Session time-out', 'height=' + dimensions.height + 'px, width=' + dimensions.width + 'px, left=' + dimensions.left + 'px, top=' + dimensions.top + 'px, toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no');

        function getPopupDimensions() {
            return {
                height: DIMENSIONS.HEIGHT,
                left: (this.$window.screen.width / 2) - (DIMENSIONS.WIDTH / 2),
                top: (this.$window.screen.height / 2) - (DIMENSIONS.HEIGHT / 2),
                width: DIMENSIONS.WIDTH
            };
        }
    };

    /**
     * @method
     *
     * @description
     * Deactivates both the modal and popup and resets activated state.
     */
    function deactivate() {
        this.activated = false;

        if (this.popupReference) {
            this.popupReference.close();
        }

        this.showModal = false;

        this.$scope.$applyAsync();
    }

    /**
     * @name keepAlive
     *
     * @method
     * @public
     *
     * @description
     * Emits the [KEEP_ALIVE] and [DEACTIVATE] bus event to close the modal and popup
     * and instructing the session-timeout widget to prolong the current session.
     */
    function keepAlive() {
        this.lpCoreBus.publish(MESSAGEBUS_EVENTS.KEEP_ALIVE);
        this.lpCoreBus.publish(MESSAGEBUS_EVENTS.DEACTIVATE);
    }

    /**
     * @name logoff
     *
     * @method
     * @public
     *
     * @description
     * Emits the [LOGOFF] and [DEACTIVATE] bus event to close the modal and popup and
     * instructing the session-timeout widget to terminate the session and logoff.
     */
    function logoff() {
        this.lpCoreBus.publish(MESSAGEBUS_EVENTS.LOGOFF);
        this.lpCoreBus.publish(MESSAGEBUS_EVENTS.DEACTIVATE);
    }

    exports.SessionModalCtrl = SessionModalCtrl;
});
