define( function (require, exports, module) {
    'use strict';

    module.name = 'hsbc-widget-account-overview';

    var base = require('base');
    var core = require('core');
    var hsbcCommons = require('feature-commons');

    var deps = [
        core.name,
        hsbcCommons.name
    ];

    module.exports = base.createModule(module.name, deps)
        .constant('WIDGET_NAME', module.name )
        .controller( require('./account-overview.ctrl') )
        .filter( require('./account-overview.filter') )
        .factory( require('./account-overview.models') )
        .service( require('./account-overview.service') );
});
