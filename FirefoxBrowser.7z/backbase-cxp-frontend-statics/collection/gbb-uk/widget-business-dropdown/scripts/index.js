define( function (require, exports, module) {
    'use strict';

    module.name = 'widget-business-dropdown';

    var base = require('base');
    var core = require('core');
    var hsbcCommons = require('feature-commons');

    var deps = [
        core.name,
        hsbcCommons.name
    ];

    module.exports = base.createModule(module.name, deps)
        .constant('WIDGET_NAME', module.name )
        .controller( require('./business-dropdown.ctrl') )
        .service( require('./business-dropdown.service') );
});
