/**
 *  ----------------------------------------------------------------
 *  Author : Backbase R&D - Amsterdam - New York
 *  Filename : content.js
 *  Description:
 *
 *  Source code for CXP Universal Content Widget
 *  ----------------------------------------------------------------
 */

 b$ = b$ || {};
 b$.hsbc = b$.hsbc || {};
 b$.hsbc.widgets = b$.hsbc.widgets || {};
 b$.hsbc.widgets.marketingContentCtrl = (function($, pubSub) {
     'use strict';

     return {
         /**
          * Initialize event handler
          * @param  {Object} oWidget Backbase widget object
          */
         initialise: function(oWidget) {
             var btnControlElement = $(oWidget.body).find('.btn-control');
             var widgetElement = $(oWidget.body).find('.widget-marketing-content');
             var mainContainerElement = $(oWidget.body).find('.main-container');

             var windowContainer = {};

             if(mainContainerElement.hasClass('expand-main-container')){
                 mainContainerElement.removeClass('expand-main-container');
             }

             mainContainerElement.addClass('loading-screen');
             //to avoid widget expand displaying showing before initialisation, we hide the content and showing when widget is initializing
             widgetElement.css('display', 'block');

             //Method to manage displaying of popup
             var displayPopUp = function(url){
                 if((windowContainer[url] === undefined || windowContainer[url] === null || windowContainer[url].closed === true) && url !== undefined){
                     windowContainer[url] = window.open(url, url);
                 }
                 else if(windowContainer[url] && windowContainer[url].closed === false && url !== undefined){
                     windowContainer[url].focus();
                 }
             };

             //Method to manage deploying of main container
             var deployMainContainer = function(){
                 pubSub.publish('carousel.stop.autoplay');
                 pubSub.publish('carousel.display.pagination');
                 pubSub.publish('carousel.display.control');
                 mainContainerElement.addClass('expand-main-container');
                 pubSub.publish('template.expand');
             };

             //Method to reduce main container
             var reduceMainContainer = function(){
                 if(btnControlElement.hasClass('glyphicon-pause')){
                     pubSub.publish('carousel.start.autoplay');
                 }
                 pubSub.publish('carousel.hide.pagination');
                 pubSub.publish('carousel.hide.control');
                 mainContainerElement.removeClass('expand-main-container');
                 pubSub.publish('template.unexpand');
             };

             //Method to manage button play/pause to manage autoplay
             var manageButtonPlayPause = function(target) {
                 if ( target.hasClass('glyphicon-pause') ) {
                     pubSub.publish('carousel.stop.autoplay');
                     target.removeClass('glyphicon-pause').addClass('glyphicon-play');
                     pubSub.publish('autoplay.pause');
                 }
                 else {
                     pubSub.publish('carousel.start.autoplay');
                     target.removeClass('glyphicon-play').addClass('glyphicon-pause');
                     pubSub.publish('autoplay.play');
                 }
             };

             //This signal allowing to detect when all images are ready
             $(window).on('load', function() {
                 pubSub.publish('template.ready');
             });

             mainContainerElement.on('click', 'div', function(){
                 if($(this).hasClass('title')) {
                     deployMainContainer();
                 }
             });

             mainContainerElement.on('click', 'a', function(event){
                 if($(this).hasClass('btn-control')) {
                     var target = $( event.target);
                     manageButtonPlayPause(target);
                 }
                 else if($(this).hasClass('btn-close')){
                     reduceMainContainer();
                 }
                 else if($(this).hasClass('btn-primary')){
                     event.preventDefault();
                     event.stopPropagation();
                     var url = $(this).attr('href');
                     displayPopUp(url);
                 }
             });

             //Expand all containers
             pubSub.subscribe('template.expand', function(){
                 mainContainerElement.addClass('expand-main-container');
             });

             //Unexpand all containers
             pubSub.subscribe('template.unexpand', function(){
                 mainContainerElement.removeClass('expand-main-container');
             });

             //Displays all containers
             pubSub.subscribe('template.ready', function(){
                 mainContainerElement.removeClass('loading-screen');
             });

             //Display pause button on all containers
             pubSub.subscribe('autoplay.pause', function(){
                 btnControlElement.removeClass('glyphicon-pause').addClass('glyphicon-play');
             });

             //Display play button on all containers
             pubSub.subscribe('autoplay.play', function(){
                 btnControlElement.removeClass('glyphicon-play').addClass('glyphicon-pause');
             });
         }
     };
 }(window.jQuery, window.gadgets.pubsub));
