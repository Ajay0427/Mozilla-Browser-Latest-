require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var userProfileMock = require('../test/mock/userProfile.json');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('Welcome Message Controller', function() {
    var createController, mockCurrentUserProfile;

    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    beforeEach(inject(function($controller, $rootScope, $httpBackend, WelcomeMessageService, lpWidget) {
        createController = function(locals) {
            locals = locals || { $scope: $rootScope.$new() };
            return $controller('WelcomeMessageCtrl as $ctrl', locals);
        };

        mockCurrentUserProfile = function() {
            // randomise URL to avoid conflicts between tests
            var currentUserProfileUrl = '/api/current_user_profile/' + Math.random();
            var currentUserProfileData = Object.create(userProfileMock);

            $httpBackend.whenGET(currentUserProfileUrl).respond(currentUserProfileData);
            lpWidget.setPreference(WelcomeMessageService.PROPERTIES.CURRENT_USER_PROFILE_URL, currentUserProfileUrl);
        };
    }));

    describe('$onInit()', function() {
        it('should initialize the instance', inject(function() {
            var ctrl = createController();
            var spy = spyOn(ctrl, 'initializeCurrentUserProfile');
            ctrl.$onInit();

            expect(spy).toHaveBeenCalled();
        }));

        it('should expose messages via properties', inject(function(lpWidget, $httpBackend) {
            var morningMessageMock = '/messages/morning-message/' + Math.random();
            var afternoonMessageMock = '/messages/after-noon-message/' + Math.random();
            var eveningMessageMock = '/messages/evening-message/' + Math.random();

            var ctrl = createController();

            lpWidget.setPreference(ctrl.PROPERTIES.MORNING_MESSAGE, morningMessageMock);
            lpWidget.setPreference(ctrl.PROPERTIES.AFTERNOON_MESSAGE, afternoonMessageMock);
            lpWidget.setPreference(ctrl.PROPERTIES.EVENING_MESSAGE, eveningMessageMock);

            mockCurrentUserProfile();
            ctrl.$onInit();
            $httpBackend.flush();

            expect(ctrl.messages).toEqual({
                morningMessage: morningMessageMock,
                afternoonMessage: afternoonMessageMock,
                eveningMessage: eveningMessageMock
            });
        }));
    });

    describe('initializeCurrentUserProfile()', function() {
        it('should fetch/process a value of setUserProfile the controller', inject(function($httpBackend) {
            mockCurrentUserProfile();
            var ctrl = createController();

            ctrl.initializeCurrentUserProfile();
            $httpBackend.flush();

            var currentUserProfile = userProfileMock;
            expect(ctrl.currentUserProfile).toEqual({
                dateAndTimeLastLoggedOn: currentUserProfile.dateAndTimeLastLoggedOn,
                firstName: 'John'
            });
        }));
    });

    describe('populateDaypartName()', function() {
        it('should fetch a value of good morning message', inject(function($httpBackend) {
            mockCurrentUserProfile();
            var ctrl = createController();

            ctrl.currentDate = new Date('Thu Mar 09 2017 09:30:54 GMT+0000');
            ctrl.messages = {
                morningMessage: 'Good morning'
            };
            ctrl.$onInit();
            $httpBackend.flush();

            expect(ctrl.userGreeting).toEqual(ctrl.messages.morningMessage);
        }));

        it('should fetch a value of good afternoon message', inject(function($httpBackend) {
            mockCurrentUserProfile();
            var ctrl = createController();
            ctrl.currentDate = new Date('Thu Mar 09 2017 15:30:54 GMT+0000');
            ctrl.messages = {
                afternoonMessage: 'Good afternoon'
            };
            ctrl.$onInit();
            $httpBackend.flush();

            expect(ctrl.userGreeting).toEqual(ctrl.messages.afternoonMessage);
        }));

        it('should fetch a value of good evening message', inject(function($httpBackend) {
            mockCurrentUserProfile();
            var ctrl = createController();
            ctrl.currentDate = new Date('Thu Mar 09 2017 19:30:54 GMT+0000');
            ctrl.messages = {
                eveningMessage: 'Good evening'
            };
            ctrl.$onInit();
            $httpBackend.flush();

            expect(ctrl.userGreeting).toEqual(ctrl.messages.eveningMessage);
        }));
    });

});
