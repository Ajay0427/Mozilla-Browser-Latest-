# New layout modal widget
