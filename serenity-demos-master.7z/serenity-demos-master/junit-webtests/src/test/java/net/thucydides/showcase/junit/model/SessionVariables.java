package net.thucydides.showcase.junit.model;

/**
 * Created by john on 12/11/14.
 */
public enum SessionVariables {
    SELECTED_LISTING
}
