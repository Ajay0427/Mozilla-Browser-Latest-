require('angular');
require('angular-mocks');

var main = require('../index');
var ngModule = window.module;

describe('HsbcUtils', function() {
    beforeEach(ngModule(main.name));

    describe('replaceContextPath()', function() {
        it('should replace contextRoot placeholder with the value exposed globally on portal', inject(function(HsbcUtils) {
            b$.portal.config = b$.portal.config || {};
            b$.portal.config.serverRoot = '/portal';

            var testPath = '$(contextRoot)/foo/bar';
            var expectedPath = '/portal/foo/bar';

            var path = HsbcUtils.replaceContextPath(testPath);

            expect(path).toBe(expectedPath);
        }));

        it('should replace the contextRoot with an empty context (in case of root deploy)', inject(function(HsbcUtils) {
            b$.portal.config = b$.portal.config || {};
            b$.portal.config.serverRoot = '';

            var testPath = '$(contextRoot)/foo/bar';
            var expectedPath = '/foo/bar';

            var path = HsbcUtils.replaceContextPath(testPath);

            expect(path).toBe(expectedPath);
        }));
    });
});
