define(function(require, exports) {
    'use strict';

    function HsbcUtils() {
    }

    HsbcUtils.prototype.replaceContextPath = replaceContextPath;

    /**
     * Replaces the $(contextRoot) placeholder with the actual context root that
     * is defined globally as part of Portal configuration
     * @param {String} path
     * @return {String}
     */
    function replaceContextPath(path) {
        var contextRoot = (window.b$ && window.b$.portal && b$.portal.config && b$.portal.config.serverRoot);

        return String(path || '').replace('$(contextRoot)', contextRoot);
    }

    exports.HsbcUtils = HsbcUtils;
});
