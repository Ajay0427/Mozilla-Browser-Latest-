# widget-hsbc-content

A boilerplate with the basic structure to write customisable contents

It includes:

- unit tests
- linter configuration
- .editorconfig file
- LESS styling
- a sample JS file

## Tooling

To start developing, run `bower install` first.

To build and run the linter/tests:

- bblp build -f

To watch and recompile on demand:

- bblp start
- bblp test -w
