require('angular');
require('angular-mocks');

var modelXML = require('../model.xml');
var indexHTML = require('../index.html');

var main = require('./index');
var WidgetMock = require('../test/widget-mocks');
var ngModule = window.module;

describe('SessionLogoffService', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var lpWidget = new WidgetMock(modelXML, indexHTML);
        $provide.value('lpWidget', lpWidget);
    }));

    beforeEach(inject(function($cookies, $httpBackend, SessionLogoffService, lpWidget) {
        this.$cookies = $cookies;
        this.$httpBackend = $httpBackend;

        this.SessionLogoffService = SessionLogoffService;
        this.lpWidget = lpWidget;
    }));

    afterEach(function() {
        this.$httpBackend.verifyNoOutstandingExpectation();
        this.$httpBackend.verifyNoOutstandingRequest();
    });

    describe('logoff', function() {
        beforeEach(function() {
            this.bbxsrfValue = '0118999881';
            this.jsessionidValue = '9991197253';

            this.$cookies.put('BBXSRF', this.bbxsrfValue);
            this.$cookies.put('JSESSIONID', this.jsessionidValue);
        });

        it('should do gbbp request for a succesful logoff', function() {
            var result;
            var sessionLogoffGbbpUrl = this.lpWidget.setPreference(this.SessionLogoffService.PREFERENCES.SESSION_LOGOFF_GBBP_URL, 'one');

            this.$httpBackend.expectPOST(sessionLogoffGbbpUrl).respond(200);

            this.SessionLogoffService.logoff().then(function() {
                result = 'resolved';
            });

            this.$httpBackend.flush();
            expect(result).toBe('resolved');
        });

        it('should send the right headers to gbbp logoff', function() {
            var sessionLogoffGbbpUrl = this.lpWidget.setPreference(this.SessionLogoffService.PREFERENCES.SESSION_LOGOFF_GBBP_URL, '011899988199');

            this.$httpBackend.expectPOST(sessionLogoffGbbpUrl, undefined, function(headers) {
                return headers['X-BBXSRF'] === this.bbxsrfValue && headers.JSESSIONID === this.jsessionidValue;
            }.bind(this)).respond(200);

            this.SessionLogoffService.logoff();

            this.$httpBackend.flush();
        });
    });
});
