require('angular');
require('angular-mocks');

var main = require('./index');
var indexHTML = require('../index.html');
var WidgetMock = require('../test/widget-mocks');
var contactUSListMock = require('../test/mock/contactUs_List.json');
var ngModule = window.module;

describe('ContactUS Service', function() {
    beforeEach(ngModule(main.name, function($provide) {
        var widget = new WidgetMock(indexHTML);
        $provide.value('lpWidget', widget);
    }));

    afterEach(inject(function($httpBackend) {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    describe('getContactUSListData()', function() {
        it('should fetch a contactus list data using URL on widget properties', inject(function(ContactUSService, lpWidget, $rootScope, $httpBackend) {
            var urlToFetch = '/contactUSList/' + Math.random();
            var result;
            $httpBackend.expectGET(urlToFetch).respond(200, contactUSListMock);
            lpWidget.setPreference(ContactUSService.PROPERTIES.CONTACT_US_LIST_URL, urlToFetch);
            ContactUSService.getContactListData().then(function(o) { result = o; });
            $httpBackend.flush();

            expect(result).toEqual({
                result: contactUSListMock
            });
        }));
});
});
