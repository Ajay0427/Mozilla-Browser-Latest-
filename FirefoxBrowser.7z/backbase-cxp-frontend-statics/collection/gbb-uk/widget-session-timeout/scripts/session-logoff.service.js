define(function(require, exports) {
    'use strict';

    const PREFERENCES = {
        SESSION_LOGOFF_GBBP_URL: 'sessionLogoffGbbpUrl'
    };

    /**
     * @constructor
     * @ngInject
     */
    function SessionLogoffService($cookies, $http, $q, lpWidget) {
        this.$cookies = $cookies;
        this.$http = $http;
        this.$q = $q;
        this.lpWidget = lpWidget;
    }

    SessionLogoffService.prototype.PREFERENCES = PREFERENCES;
    SessionLogoffService.prototype.logoff = logoff;

    /**
     * @method
     * @public
     *
     * @param {string} environment the environment for which the session needs to be kept alive.
     *
     * @description
     * Sends a GET request to the heartbeat URL for the given environment.
     *
     * @returns {promise} keepalive url for the given environment if valid, undefined otherwise.
     */
    function logoff() {
        return logoffGbbp.call(this);
    }

    function logoffGbbp() {
        var gbbpUrl = this.lpWidget.getPreference([PREFERENCES.SESSION_LOGOFF_GBBP_URL]);
        var headers = getCxpHeaders.call(this);

        return this.$http.post(gbbpUrl, {}, {headers: headers});

        function getCxpHeaders() {
            return {
                'X-BBXSRF': this.$cookies.get('BBXSRF'),
                'JSESSIONID': this.$cookies.get('JSESSIONID')
            };
        }
    }

    exports.SessionLogoffService = SessionLogoffService;
});
