(function (b$, PubSub) {
    'use strict';
    var Container = b$.bdom.getNamespace('http://backbase.com/2013/portalView').getClass('container');

    function PageFrameContainer() {
        Container.apply(this, arguments);
        this.isPossibleDragTarget = true;
    }

    Container.extend(PageFrameContainer, {
        localName: 'hsbcContainerPageFrame',
        namespaceURI: 'templates_hsbcContainerPageFrame'
    }, {
        template: function(json) {
            var data = {item: json.model.originalItem};
            return window[this.namespaceURI][this.localName](data);
        },
        handlers: {
            DOMReady: function(){
                var container = $(this.htmlNode);

                PubSub.subscribe('page-frame:toggle-menu', function toggleMenu() {
                    container.toggleClass('expanded');
                });
            },

            preferencesSaved: function(event){
                if(event.target === this) {
                    this.refreshHTML();
                }
            }
        }
    });
})(window.b$, window.gadgets.pubsub);
