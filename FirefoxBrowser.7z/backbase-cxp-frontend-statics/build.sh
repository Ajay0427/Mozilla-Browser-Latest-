#!/bin/sh
mvn clean package