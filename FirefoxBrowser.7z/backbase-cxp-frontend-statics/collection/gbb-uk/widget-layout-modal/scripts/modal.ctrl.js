/**
 * Controllers
 * @module controllers
 */
define(function (require, exports) {
    'use strict';

    /**
     * @constructor
     * @ngInject
     *
     * @name LayoutModalCtrl
     *
     * @description
     * Checks if the layout modal has been activated before by reading local storage, activates
     * the bootstrap modal that informes the user about the new layout if appropriate and saves
     * the display state into local storage after which the modal will not be displayed.
     */
    function LayoutModalCtrl($window) {
        this.$window = $window;
    }

    LayoutModalCtrl.prototype.$onInit = onInit;

    function onInit() {
        if (!isShownBefore.call(this)) {
            showModal.call(this);
            saveShownBefore.call(this);
        }
    };

    function isShownBefore() {
        return !!this.$window.localStorage.layoutModalShown;
    }

    function showModal() {
        this.showModal = true;
    }

    function saveShownBefore() {
        this.$window.localStorage.layoutModalShown = true;
    }

    exports.LayoutModalCtrl = LayoutModalCtrl;
});
