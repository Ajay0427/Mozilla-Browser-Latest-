/**
 * filter
 * @module filter
 */
define(function(require, exports) {
    'use strict';

    function accountNumberFilter() {
        return function(accountNumber) {
            if (accountNumber && /^[0-9]+$/.test(accountNumber)) {
                accountNumber = accountNumber.replace(/(.{4})/g, '$1 ').trim();
            }

            return accountNumber;
        };
    }

    /**
     * @ngInject
     */
    function amountFilter(currencyFilter) {
        return function(amountValue) {
            if (amountValue || amountValue === 0) {
                var amountAbs = Math.abs(amountValue);
                return currencyFilter(amountAbs, '', 2);
            }

            return '';
        };
    }

    /**
     * @ngInject
     */
    // eslint-disable-next-line no-shadow
    function balanceFilter(amountFilter) {
        return function(balanceValue) {
            if (balanceValue || balanceValue === 0) {
                return amountFilter(balanceValue);
            }

            return 'N/A';
        };
    }

    function cardholderNameFilter() {
        return function(cardholderName) {
            var civility = '';
            var firstName = '';

            var slashSplitParts = cardholderName.split('/');
            if (slashSplitParts.length > 1) {
                civility = slashSplitParts[1] + ' ';
                cardholderName = slashSplitParts[0];
            }

            var commaSplitParts = cardholderName.split(',');
            if (commaSplitParts.length > 1) {
                firstName = commaSplitParts[1] + ' ';
                cardholderName = commaSplitParts[0];
            }

            return civility + firstName + cardholderName;
        };
    }

    // TODO remove this filter! Is conflicting with AngularJS builtin
    // Use a decorator instead if really necessary
    /**
     * @ngInject
     */
    function dateFilter($locale) {
        return function(date) {
            if (date && date.split('-')[1]) {
                var month = $locale.DATETIME_FORMATS.SHORTMONTH[date.split('-')[1].replace(/^0+/, '') - 1];
                return date.split('-')[2] + ' ' + month + ' ' + date.split('-')[0];
            }

            return date;
        };
    }

    /**
     * @ngInject
     */
    function drOrCrDetailsFilter() {

        return function(balance, isCardHolder) {

            if (balance < 0 && !isCardHolder) {
                return ' DR';
            }

            if (balance > 0 && isCardHolder) {
                return ' CR';
            }

            return '';
        };
    }

    function drOrCrListFilter() {

        return function(balance, isCardHolder) {

            if (balance < 0) {
                return 'DR';
            }

            if (balance > 0 && isCardHolder) {
                return 'CR';
            }

            return '';
        };
    }

    function descriptionConcatFilter() {
        function toString(value) {
            return String(value || '');
        }

        return function(transaction) {
            if (!transaction) {
                return '';
            }

            var description = [
                toString(transaction.description1),
                toString(transaction.description2),
                toString(transaction.description3),
                toString(transaction.description4),
                toString(transaction.description5)
            ];

            return description.join(' ').trim();
        };
    }

    function sortTypeNumberFilter() {
        return function(sortTypeNumber) {
            if (sortTypeNumber) {
                sortTypeNumber = sortTypeNumber.replace(/(.{2})/g, '$1-').slice(0, 8);
            }

            return sortTypeNumber;
        };
    }

    function timeFilter() {
        return function(time) {
            if (time && time.split(':').length > 2) {
                time = time.slice(0, time.lastIndexOf(':'));
            }

            return time;
        };
    }

    exports.accountNumber = accountNumberFilter;
    exports.amount = amountFilter;
    exports.balance = balanceFilter;
    exports.dateFilter = dateFilter;
    exports.cardholderName = cardholderNameFilter;
    exports.descriptionConcat = descriptionConcatFilter;
    exports.drOrCrDetails = drOrCrDetailsFilter;
    exports.drOrCrList = drOrCrListFilter;
    exports.sortTypeNumber = sortTypeNumberFilter;
    exports.time = timeFilter;
});
