var $ = window.$ = require('jquery');

require('./index.js');

var modelXML = require('../model.xml');
var indexHTML = require('../test/unit/menu.mock.html');
var WidgetMock = require('../test/widget-mocks.js');
var Widget = b$.hsbc.widgets.WidgetEdm;

describe('WidgetEdm', function() {
    function EventMock(target) {
        this.currentTarget = target;
        this.preventDefault = jasmine.createSpy('preventDefault');
    }

    function createWidget() {
        var widgetChrome = document.createElement('div');
        var widgetObject = new WidgetMock(modelXML, indexHTML);

        widgetChrome.appendChild(widgetObject.body);

        return Widget.create(widgetObject);
    }

    function getCreatedForm() {
        return document.createElement.calls.all().filter(function(call) {
            return call.args[0] === 'form';
        })[0].returnValue;
    }

    describe('getContentHeight(geometry)', function() {
        it('should return the outer height when inner height is less than outer height', function() {
            var geometry = {
                outerHeight: 10,
                innerHeight: 5
            };

            var widget = createWidget();
            var height = widget.getContentHeight(geometry);

            expect(height).toBe(geometry.outerHeight);
        });

        it('should return the outer height if both outer and inner are equal', function() {
            var geometry = {
                outerHeight: 10,
                innerHeight: 10
            };

            var widget = createWidget();
            var height = widget.getContentHeight(geometry);

            expect(height).toBe(geometry.outerHeight);
        });

        it('should return the inner height if inner height is greater than outer height', function() {
            var geometry = {
                outerHeight: 5,
                innerHeight: 10
            };

            var widget = createWidget();
            var height = widget.getContentHeight(geometry);

            expect(height).toBe(geometry.innerHeight);
        });
    });

    describe('openSamlTokenPage', function() {
        beforeEach(function() {
            this.getCreatedForm = getCreatedForm;

            this.widget = createWidget();

            var appendChildReference = document.body.appendChild;
            var jQueryGetReference = $.get;

            spyOn($, 'get').and.callFake(function() {
                if (arguments[0].indexOf('/saml/token/') !== -1) {
                    return $.Deferred().resolve({data: 'saml-token'});
                }

                return jQueryGetReference.call(arguments);
            });

            spyOn(document, 'createElement').and.callThrough();
            spyOn(document.body, 'removeChild').and.callThrough();
            spyOn(document.body, 'appendChild').and.callFake(function(appendedElement) {
                if (appendedElement.nodeName.toLowerCase() === 'form') {
                    appendedElement.submit = function() {};
                }

                appendChildReference.apply(document.body, arguments);
            });
        });

        it('should create a new form element on a saml token page request', function() {
            var samlTokenElement = this.widget.element.querySelector('[data-saml-token-url="/saml/token/accountservices/"]');
            var eventMock = new EventMock(samlTokenElement);

            this.widget.openSamlTokenPage(eventMock);

            expect(document.createElement.calls.all().filter(function(call) {
                return call.args[0] === 'form';
            }).length).toEqual(1);
        });

        it('should clean up the form element from the DOM', function() {
            var samlTokenElement = this.widget.element.querySelector('[data-saml-token-url="/saml/token/accountservices/"]');
            var eventMock = new EventMock(samlTokenElement);
            var form;

            this.widget.openSamlTokenPage(eventMock);
            form = this.getCreatedForm();

            expect(document.body.removeChild).toHaveBeenCalledWith(form);
        });

        it('should create a hidden input element to the form containing the saml token', function() {
            var samlTokenElement = this.widget.element.querySelector('[data-saml-token-url="/saml/token/accountservices/"]');
            var eventMock = new EventMock(samlTokenElement);
            var form;

            this.widget.openSamlTokenPage(eventMock);
            form = this.getCreatedForm();

            expect(form.querySelectorAll('input[name="SAMLResponse"]').length).toEqual(1);
            expect(form.querySelector('input[name="SAMLResponse"]').getAttribute('value')).toEqual('saml-token');
        });

        it('should use the links\' inner text as target to make sure a new window per link is only opened once', function() {
            var samlTokenElement = this.widget.element.querySelector('[data-saml-token-url="/saml/token/accountservices/"]');
            var eventMock = new EventMock(samlTokenElement);
            var form;

            this.widget.openSamlTokenPage(eventMock);
            form = this.getCreatedForm();

            expect(form.getAttribute('target')).toEqual('Account Services');
        });

        it('should use the links\' href attribute as form action', function() {
            var samlTokenElement = this.widget.element.querySelector('[data-saml-token-url="/saml/token/accountservices/"]');
            var eventMock = new EventMock(samlTokenElement);
            var form;

            this.widget.openSamlTokenPage(eventMock);
            form = this.getCreatedForm();

            expect(form.getAttribute('action')).toEqual('/saml/page/');
        });

        it('should not execute any action when no page url was specified', function() {
            var samlTokenElement = this.widget.element.querySelector('[data-saml-token-url="/saml/token/connectionshub/"]');
            var eventMock = new EventMock(samlTokenElement);

            this.widget.openSamlTokenPage(eventMock);

            expect(document.createElement.calls.all().filter(function(call) {
                return call.args[0] === 'form';
            }).length).toEqual(0);
        });
    });

    describe('#toggleMenuLevel()', function () {
        it('should open a second-level menu and mark the toggle root as open', function() {
            var widget = createWidget();
            var element = $(widget.element);

            var toggleTargetElement = element.find('[data-target="toggle"]').eq(0);
            var toggleElement = toggleTargetElement.find('[data-toggle="toggle"]').eq(0);
            var toggleRoot = element.find('[data-toggle-root]');
            var event = new EventMock(toggleElement[0]);

            widget.toggleMenuLevel(event);

            expect(toggleRoot.hasClass(Widget.CLASSES.OPEN)).toBe(true);
            expect(toggleTargetElement.hasClass(Widget.CLASSES.OPEN)).toBe(true);
            expect(event.preventDefault).toHaveBeenCalled();
        });

        it('should close a previously open second-level menu and mark the toggle root as closed', function() {
            var widget = createWidget();
            var element = $(widget.element);

            var toggleTargetElement = element.find('[data-target="toggle"]').eq(0);
            var toggleElement = toggleTargetElement.find('[data-toggle="toggle"]').eq(0);
            var toggleRoot = element.find('[data-toggle-root]');
            var event = new EventMock(toggleElement[0]);

            // click once to open, click again to close
            widget.toggleMenuLevel(event);
            widget.toggleMenuLevel(event);

            expect(toggleRoot.hasClass(Widget.CLASSES.OPEN)).toBe(false);
            expect(toggleRoot.hasClass(Widget.CLASSES.CLOSED)).toBe(true);
            expect(toggleTargetElement.hasClass(Widget.CLASSES.OPEN)).toBe(false);

            expect(event.preventDefault).toHaveBeenCalled();
        });

        it('should close a second-level menu from a inner toggle child element of that menu', function() {
            var widget = createWidget();
            var element = $(widget.element);

            var toggleTargetElement = element.find('[data-target="toggle"]').eq(0);
            var toggleElement = toggleTargetElement.find('[data-toggle="toggle"]').eq(0);
            var toggleOnParentElement = toggleTargetElement.find('[data-toggle="parent"]').eq(0);
            var toggleRoot = element.find('[data-toggle-root]');
            var openEvent = new EventMock(toggleElement[0]);
            var closeEvent = new EventMock(toggleOnParentElement[0]);

            // click once to open, click again to close
            widget.toggleMenuLevel(openEvent);
            widget.toggleMenuLevel(closeEvent);

            expect(toggleRoot.hasClass(Widget.CLASSES.OPEN)).toBe(false);
            expect(toggleRoot.hasClass(Widget.CLASSES.CLOSED)).toBe(true);
            expect(toggleTargetElement.hasClass(Widget.CLASSES.OPEN)).toBe(false);

            expect(openEvent.preventDefault).toHaveBeenCalled();
            expect(closeEvent.preventDefault).toHaveBeenCalled();
        });
    });
});
