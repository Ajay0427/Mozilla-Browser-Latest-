/**
*  ----------------------------------------------------------------
*  Author : Backbase R&D - Amsterdam - New York
*  Filename : content.js
*  Description:
*
*  Source code for CXP Universal Content Widget
*  ----------------------------------------------------------------
*/

b$ = b$ || {};
b$.hsbc = b$.hsbc || {};
b$.hsbc.extensions = b$.hsbc.extensions || {};
b$.hsbc.extensions.WidgetHsbcContentExtension = (function($) {
    'use strict';

    return {

        /**
        *  Initialize content widget
        *  @param  {Object} oWidget Backbase widget object
        */
        start: function(oWidget) {
            b$.hsbc.widgets.WidgetHsbcContent.start(oWidget);
            //extension part for marketing content
            if($(oWidget.body).find('.widget-marketing-content').length){
                    b$.hsbc.widgets.marketingContentCtrl.initialise(oWidget);
            }
        }
    };
}(window.jQuery));
